﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Logging;
using LITS.Core.Resources;
using System.Data.Entity;

namespace LITS.Core.Main
{
    public class BusinessRule
    {
        private static LITSEntities _LITSEntities;

        public BusinessRule()
        {
            _LITSEntities = new LITSEntities();
        }

        #region CONST STRING MESSAGE
        public static string MSG_SUBMIT_SUCCESSFULL = "Submit Successfully";
        public static string MSG_CANCEL_SUCCESSFULL = "Cancel Successfully";
        public static string MSG_COMPLETE_SUCCESSFULL = "Complete Successfully";
        public static string MSG_APPROVED_SUCCESSFULL = "Approved Successfully";
        public static string MSG_RETURN_SUCCESSFULL = "Return To CI Successfully";
        public static string MSG_SENDBACK_SUCCESSFULL = "Send back SC Successfully";
        public static string MSG_SENDBACKOS_SUCCESSFULL = "Send back OS Successfully";
        public static string MSG_REQUEUE_SUCCESSFULL = "Requeue to Tele Successfully";
        public static string MSG_RECOMMEND_SUCCESSFULL = "Recommend Successfully";
        public static string MSG_RECOMMEND_FAIL = "Recommend Rules Failed. Please check your Decision";
        public static string MSG_FRAUD_INVESTIGATE = "This application are investigated by Fraud";
        public static string MSG_REQUIRED = "Please input all required field";
        public static string MSG_PENDINGLOG_SENDBACK = "Please update pending log before sending back.";
        public static string MSG_PENDINGLOG_RESPONSE = "Please reponse all pending log before revert back.";
        public static string MSG_REQUEUELOG_SENDBACK = "Please update requeue log before sending back.";
        public static string MSG_REQUEUELOG_RESPONSE = "Please reponse all requeue log before recommend.";
        public static string MSG_BYPASS_SUCCESSFULL = "BY PASS Successfully";
        public static string MSG_ERROR_EXPIREDDATE = "Fail when check Expired date or Expired Visa/Work Permit";
        public static string MSG_ERROR_WHEN_PROCESSING = "Error when processing";
        public static string MSG_QUEUE_STATUS = "Current status of this application is not your queue.";
        public static string MSG_ERROR_VALIDVISA = "Fail when checking Valid of Visa / Work permit";
        public static string MSG_ID_REQUIRED = "ID or PP of Customer is required";
        public static string MSG_FRAUD_WATCHLIST = "This case need route to Fraud to check WatchList";
        public static string GROUP_STANDARD = "1.Standard application";
        public static string GROUP_SELF_EMPLOYED = "2.Self-employed";
        public static string GROUP_SECURED = "3.Secured application";
        public static string GROUP_SUPPLEMENTARY = "4.Supplementary card";
        public static string MSG_ERROR_INCORRECTEMAIL = "Email is incorrect format";
        public const string MSG_CCDupPipeLine = "The same CC application on pipeline";
        public const string MSG_PNDupPipeline = "The same PN application on pipeline";
        public const string MSG_MLDupPipeline = "The same ML application on pipeline";
        public const string MSG_CCDupApproved = "The same CC application was approved";
        public const string MSG_PNDupApproved = "The same PN application was approved";
        public const string MSG_MLDupApproved = "The same ML application was approved";
        public const string MSG_DupOverwrite = "Press OK to Overwrite or Cancel.";
        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="appId"></param>
        /// <param name="isInvestigave"></param>
        /// <returns></returns>
        public static bool ApplicationIsBlackList(int appId, ref bool isInvestigave)
        {
            bool isCheckedBlackList = false;
            isInvestigave = true;
            try
            {
                using (var context = new LITSEntities())
                {
                    var frmInvestigave = context.frm_investigave.Where(x => x.fk_application_information_id == appId).FirstOrDefault();
                    if (frmInvestigave != null && (frmInvestigave.fk_status_id != (int)EnumList.CCApplicationStatus.FRFinal
                      || frmInvestigave.fk_status_id != (int)EnumList.CCApplicationStatus.FRRejected))
                    {
                        isCheckedBlackList = true;
                    }

                    if (frmInvestigave != null && !string.IsNullOrEmpty(frmInvestigave.CheckerBy)
                      && frmInvestigave.fk_status_id == (int)EnumList.CCApplicationStatus.FRFinal)
                    {
                        isInvestigave = false;
                    }
                }
            }
            catch(Exception ex)
            {
                LogHelper.WriteLogError("[ApplicationIsBlackList]::", ex);
            }

            return isCheckedBlackList;
        }

        /// <summary>
        /// Check user already input Identification or not
        /// </summary>
        /// <param name="id">Input value can be CustomerId or ApplicationId</param>
        /// <returns></returns>
        public static bool CheckExistingIdentification(int CustomerID, ref string msgError)
        {
            using (var context = new LITSEntities())
            {
                var listId = context.customer_identification.Where(x => x.fk_customer_information_id == CustomerID).ToList();
                if (listId.Count > 0)
                {
                    int idCount = 0;
                    int ppCount = 0;
                    int prevIDPP = 0;
                    foreach (customer_identification item in listId)
                    {
                        if (item.fk_m_identification_type_id == (int)EnumList.IdentificationType.ID)
                            idCount++;
                        else if (item.fk_m_identification_type_id == (int)EnumList.IdentificationType.Passport)
                            ppCount++;
                        else if (item.fk_m_identification_type_id == (int)EnumList.IdentificationType.Previous_ID
                            || item.fk_m_identification_type_id == (int)EnumList.IdentificationType.Previous_PP)
                            prevIDPP++;
                    }

                    if (idCount > 1 || ppCount > 1)
                    {
                        msgError = "Select Identification Type only 1 time with type is ID/PP";
                        return false;
                    }
                    else if (prevIDPP == 0)
                    {
                        msgError = "Please input 1 record with type Previous_ID/Previous_PP. If customer has no old ID, kindly input N/A";
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
                else
                {
                    msgError = MSG_ID_REQUIRED;
                    return false;
                }
            }
        }

        /// <summary>
        /// Check blacklist automatic
        /// </summary>
        /// <param name="appNo"></param>
        /// <param name="customerID"></param>
        /// <param name="customerName"></param>
        /// <param name="customerStatus">If not Active, need to check BL</param>
        /// <param name="dOB"></param>
        /// <param name="companyCode"></param>
        /// <param name="message"></param>
        /// <param name="blackListStatus"></param>
        /// <param name="pID"></param>
        /// <returns>/// false: in case Application is not pass checking blacklist true: in case Application is pass checking blacklist</returns>
        public static bool CheckBlackList(int appId, int customerId, string customerName, DateTime dOB, int companyCodeId, string companyCode,
            ref string message, ref string blackListStatus, string pID)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    bool result = true;
                    try
                    {
                        var customer = context.customer_information.Where(x => x.pk_id == customerId).FirstOrDefault();

                        if (customer != null && customer.fk_status_id != (int)EnumList.CustomerStatus.Active && !ApplicationIsFraud(appId))
                        {
                            frm_black_list_log frmBlackListLog = new frm_black_list_log();
                            frmBlackListLog.fk_application_information_id = appId;
                            frmBlackListLog.fk_customer_information_id = customer.pk_id;
                            frmBlackListLog.created_date = DateTime.Now;

                            var blackListCom = context.frm_black_list_company.Where(x => x.fk_m_company_code_id == customer.fk_m_company_code_id).FirstOrDefault();

                            if (blackListCom != null)
                            {
                                #region step 1: Check blacklist company by CompanyCode
                                // Application rejected by Company Black List Code
                                frmBlackListLog.fk_application_information_id = blackListCom.fk_application_information_id;
                                frmBlackListLog.fk_customer_information_id = customerId;
                                frmBlackListLog.fk_frm_black_list_code_id = blackListCom.fk_frm_black_list_code_id;
                                frmBlackListLog.owner_name = blackListCom.owner_name;
                                frmBlackListLog.is_active = true;
                                frmBlackListLog.fk_status_id = (int)EnumList.CCApplicationStatus.FRPending;
                                frmBlackListLog.fk_type_id = 1;
                                frmBlackListLog.created_by = pID;
                                frmBlackListLog.created_date = DateTime.Now;

                                message = "The application rejected by Company Black List Code: " + blackListCom.fk_frm_black_list_code_id;
                                result = false;
                                #endregion
                            }
                            else
                            {
                                var ccIdens = context.customer_identification.Where(x => x.fk_customer_information_id == customerId).ToList();

                                #region step 2: Check blacklist customer by CustomerID
                                var blackListCustStep2 = context.frm_black_list_customer.Where(x => x.fk_customer_information_id == customerId).FirstOrDefault();

                                if (blackListCustStep2 != null)
                                {
                                    string[] arrBlackCustCodeForever = "IF|CF|RF|SF|D|DRP|Settlement|RL|LL".Split('|');
                                    string[] arrBlackCustCodeWarning = "RR|O".Split('|');

                                    if (Array.IndexOf(arrBlackCustCodeForever, blackListCustStep2.fk_frm_black_list_code_id) != -1)
                                    {
                                        // Reject forever
                                        message = "The customer with ID number " + blackListCustStep2.fk_customer_information_id
                                            + " is in BLACK LIST. Hence, you are not allowed to submit application for this customer";
                                    }
                                    else if (Array.IndexOf(arrBlackCustCodeWarning, blackListCustStep2.fk_frm_black_list_code_id) != -1)
                                    {
                                        #region Need FRM Investigave
                                        message = "ApplicationNo " + appId + " was created but the customer ID number "
                                        + blackListCustStep2.fk_customer_information_id + " are in blacklist with type "
                                        + blackListCustStep2.fk_frm_black_list_code_id + " exist in BLACK LIST. The case will be automatically transfered to Fraud team queue for review.";

                                        frm_investigave frmInvest = new frm_investigave();

                                        frmInvest.fk_application_information_id = appId;
                                        frmInvest.ReferedBy = pID;
                                        frmInvest.ReferedDate = DateTime.Now;
                                        frmInvest.ReferedChannel = "Check automactic";
                                        frmInvest.fk_customer_information_id = customerId;
                                        foreach (customer_identification item in ccIdens)
                                        {
                                            switch (item.fk_m_identification_type_id)
                                            {
                                                //case "ID": frmInvest.PersonalNo = item.IdentificationNo; break;
                                                //case "Passport": frmInvest.PassportNo = item.IdentificationNo; break;
                                                //case "Previous_ID": frmInvest.PreviousNo = item.IdentificationNo; break;
                                                //case "Previous_PP": frmInvest.SocialNo = item.IdentificationNo; break;
                                            }
                                        }
                                        frmInvest.fk_status_id = (int)EnumList.CCApplicationStatus.FRPending;
                                        frmInvest.SummaryInvestigation = "Check Black list automatic with code " + blackListCustStep2.fk_frm_black_list_code_id;
                                        frmInvest.fk_m_investigave_type_id = (int)EnumList.FRMInvestigaveType.PreApprovalEscalation;

                                        context.frm_investigave.Add(frmInvest);
                                        context.SaveChanges();
                                        #endregion
                                    }

                                    frmBlackListLog.fk_status_id = (int)EnumList.CCApplicationStatus.FRPending;
                                    frmBlackListLog.fk_frm_black_list_code_id = blackListCustStep2.fk_frm_black_list_code_id;
                                    frmBlackListLog.fk_customer_information_id = blackListCustStep2.fk_customer_information_id;
                                    frmBlackListLog.is_active = true;
                                    frmBlackListLog.fk_status_id = (int)EnumList.CCApplicationStatus.FRPending;
                                    frmBlackListLog.fk_type_id = 1;
                                    frmBlackListLog.created_by = pID;
                                    frmBlackListLog.created_date = DateTime.Now;

                                    result = false;
                                }
                                #endregion

                                if (result)
                                {
                                    var blackListCustStep3 = context.frm_black_list_customer
                                        .Where(x => x.fk_customer_information_id == customerId).ToList();

                                    if (blackListCustStep3 != null && blackListCustStep3.Count > 0)
                                    {
                                        #region step 3: Check blacklist customer by CustomerName && DOB
                                        message = "The customer with name " + customer.full_name + " & DOB " + customer.dob.ToString()
                                          + " are in blacklist exist in BLACK LIST. The case will be automatically transfered to Fraud team queue for review.";
                                        frmBlackListLog.fk_status_id = (int)EnumList.CCApplicationStatus.FRPending;

                                        frm_investigave frmInvestStep3 = new frm_investigave();

                                        frmInvestStep3.fk_application_information_id = appId;
                                        frmInvestStep3.ReferedBy = pID;
                                        frmInvestStep3.ReferedDate = DateTime.Now;
                                        frmInvestStep3.ReferedChannel = "Check automactic";
                                        frmInvestStep3.fk_customer_information_id = customerId;
                                        foreach (customer_identification item in ccIdens)
                                        {
                                            switch (item.fk_m_identification_type_id)
                                            {
                                                //case "ID": frmInvestStep3.PersonalNo = item.IdentificationNo; break;
                                                //case "Passport": frmInvestStep3.PassportNo = item.IdentificationNo; break;
                                                //case "Previous_ID": frmInvestStep3.PreviousNo = item.IdentificationNo; break;
                                                //case "Previous_PP": frmInvestStep3.SocialNo = item.IdentificationNo; break;
                                            }
                                        }

                                        frmInvestStep3.fk_status_id = (int)EnumList.CCApplicationStatus.FRPending;
                                        frmInvestStep3.SummaryInvestigation = "Check Black list automatic with name "
                                        + customer.full_name + " & DOB " + customer.dob.ToString();
                                        frmInvestStep3.fk_m_investigave_type_id = (int)EnumList.FRMInvestigaveType.PreApprovalEscalation;

                                        context.frm_investigave.Add(frmInvestStep3);
                                        context.SaveChanges();

                                        result = false;
                                        #endregion
                                    }
                                    else
                                    {
                                        result = true;

                                        customer.fk_status_id = (int)EnumList.CustomerStatus.Active;
                                        customer.is_active = true;

                                        context.customer_information.Attach(customer);
                                        context.Entry(customer).State = EntityState.Modified;
                                        context.SaveChanges();
                                    }
                                }
                            }

                            if (!result)
                            {
                                context.frm_black_list_log.Add(frmBlackListLog);
                                context.SaveChanges();

                                blackListStatus = context.m_status.Where(x => x.pk_id == frmBlackListLog.fk_status_id).FirstOrDefault().name;
                            }
                        }

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        //string errorMSG = string.Format("CheckBlackList::{0}::{1}", appNo, ex);
                        //Logger.Error(errorMSG);
                        transaction.Rollback();
                    }

                    return result;
                }
            }
        }

        /// <summary>
        /// CheckBlackList
        /// </summary>
        /// <param name="custID"></param>
        /// <param name="customerName"></param>
        /// <param name="customerStatus"></param>
        /// <param name="customerID"></param>
        /// <param name="customerPrevID"></param>
        /// <param name="dOB"></param>
        /// <param name="companyCode"></param>
        /// <param name="message"></param>
        /// <param name="blackListStatus"></param>
        /// <returns></returns>
        public static bool CheckBlackList(int appId, int customerId, int customerPrevId, DateTime dOB, int companyCodeId, string companyCode,
            ref string message, ref int blackListStatus)
        {
            bool result = true;
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        int customerStatusId = (int)_LITSEntities.customer_information.Where(x => x.pk_id == customerId).FirstOrDefault().fk_status_id;
                        if (customerStatusId != (int)EnumList.CustomerStatus.Active)
                        {
                            #region step 1: Check blacklist company by CompanyCode
                            if (companyCodeId > 0)
                            {
                                var blackListCom = context.frm_black_list_company.Where(x => x.fk_m_company_code_id == companyCodeId).FirstOrDefault();

                                if (blackListCom != null)
                                {
                                    // Application rejected by Company Black List Code
                                    message = "The application rejected by Company Black List Code: " + blackListCom.fk_frm_black_list_code_id;
                                    result = false;
                                }
                            }
                            #endregion

                            #region step 2: Check blacklist customer by CustomerID
                            if (result)
                            {
                                var blackListCustStep2 = context.frm_black_list_customer.Where(x => x.fk_customer_information_id == customerId).FirstOrDefault();

                                if (blackListCustStep2 != null)
                                {
                                    string[] arrBlackCustCodeForever = "IF|CF|RF|SF|D|DRP|Settlement|RL|LL".Split('|');
                                    string[] arrBlackCustCodeWarning = "RR|O".Split('|');

                                    if (Array.IndexOf(arrBlackCustCodeForever, blackListCustStep2.fk_frm_black_list_code_id) != -1)
                                    {
                                        message = "The customer with ID number ["
                                            + blackListCustStep2.fk_customer_information_id
                                            + "] is in BLACK LIST. Hence, you are not allowed to submit application for this customer";
                                    }
                                    else if (Array.IndexOf(arrBlackCustCodeWarning, blackListCustStep2.fk_frm_black_list_code_id) != -1)
                                    {
                                        message = "Investigave|The customer ID number ["
                                          + blackListCustStep2.fk_customer_information_id + "] are in blacklist with type ["
                                          + blackListCustStep2.fk_frm_black_list_code_id
                                          + "] exist in BLACK LIST. The case will be automatically transfered to Fraud team queue for review";
                                    }
                                    result = false;
                                }
                            }
                            #endregion

                            if (result)
                            {
                                #region step 3: Check blacklist customer by CustomerName && DOB
                                var customer = context.customer_information.Where(x => x.pk_id == customerId).FirstOrDefault();
                                var blackListCustStep3 = context.frm_black_list_customer.Where(x => x.fk_customer_information_id == customerId).ToList();

                                if (blackListCustStep3 != null && blackListCustStep3.Count > 0)
                                {
                                    message = "Investigave|The customer with name ["
                                      + customer.full_name + "] & DOB [" + customer.dob.ToString()
                                      + "] are in blacklist exist in BLACK LIST. The case will be automatically transfered to Fraud team queue for review";

                                    result = false;
                                }
                                else
                                {
                                    result = true;

                                    var cust = context.customer_information.Where(x => x.pk_id == customerId).FirstOrDefault();
                                    cust.fk_status_id = (int)EnumList.CustomerStatus.Active;
                                    cust.is_active = true;

                                    context.customer_information.Attach(cust);
                                    context.Entry(cust).State = EntityState.Modified;
                                    context.SaveChanges();
                                }
                                #endregion
                            }
                        }

                        context.Commit();
                    }
                    catch (Exception ex)
                    {
                        string errorMSG = string.Format("CheckBlackList::{0}", ex);
                        //Logger.Error(errorMSG);
                        transaction.Rollback();
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="appNo"></param>
        /// <returns></returns>
        public static bool ApplicationIsFraud(int appId)
        {
            using (var context = new LITSEntities())
            {
                var frmInvestigave = context.frm_investigave.Where(x => x.fk_application_information_id == appId).FirstOrDefault();
                if (frmInvestigave != null && !string.IsNullOrEmpty(frmInvestigave.CheckerBy)
                  && frmInvestigave.fk_status_id == (int)EnumList.CCApplicationStatus.FRFinal
                  && frmInvestigave.InvestigatorResult == "Fraud")
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// CaculteExpiredDate
        /// </summary>
        /// <param name="typeID"></param>
        /// <param name="issueDate"></param>
        /// <returns></returns>
        public static DateTime CaculteExpiredDate(string typeID, DateTime? issueDate)
        {
            if (typeID == "ID" || typeID == "Previous_ID")
            {
                return ((DateTime)issueDate).AddYears(15);
            }
            else if (typeID == "Passport" || typeID == "Previous_PP")
            {
                return ((DateTime)issueDate).AddYears(10);
            }

            return DateTime.Now;
        }

        /// <summary>
        /// GetApplicationNextAppNo
        /// </summary>
        /// <param name="AnchorProduct"></param>
        /// <param name="dtApp"></param>
        /// <returns></returns>
        public static string GetApplicationNextAppNo(string AnchorProduct, DateTime dtApp)
        {
            string ApplicationNo = string.Empty;

            int NewAppNumber = Int32.Parse(_LITSEntities.application_information.
                Where(x => x.application_no.Substring(0, 2) == AnchorProduct)
                .OrderByDescending(c => c.pk_id)
                .FirstOrDefault()
                .application_no.Substring(12, 9)) + 1;

            return ApplicationNo = AnchorProduct + dtApp.ToString("ddMMyyyy") + NewAppNumber.ToString("D9");
        }
    }
}
