﻿using System;
using System.Collections.Generic;
using PagedList;
using System.Linq;
using System.Data.Entity;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Core.Resources;
using LITS.Interface.Repository.AutoLoan.LendingOperation;
using LITS.Model.Views.AutoLoan;
using LITS.Model.PartialViews.AutoLoan.LendingOperation;
using LITS.Model.Domain.Main;
using LITS.Core.Main;

namespace LITS.Data.Repository.AutoLoan.LendingOperation
{
    public class DisbursementInformationRepository : RepositoryBase<DisbursementInformationViewModel>, IDisbursementInformationRepository
    {
        private readonly LITSEntities _LITSEntities;

        public DisbursementInformationRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(DisbursementInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(DisbursementInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<DisbursementInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public DisbursementInformationViewModel Get(Expression<Func<DisbursementInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<DisbursementInformationViewModel> GetMany(Expression<Func<DisbursementInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<DisbursementInformationViewModel> GetPage<TOrder>(Page page, Expression<Func<DisbursementInformationViewModel, bool>> where, Expression<Func<DisbursementInformationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(DisbursementInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public DisbursementInformationViewModel LoadIndex(DisbursementInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            //var varApp = _LITSEntities.application_information
            //    .FirstOrDefault(p => p.pk_id == objParam.ApplicationInformationID);

            //if (varApp != null)
            //    objParam = AutoMapper.Mapper.Map<application_information, DisbursementInformationViewModel>(varApp);

            //var varAppDup = _LITSEntities.application_duplication
            //    .Where(x => x.fk_application_information_id == objParam.ApplicationInformationID)
            //    .ToList();
            //if (varAppDup != null)
            //{
            //    foreach (application_duplication obj in varAppDup)
            //    {
            //        ApplicationDuplicationViewModel ad = new ApplicationDuplicationViewModel();
            //        ad.ApplicationInformationDuplicationID = (int)obj.fk_application_information_duplication_id;
            //        ad.ApplicationInformationID = obj.pk_id;
            //        ad.ApplicationNo = obj.application_no;
            //        ad.DuplicationTypeID = obj.fk_m_duplication_type_id;
            //        ad.StatusID = obj.fk_status_id;
            //        ad.ApplicationTypeID = obj.fk_type_id;
            //        ad.CreatedBy = obj.created_by;
            //        ad.CreatedDate = obj.created_date;

            //        objParam._ApplicationDuplicationViewModel.Add(ad);
            //    }
            //}

            return objParam;
        }

        public DisbursementInformationViewModel Save(DisbursementInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }
        #endregion
    }
}
