﻿using System;
using PagedList;
using System.Linq;
using System.Collections.Generic;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.OperationSupport;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;
using LITS.Infrastructure.Context;
using LITS.Model.Domain.Main;

namespace LITS.Data.Repository.AutoLoan.OperationSupport
{
    public class CustomerCreditBureauRepository : RepositoryBase<CustomerCreditBureauViewModel>, ICustomerCreditBureauRepository
    {
        private readonly LITSEntities _LITSEntities;

        public CustomerCreditBureauRepository(IDatabaseFactory databaseFactory,
            LITSEntities Entities)
            : base(databaseFactory)
        {
            this._LITSEntities = Entities;
        }

        #region Base

        public void Add(CustomerCreditBureauViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(CustomerCreditBureauViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<CustomerCreditBureauViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public CustomerCreditBureauViewModel Get(Expression<Func<CustomerCreditBureauViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<CustomerCreditBureauViewModel> GetMany(Expression<Func<CustomerCreditBureauViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<CustomerCreditBureauViewModel> GetPage<TOrder>(Page page, Expression<Func<CustomerCreditBureauViewModel, bool>> where, Expression<Func<CustomerCreditBureauViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(CustomerCreditBureauViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public CustomerCreditBureauViewModel LoadIndex(CustomerCreditBureauViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            //var varApp = _LITSEntities.application_information
            //    .FirstOrDefault(p => p.pk_id == objParam.ApplicationInformationID);

            //if (varApp != null)
            //    objParam = AutoMapper.Mapper.Map<application_information, CustomerCreditBureauViewModel>(varApp);

            //var varAppDup = _LITSEntities.application_duplication
            //    .Where(x => x.fk_application_information_id == objParam.ApplicationInformationID)
            //    .ToList();
            //if (varAppDup != null)
            //{
            //    foreach (application_duplication obj in varAppDup)
            //    {
            //        ApplicationDuplicationViewModel ad = new ApplicationDuplicationViewModel();
            //        ad.ApplicationInformationDuplicationID = (int)obj.fk_application_information_duplication_id;
            //        ad.ApplicationInformationID = obj.pk_id;
            //        ad.ApplicationNo = obj.application_no;
            //        ad.DuplicationTypeID = obj.fk_m_duplication_type_id;
            //        ad.StatusID = obj.fk_status_id;
            //        ad.ApplicationTypeID = obj.fk_type_id;
            //        ad.CreatedBy = obj.created_by;
            //        ad.CreatedDate = obj.created_date;

            //        objParam._ApplicationDuplicationViewModel.Add(ad);
            //    }
            //}

            return objParam;
        }

        public CustomerCreditBureauViewModel Save(CustomerCreditBureauViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        #endregion
    }
}
