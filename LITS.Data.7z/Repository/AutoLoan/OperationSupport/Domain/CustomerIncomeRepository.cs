﻿using System;
using PagedList;
using System.Linq;
using System.Collections.Generic;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.OperationSupport;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;
using LITS.Infrastructure.Context;
using LITS.Model.Domain.Main;

namespace LITS.Data.Repository.AutoLoan.OperationSupport
{
    public class CustomerIncomeRepository : RepositoryBase<CustomerIncomeViewModel>, ICustomerIncomeRepository
    {
        private readonly LITSEntities _LITSEntities;

        public CustomerIncomeRepository(IDatabaseFactory databaseFactory,
            LITSEntities Entities)
            : base(databaseFactory)
        {
            this._LITSEntities = Entities;
        }

        #region Base

        public void Add(CustomerIncomeViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(CustomerIncomeViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<CustomerIncomeViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public CustomerIncomeViewModel Get(Expression<Func<CustomerIncomeViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<CustomerIncomeViewModel> GetMany(Expression<Func<CustomerIncomeViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<CustomerIncomeViewModel> GetPage<TOrder>(Page page, Expression<Func<CustomerIncomeViewModel, bool>> where, Expression<Func<CustomerIncomeViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(CustomerIncomeViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public CustomerIncomeViewModel LoadIndex(CustomerIncomeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            //var varApp = _LITSEntities.application_information
            //    .FirstOrDefault(p => p.pk_id == objParam.ApplicationInformationID);

            //if (varApp != null)
            //    objParam = AutoMapper.Mapper.Map<application_information, CustomerIncomeViewModel>(varApp);

            //var varAppDup = _LITSEntities.application_duplication
            //    .Where(x => x.fk_application_information_id == objParam.ApplicationInformationID)
            //    .ToList();
            //if (varAppDup != null)
            //{
            //    foreach (application_duplication obj in varAppDup)
            //    {
            //        ApplicationDuplicationViewModel ad = new ApplicationDuplicationViewModel();
            //        ad.ApplicationInformationDuplicationID = (int)obj.fk_application_information_duplication_id;
            //        ad.ApplicationInformationID = obj.pk_id;
            //        ad.ApplicationNo = obj.application_no;
            //        ad.DuplicationTypeID = obj.fk_m_duplication_type_id;
            //        ad.StatusID = obj.fk_status_id;
            //        ad.ApplicationTypeID = obj.fk_type_id;
            //        ad.CreatedBy = obj.created_by;
            //        ad.CreatedDate = obj.created_date;

            //        objParam._ApplicationDuplicationViewModel.Add(ad);
            //    }
            //}

            return objParam;
        }

        public CustomerIncomeViewModel Save(CustomerIncomeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        #endregion
    }
}
