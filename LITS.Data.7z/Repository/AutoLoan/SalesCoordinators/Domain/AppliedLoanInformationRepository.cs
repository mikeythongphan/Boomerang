﻿using System;
using PagedList;
using System.Linq.Expressions;
using System.Linq;
using System.Data.Entity;
using System.Collections.Generic;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class AppliedLoanInformationRepository : RepositoryBase<AppliedLoanInformationViewModel>, IAppliedLoanInformationRepository
    {
        private readonly LITSEntities _LITSEntities;

        public AppliedLoanInformationRepository(IDatabaseFactory databaseFactory,
            LITSEntities Entities)
            : base(databaseFactory)
        {
            this._LITSEntities = Entities;
        }

        #region Base

        public void Add(AppliedLoanInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(AppliedLoanInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<AppliedLoanInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public AppliedLoanInformationViewModel Get(Expression<Func<AppliedLoanInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<AppliedLoanInformationViewModel> GetMany(Expression<Func<AppliedLoanInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<AppliedLoanInformationViewModel> GetPage<TOrder>(Page page, Expression<Func<AppliedLoanInformationViewModel, bool>> where, Expression<Func<AppliedLoanInformationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(AppliedLoanInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom
        public AppliedLoanInformationViewModel LoadIndex(AppliedLoanInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            var varApp = _LITSEntities.al_personal_application
                .Where(p => p.pk_id == objParam.ApplicationInformationID && p.is_active == true).FirstOrDefault();

            if (varApp != null)
            {
                objParam.ALApplicationInformationID = varApp.pk_id;
                objParam.AmountRequested = varApp.amount_requested_vnd;
                objParam.ApplicationInformationID = varApp.fk_application_information_id;
                objParam.ApplicationStatusID = varApp.fk_status_id;
                objParam.ApplicationTypeID = varApp.fk_type_id;
                objParam.CampaignCodeID = varApp.fk_m_campaign_code_id;
                objParam.CreateBy = varApp.created_by;
                objParam.CreateDate = varApp.created_date;
                objParam.CreditDeviationID = varApp.fk_m_credit_deviation_id;
                objParam.FloatingInterestRateID = varApp.fk_m_floating_interest_rate_id;
                objParam.IsActive = varApp.is_active;
                objParam.LoanPurposeID = varApp.fk_m_loan_purpose_id;
                objParam.LTV = varApp.ltv;
                objParam.PaymentTypeID = varApp.fk_m_payment_type_id;
                objParam.ProgramTypeID = varApp.fk_m_program_type_id;
                objParam.ReasonForDeviationID = varApp.fk_m_reason_for_deviation_id;
                objParam.TenorsID = varApp.fk_m_loan_tenor_id;
            }

            return objParam;
        }

        public AppliedLoanInformationViewModel Save(AppliedLoanInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }
        #endregion
    }
}
