﻿using System;
using PagedList;
using System.Linq;
using System.Collections.Generic;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Infrastructure.Context;
using LITS.Model.Domain.Main;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class CarDealerInformationRepository : RepositoryBase<CarDealerInformationViewModel>, ICarDealerInformationRepository
    {
        private readonly LITSEntities _LITSEntities;

        public CarDealerInformationRepository(IDatabaseFactory databaseFactory,
            LITSEntities Entities) : base(databaseFactory)
        {
            this._LITSEntities = Entities;
        }

        #region Base

        public void Add(CarDealerInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(CarDealerInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<CarDealerInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public CarDealerInformationViewModel Get(Expression<Func<CarDealerInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<CarDealerInformationViewModel> GetMany(Expression<Func<CarDealerInformationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<CarDealerInformationViewModel> GetPage<TOrder>(Page page, Expression<Func<CarDealerInformationViewModel, bool>> where, Expression<Func<CarDealerInformationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(CarDealerInformationViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public CarDealerInformationViewModel LoadIndex(CarDealerInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            var varApp = (from alapp in _LITSEntities.al_personal_application
                          join status in _LITSEntities.m_status on alapp.fk_status_id equals status.pk_id
                          join type in _LITSEntities.m_type on alapp.fk_type_id equals type.pk_id
                          join dealer in _LITSEntities.al_car_dealer on alapp.fk_al_car_dealer_id equals dealer.pk_id
                          where alapp.fk_application_information_id == objParam.ApplicationInformationID
                          && alapp.is_active == true
                          select new CarDealerInformationViewModel
                          {
                              ALApplicationInformationID = alapp.pk_id,
                              ApplicationInformationID = alapp.fk_application_information_id,
                              ApplicationStatusID = alapp.fk_status_id,
                              ApplicationStatus = status.name,
                              ApplicationTypeID = alapp.fk_type_id,
                              ApplicationType = type.name,
                              CarDealerAddress = dealer.car_dealer_name,
                              CarDealerCityID = dealer.fk_car_dealer_city_id,
                              CarDealerDistrictID = dealer.fk_car_dealer_district_id,
                              CarDealerWards = dealer.car_dealer_wards,
                              CarDealerILCap = alapp.car_dealer_il_cap,
                              CarDealerPromissoryDisbursementAvailableLimit = alapp.car_dealer_promissory_disbursement_available_limit,
                              CarDealerTotalDisbursement = alapp.car_dealer_total_disbursement,
                              CarDealerPromissoryDisbursementCap = alapp.car_dealer_promissory_disbursement_cap,
                              CooperationContractActive = alapp.cooperation_contract_active,
                              CreateBy = alapp.created_by,
                              CreateDate = alapp.created_date
                          }).FirstOrDefault();

            if(varApp != null)
            {
                objParam = varApp;
            }

            return objParam;
        }

        public CarDealerInformationViewModel Save(CarDealerInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }
        #endregion
    }
}
