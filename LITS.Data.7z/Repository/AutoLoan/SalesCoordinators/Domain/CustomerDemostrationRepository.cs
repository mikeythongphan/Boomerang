﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PagedList;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class CustomerDemostrationRepository : RepositoryBase<CustomerDemostrationViewModel>, ICustomerDemostrationRepository
    {
        private LITSEntities _LITSEntities;

        public CustomerDemostrationRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(CustomerDemostrationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(CustomerDemostrationViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<CustomerDemostrationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public CustomerDemostrationViewModel Get(Expression<Func<CustomerDemostrationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<CustomerDemostrationViewModel> GetMany(Expression<Func<CustomerDemostrationViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<CustomerDemostrationViewModel> GetPage<TOrder>(Page page, Expression<Func<CustomerDemostrationViewModel, bool>> where, Expression<Func<CustomerDemostrationViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(CustomerDemostrationViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public CustomerDemostrationViewModel LoadIndex(CustomerDemostrationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            var varApp = (from alapp in _LITSEntities.al_personal_application
                          join status in _LITSEntities.m_status on alapp.fk_status_id equals status.pk_id
                          join type in _LITSEntities.m_type on alapp.fk_type_id equals type.pk_id
                          join dealer in _LITSEntities.al_car_dealer on alapp.fk_al_car_dealer_id equals dealer.pk_id
                          where alapp.fk_application_information_id == objParam.ApplicationInformationID
                          && alapp.is_active == true
                          select new CustomerDemostrationViewModel
                          {
                              ALApplicationInformationID = alapp.pk_id,
                              ApplicationInformationID = alapp.fk_application_information_id,
                              ApplicationStatusID = alapp.fk_status_id,
                              ApplicationStatus = status.name,
                              ApplicationTypeID = alapp.fk_type_id,
                              ApplicationType = type.name,
                              TotalFDvalue = alapp.total_fd_value,
                              TotalPropertyOwned = alapp.total_property_owned,
                              TotalCarOwned = alapp.total_car_owned,
                              OtherAsset = alapp.other_asset,
                              MonthlyExpenditure = alapp.monthly_expenditure_vnd,
                              CreateBy = alapp.created_by,
                              CreateDate = alapp.created_date
                          }).FirstOrDefault();

            if (varApp != null)
            {
                objParam = varApp;
            }

            return objParam;
        }

        public CustomerDemostrationViewModel Save(CustomerDemostrationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        #endregion
    }
}
