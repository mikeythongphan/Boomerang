﻿using System;
using System.Linq;
using PagedList;
using AutoMapper;
using System.Linq.Expressions;
using System.Collections.Generic;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Interface.Repository.Main.CreateNewLoan;
using LITS.Model.Views.Main;
using LITS.Model.PartialViews.Main.CreateNewLoan;

namespace LITS.Data.Repository.Main.CreateNewLoan
{
    public class CreateNewLoanStep1Repository : RepositoryBase<CreateNewLoanStep1ViewModel>, ICreateNewLoanStep1Repository
    {
        private LITSEntities _LITSEntities;

        public CreateNewLoanStep1Repository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(CreateNewLoanStep1ViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_sales_channel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<CreateNewLoanStep1ViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public CreateNewLoanStep1ViewModel Get(Expression<Func<CreateNewLoanStep1ViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<CreateNewLoanStep1ViewModel> GetMany(Expression<Func<CreateNewLoanStep1ViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<CreateNewLoanStep1ViewModel> GetPage<TOrder>(Page page, Expression<Func<CreateNewLoanStep1ViewModel, bool>> where, Expression<Func<CreateNewLoanStep1ViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(CreateNewLoanStep1ViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion




    }
}
