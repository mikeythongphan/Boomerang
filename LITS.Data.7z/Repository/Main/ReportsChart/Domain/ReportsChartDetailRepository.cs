﻿using LITS.Infrastructure.Configuration;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Main.ReportsChart;
using LITS.Model.PartialViews.Main.ReportsChart;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Data.Repository.Main.ReportsChart
{
    public class ReportsChartDetailRepository : RepositoryBase<ReportsChartDetailViewModel>, IReportsChartDetailRepository
    {
        public ReportsChartDetailRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }
    }
}
