﻿using LITS.Infrastructure.Configuration;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Main.ReportsChart;
using LITS.Model.Views.Main;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Data.Repository.Main.ReportsChart
{
    public class ReportsChartRepository : RepositoryBase<ReportsChartViewModel>, IReportsChartRepository
    {
        private LITSEntities _LITSEntities;

        public ReportsChartRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        public ReportsChartViewModel SearchData(ReportsChartViewModel obj, string strAreaName, string strControllerName)
        {
            throw new NotImplementedException();
        }
    }
}
