﻿using AutoMapper;
using LITS.Infrastructure.Configuration;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Main.ReportsExport;
using LITS.Model.PartialViews.Main.ReportsExport;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Data.Repository.Main.ReportsExport
{
    public class ReportsExportMasterRepository : RepositoryBase<ReportsExportMasterViewModel>, IReportsExportMasterRepository
    {
        private LITSEntities _LITSEntities;

        public ReportsExportMasterRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Custom

        public List<ReportsExportMasterCustomerViewModel> GetListCustomerLargeDatabase()
        {
            List<ReportsExportMasterCustomerViewModel> obj = new List<ReportsExportMasterCustomerViewModel>();

            obj = (
                from custinfo in _LITSEntities.customer_information.ToList()
                join custiden in _LITSEntities.customer_identification.ToList() on custinfo.pk_id equals custiden.fk_customer_information_id
                select new ReportsExportMasterCustomerViewModel
                {
                    CustomerID = custinfo.pk_id,
                    CustomerName = custinfo.full_name,
                    CustomerIdentification = custiden.identification_no
                }).ToList();

            return obj;
        }

        public List<ReportsExportMasterCompanyViewModel> GetListCompanyLargeDatabase()
        {
            List<ReportsExportMasterCompanyViewModel> obj = new List<ReportsExportMasterCompanyViewModel>();

            var data = _LITSEntities.m_company_code.Where(x => x.is_active == true).ToList();

            Mapper.Map<List<m_company_code>, List<ReportsExportMasterCompanyViewModel>>(data, obj);

            return obj;
        }

        #endregion
    }
}
