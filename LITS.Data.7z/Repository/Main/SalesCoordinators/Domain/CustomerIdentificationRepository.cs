﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Interface.Repository.Main.SalesCoordinators;

namespace LITS.Data.Repository.Main.SalesCoordinators
{
    public class CustomerIdentificationRepository: RepositoryBase<customer_identification>, ICustomerIdentificationRepository
    {
        public CustomerIdentificationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }
    }
}
