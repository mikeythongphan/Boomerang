﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Configuration;
using LITS.Model.Views.Main;
using LITS.Interface.Repository.Main.SalesCoordinators;

namespace LITS.Data.Repository.Main.SalesCoordinators
{
    public class SalesCoordinatorsRepository : RepositoryBase<SalesCoordinatorsViewModel>, ISalesCoordinatorsRepository
    {
        public SalesCoordinatorsRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        {}
    }
}
