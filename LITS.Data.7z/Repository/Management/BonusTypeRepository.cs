﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class BonusTypeRepository : RepositoryBase<BonusTypeViewModel>, IBonusTypeRepository
    {
        private LITSEntities _LITSEntities;

        public BonusTypeRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_bonus_type entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_bonus_type entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_bonus_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_bonus_type Get(Expression<Func<m_bonus_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_bonus_type> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_bonus_type GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_bonus_type GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_bonus_type> GetMany(Expression<Func<m_bonus_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_bonus_type> GetPage<TOrder>(Page page, Expression<Func<m_bonus_type, bool>> where, Expression<Func<m_bonus_type, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_bonus_type entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<BonusTypeViewModel> GetListActiveAll()
        {
            List<m_bonus_type> bankHolidayList = _LITSEntities.m_bonus_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<BonusTypeViewModel> resultList = new List<BonusTypeViewModel>();
            foreach (m_bonus_type temp in bankHolidayList)
            {
                BonusTypeViewModel data = Mapper.Map<m_bonus_type, BonusTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BonusTypeViewModel> GetListActiveById(int? Id)
        {
            List<m_bonus_type> bankHolidayList = _LITSEntities.m_bonus_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<BonusTypeViewModel> resultList = new List<BonusTypeViewModel>();
            foreach (m_bonus_type temp in bankHolidayList)
            {
                BonusTypeViewModel data = Mapper.Map<m_bonus_type, BonusTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BonusTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_bonus_type> bankHolidayList = _LITSEntities.m_bonus_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<BonusTypeViewModel> resultList = new List<BonusTypeViewModel>();
            foreach (m_bonus_type temp in bankHolidayList)
            {
                BonusTypeViewModel data = Mapper.Map<m_bonus_type, BonusTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BonusTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_bonus_type> bankHolidayList = _LITSEntities.m_bonus_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<BonusTypeViewModel> resultList = new List<BonusTypeViewModel>();
            foreach (m_bonus_type temp in bankHolidayList)
            {
                BonusTypeViewModel data = Mapper.Map<m_bonus_type, BonusTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BonusTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_bonus_type> bankHolidayList = _LITSEntities.m_bonus_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<BonusTypeViewModel> resultList = new List<BonusTypeViewModel>();
            foreach (m_bonus_type temp in bankHolidayList)
            {
                BonusTypeViewModel data = Mapper.Map<m_bonus_type, BonusTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BonusTypeViewModel> GetListAll()
        {
            List<m_bonus_type> bankHolidayList = _LITSEntities.m_bonus_type.ToList();
            List<BonusTypeViewModel> resultList = new List<BonusTypeViewModel>();
            foreach (m_bonus_type temp in bankHolidayList)
            {
                BonusTypeViewModel data = Mapper.Map<m_bonus_type, BonusTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BonusTypeViewModel> GetListById(int? Id)
        {
            List<m_bonus_type> bankHolidayList = _LITSEntities.m_bonus_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<BonusTypeViewModel> resultList = new List<BonusTypeViewModel>();
            foreach (m_bonus_type temp in bankHolidayList)
            {
                BonusTypeViewModel data = Mapper.Map<m_bonus_type, BonusTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BonusTypeViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_bonus_type> bankHolidayList = _LITSEntities.m_bonus_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<BonusTypeViewModel> resultList = new List<BonusTypeViewModel>();
            foreach (m_bonus_type temp in bankHolidayList)
            {
                BonusTypeViewModel data = Mapper.Map<m_bonus_type, BonusTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BonusTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_bonus_type> bankHolidayList = _LITSEntities.m_bonus_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<BonusTypeViewModel> resultList = new List<BonusTypeViewModel>();
            foreach (m_bonus_type temp in bankHolidayList)
            {
                BonusTypeViewModel data = Mapper.Map<m_bonus_type, BonusTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BonusTypeViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_bonus_type> bankHolidayList = _LITSEntities.m_bonus_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<BonusTypeViewModel> resultList = new List<BonusTypeViewModel>();
            foreach (m_bonus_type temp in bankHolidayList)
            {
                BonusTypeViewModel data = Mapper.Map<m_bonus_type, BonusTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(BonusTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<BonusTypeViewModel, m_bonus_type>(model[0]);
                            data.is_active = false;
                            context.m_bonus_type.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(BonusTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_bonus_type data = AutoMapper.Mapper.Map<BonusTypeViewModel, m_bonus_type>(objModel);
                        context.m_bonus_type.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(BonusTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_bonus_type data = Mapper.Map<BonusTypeViewModel, m_bonus_type>(objModel);
                        context.m_bonus_type.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
