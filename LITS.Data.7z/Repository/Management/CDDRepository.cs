﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class CDDRepository : RepositoryBase<CDDViewModel>, ICDDRepository
    {
        private LITSEntities _LITSEntities;

        public CDDRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_cdd entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_cdd entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_cdd, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_cdd Get(Expression<Func<m_cdd, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_cdd> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_cdd GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_cdd GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_cdd> GetMany(Expression<Func<m_cdd, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_cdd> GetPage<TOrder>(Page page, Expression<Func<m_cdd, bool>> where, Expression<Func<m_cdd, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_cdd entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<CDDViewModel> GetListActiveAll()
        {
            List<m_cdd> bankHolidayList = _LITSEntities.m_cdd.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<CDDViewModel> resultList = new List<CDDViewModel>();
            foreach (m_cdd temp in bankHolidayList)
            {
                CDDViewModel data = Mapper.Map<m_cdd, CDDViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CDDViewModel> GetListActiveById(int? Id)
        {
            List<m_cdd> bankHolidayList = _LITSEntities.m_cdd.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<CDDViewModel> resultList = new List<CDDViewModel>();
            foreach (m_cdd temp in bankHolidayList)
            {
                CDDViewModel data = Mapper.Map<m_cdd, CDDViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CDDViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_cdd> bankHolidayList = _LITSEntities.m_cdd.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<CDDViewModel> resultList = new List<CDDViewModel>();
            foreach (m_cdd temp in bankHolidayList)
            {
                CDDViewModel data = Mapper.Map<m_cdd, CDDViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CDDViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_cdd> bankHolidayList = _LITSEntities.m_cdd.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CDDViewModel> resultList = new List<CDDViewModel>();
            foreach (m_cdd temp in bankHolidayList)
            {
                CDDViewModel data = Mapper.Map<m_cdd, CDDViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CDDViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_cdd> bankHolidayList = _LITSEntities.m_cdd.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<CDDViewModel> resultList = new List<CDDViewModel>();
            foreach (m_cdd temp in bankHolidayList)
            {
                CDDViewModel data = Mapper.Map<m_cdd, CDDViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CDDViewModel> GetListAll()
        {
            List<m_cdd> bankHolidayList = _LITSEntities.m_cdd.ToList();
            List<CDDViewModel> resultList = new List<CDDViewModel>();
            foreach (m_cdd temp in bankHolidayList)
            {
                CDDViewModel data = Mapper.Map<m_cdd, CDDViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CDDViewModel> GetListById(int? Id)
        {
            List<m_cdd> bankHolidayList = _LITSEntities.m_cdd.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<CDDViewModel> resultList = new List<CDDViewModel>();
            foreach (m_cdd temp in bankHolidayList)
            {
                CDDViewModel data = Mapper.Map<m_cdd, CDDViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CDDViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_cdd> bankHolidayList = _LITSEntities.m_cdd.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<CDDViewModel> resultList = new List<CDDViewModel>();
            foreach (m_cdd temp in bankHolidayList)
            {
                CDDViewModel data = Mapper.Map<m_cdd, CDDViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CDDViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_cdd> bankHolidayList = _LITSEntities.m_cdd.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CDDViewModel> resultList = new List<CDDViewModel>();
            foreach (m_cdd temp in bankHolidayList)
            {
                CDDViewModel data = Mapper.Map<m_cdd, CDDViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CDDViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_cdd> bankHolidayList = _LITSEntities.m_cdd.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<CDDViewModel> resultList = new List<CDDViewModel>();
            foreach (m_cdd temp in bankHolidayList)
            {
                CDDViewModel data = Mapper.Map<m_cdd, CDDViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(CDDViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<CDDViewModel, m_cdd>(model[0]);
                            data.is_active = false;
                            context.m_cdd.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(CDDViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_cdd data = AutoMapper.Mapper.Map<CDDViewModel, m_cdd>(objModel);
                        context.m_cdd.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(CDDViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_cdd data = Mapper.Map<CDDViewModel, m_cdd>(objModel);
                        context.m_cdd.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
