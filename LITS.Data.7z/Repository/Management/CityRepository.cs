﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class CityRepository : RepositoryBase<CityViewModel>, ICityRepository
    {
        private LITSEntities _LITSEntities;

        public CityRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_city entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_city entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_city, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_city Get(Expression<Func<m_city, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_city> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_city GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_city GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_city> GetMany(Expression<Func<m_city, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_city> GetPage<TOrder>(Page page, Expression<Func<m_city, bool>> where, Expression<Func<m_city, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_city entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<CityViewModel> GetListActiveAll()
        {
            List<m_city> bankHolidayList = _LITSEntities.m_city.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<CityViewModel> resultList = new List<CityViewModel>();
            foreach (m_city temp in bankHolidayList)
            {
                CityViewModel data = Mapper.Map<m_city, CityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CityViewModel> GetListActiveById(int? Id)
        {
            List<m_city> bankHolidayList = _LITSEntities.m_city.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<CityViewModel> resultList = new List<CityViewModel>();
            foreach (m_city temp in bankHolidayList)
            {
                CityViewModel data = Mapper.Map<m_city, CityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CityViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_city> bankHolidayList = _LITSEntities.m_city.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<CityViewModel> resultList = new List<CityViewModel>();
            foreach (m_city temp in bankHolidayList)
            {
                CityViewModel data = Mapper.Map<m_city, CityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CityViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_city> bankHolidayList = _LITSEntities.m_city.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CityViewModel> resultList = new List<CityViewModel>();
            foreach (m_city temp in bankHolidayList)
            {
                CityViewModel data = Mapper.Map<m_city, CityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CityViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_city> bankHolidayList = _LITSEntities.m_city.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<CityViewModel> resultList = new List<CityViewModel>();
            foreach (m_city temp in bankHolidayList)
            {
                CityViewModel data = Mapper.Map<m_city, CityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CityViewModel> GetListAll()
        {
            List<m_city> bankHolidayList = _LITSEntities.m_city.ToList();
            List<CityViewModel> resultList = new List<CityViewModel>();
            foreach (m_city temp in bankHolidayList)
            {
                CityViewModel data = Mapper.Map<m_city, CityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CityViewModel> GetListById(int? Id)
        {
            List<m_city> bankHolidayList = _LITSEntities.m_city.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<CityViewModel> resultList = new List<CityViewModel>();
            foreach (m_city temp in bankHolidayList)
            {
                CityViewModel data = Mapper.Map<m_city, CityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CityViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_city> bankHolidayList = _LITSEntities.m_city.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<CityViewModel> resultList = new List<CityViewModel>();
            foreach (m_city temp in bankHolidayList)
            {
                CityViewModel data = Mapper.Map<m_city, CityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CityViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_city> bankHolidayList = _LITSEntities.m_city.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CityViewModel> resultList = new List<CityViewModel>();
            foreach (m_city temp in bankHolidayList)
            {
                CityViewModel data = Mapper.Map<m_city, CityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CityViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_city> bankHolidayList = _LITSEntities.m_city.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<CityViewModel> resultList = new List<CityViewModel>();
            foreach (m_city temp in bankHolidayList)
            {
                CityViewModel data = Mapper.Map<m_city, CityViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(CityViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<CityViewModel, m_city>(model[0]);
                            data.is_active = false;
                            context.m_city.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(CityViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_city data = AutoMapper.Mapper.Map<CityViewModel, m_city>(objModel);
                        context.m_city.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(CityViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_city data = Mapper.Map<CityViewModel, m_city>(objModel);
                        context.m_city.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
