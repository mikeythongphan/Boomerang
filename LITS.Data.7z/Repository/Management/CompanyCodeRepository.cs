﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class CompanyCodeRepository : RepositoryBase<CompanyCodeViewModel>, ICompanyCodeRepository
    {
        private LITSEntities _LITSEntities;
        public CompanyCodeRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_company_code entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_company_code entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_company_code, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_company_code Get(Expression<Func<m_company_code, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_company_code> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_company_code GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_company_code GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_company_code> GetMany(Expression<Func<m_company_code, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_company_code> GetPage<TOrder>(Page page, Expression<Func<m_company_code, bool>> where, Expression<Func<m_company_code, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_company_code entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<CompanyCodeViewModel> GetListActiveAll()
        {
            List<m_company_code> bankHolidayList = _LITSEntities.m_company_code.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<CompanyCodeViewModel> resultList = new List<CompanyCodeViewModel>();
            foreach (m_company_code temp in bankHolidayList)
            {
                CompanyCodeViewModel data = Mapper.Map<m_company_code, CompanyCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CompanyCodeViewModel> GetListActiveById(int? Id)
        {
            List<m_company_code> bankHolidayList = _LITSEntities.m_company_code.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<CompanyCodeViewModel> resultList = new List<CompanyCodeViewModel>();
            foreach (m_company_code temp in bankHolidayList)
            {
                CompanyCodeViewModel data = Mapper.Map<m_company_code, CompanyCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CompanyCodeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_company_code> bankHolidayList = _LITSEntities.m_company_code.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<CompanyCodeViewModel> resultList = new List<CompanyCodeViewModel>();
            foreach (m_company_code temp in bankHolidayList)
            {
                CompanyCodeViewModel data = Mapper.Map<m_company_code, CompanyCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CompanyCodeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_company_code> bankHolidayList = _LITSEntities.m_company_code.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CompanyCodeViewModel> resultList = new List<CompanyCodeViewModel>();
            foreach (m_company_code temp in bankHolidayList)
            {
                CompanyCodeViewModel data = Mapper.Map<m_company_code, CompanyCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CompanyCodeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_company_code> bankHolidayList = _LITSEntities.m_company_code.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<CompanyCodeViewModel> resultList = new List<CompanyCodeViewModel>();
            foreach (m_company_code temp in bankHolidayList)
            {
                CompanyCodeViewModel data = Mapper.Map<m_company_code, CompanyCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CompanyCodeViewModel> GetListAll()
        {
            List<m_company_code> bankHolidayList = _LITSEntities.m_company_code.ToList();
            List<CompanyCodeViewModel> resultList = new List<CompanyCodeViewModel>();
            foreach (m_company_code temp in bankHolidayList)
            {
                CompanyCodeViewModel data = Mapper.Map<m_company_code, CompanyCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CompanyCodeViewModel> GetListById(int? Id)
        {
            List<m_company_code> bankHolidayList = _LITSEntities.m_company_code.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<CompanyCodeViewModel> resultList = new List<CompanyCodeViewModel>();
            foreach (m_company_code temp in bankHolidayList)
            {
                CompanyCodeViewModel data = Mapper.Map<m_company_code, CompanyCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CompanyCodeViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_company_code> bankHolidayList = _LITSEntities.m_company_code.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<CompanyCodeViewModel> resultList = new List<CompanyCodeViewModel>();
            foreach (m_company_code temp in bankHolidayList)
            {
                CompanyCodeViewModel data = Mapper.Map<m_company_code, CompanyCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CompanyCodeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_company_code> bankHolidayList = _LITSEntities.m_company_code.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CompanyCodeViewModel> resultList = new List<CompanyCodeViewModel>();
            foreach (m_company_code temp in bankHolidayList)
            {
                CompanyCodeViewModel data = Mapper.Map<m_company_code, CompanyCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CompanyCodeViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_company_code> bankHolidayList = _LITSEntities.m_company_code.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<CompanyCodeViewModel> resultList = new List<CompanyCodeViewModel>();
            foreach (m_company_code temp in bankHolidayList)
            {
                CompanyCodeViewModel data = Mapper.Map<m_company_code, CompanyCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(CompanyCodeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<CompanyCodeViewModel, m_company_code>(model[0]);
                            data.is_active = false;
                            context.m_company_code.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(CompanyCodeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_company_code data = AutoMapper.Mapper.Map<CompanyCodeViewModel, m_company_code>(objModel);
                        context.m_company_code.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(CompanyCodeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_company_code data = Mapper.Map<CompanyCodeViewModel, m_company_code>(objModel);
                        context.m_company_code.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
