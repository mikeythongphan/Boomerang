﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class CustomerSegmentRepository : RepositoryBase<CustomerSegmentViewModel>, ICustomerSegmentRepository
    {
        private LITSEntities _LITSEntities;

        public CustomerSegmentRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_customer_segment entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_customer_segment entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_customer_segment, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_customer_segment Get(Expression<Func<m_customer_segment, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_customer_segment> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_customer_segment GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_customer_segment GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_customer_segment> GetMany(Expression<Func<m_customer_segment, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_customer_segment> GetPage<TOrder>(Page page, Expression<Func<m_customer_segment, bool>> where, Expression<Func<m_customer_segment, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_customer_segment entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<CustomerSegmentViewModel> GetListActiveAll()
        {
            List<m_customer_segment> bankHolidayList = _LITSEntities.m_customer_segment.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<CustomerSegmentViewModel> resultList = new List<CustomerSegmentViewModel>();
            foreach (m_customer_segment temp in bankHolidayList)
            {
                CustomerSegmentViewModel data = Mapper.Map<m_customer_segment, CustomerSegmentViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustomerSegmentViewModel> GetListActiveById(int? Id)
        {
            List<m_customer_segment> bankHolidayList = _LITSEntities.m_customer_segment.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<CustomerSegmentViewModel> resultList = new List<CustomerSegmentViewModel>();
            foreach (m_customer_segment temp in bankHolidayList)
            {
                CustomerSegmentViewModel data = Mapper.Map<m_customer_segment, CustomerSegmentViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustomerSegmentViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_customer_segment> bankHolidayList = _LITSEntities.m_customer_segment.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<CustomerSegmentViewModel> resultList = new List<CustomerSegmentViewModel>();
            foreach (m_customer_segment temp in bankHolidayList)
            {
                CustomerSegmentViewModel data = Mapper.Map<m_customer_segment, CustomerSegmentViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustomerSegmentViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_customer_segment> bankHolidayList = _LITSEntities.m_customer_segment.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CustomerSegmentViewModel> resultList = new List<CustomerSegmentViewModel>();
            foreach (m_customer_segment temp in bankHolidayList)
            {
                CustomerSegmentViewModel data = Mapper.Map<m_customer_segment, CustomerSegmentViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustomerSegmentViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_customer_segment> bankHolidayList = _LITSEntities.m_customer_segment.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<CustomerSegmentViewModel> resultList = new List<CustomerSegmentViewModel>();
            foreach (m_customer_segment temp in bankHolidayList)
            {
                CustomerSegmentViewModel data = Mapper.Map<m_customer_segment, CustomerSegmentViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustomerSegmentViewModel> GetListAll()
        {
            List<m_customer_segment> bankHolidayList = _LITSEntities.m_customer_segment.ToList();
            List<CustomerSegmentViewModel> resultList = new List<CustomerSegmentViewModel>();
            foreach (m_customer_segment temp in bankHolidayList)
            {
                CustomerSegmentViewModel data = Mapper.Map<m_customer_segment, CustomerSegmentViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustomerSegmentViewModel> GetListById(int? Id)
        {
            List<m_customer_segment> bankHolidayList = _LITSEntities.m_customer_segment.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<CustomerSegmentViewModel> resultList = new List<CustomerSegmentViewModel>();
            foreach (m_customer_segment temp in bankHolidayList)
            {
                CustomerSegmentViewModel data = Mapper.Map<m_customer_segment, CustomerSegmentViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustomerSegmentViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_customer_segment> bankHolidayList = _LITSEntities.m_customer_segment.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<CustomerSegmentViewModel> resultList = new List<CustomerSegmentViewModel>();
            foreach (m_customer_segment temp in bankHolidayList)
            {
                CustomerSegmentViewModel data = Mapper.Map<m_customer_segment, CustomerSegmentViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustomerSegmentViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_customer_segment> bankHolidayList = _LITSEntities.m_customer_segment.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CustomerSegmentViewModel> resultList = new List<CustomerSegmentViewModel>();
            foreach (m_customer_segment temp in bankHolidayList)
            {
                CustomerSegmentViewModel data = Mapper.Map<m_customer_segment, CustomerSegmentViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustomerSegmentViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_customer_segment> bankHolidayList = _LITSEntities.m_customer_segment.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<CustomerSegmentViewModel> resultList = new List<CustomerSegmentViewModel>();
            foreach (m_customer_segment temp in bankHolidayList)
            {
                CustomerSegmentViewModel data = Mapper.Map<m_customer_segment, CustomerSegmentViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(CustomerSegmentViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<CustomerSegmentViewModel, m_customer_segment>(model[0]);
                            data.is_active = false;
                            context.m_customer_segment.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(CustomerSegmentViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_customer_segment data = AutoMapper.Mapper.Map<CustomerSegmentViewModel, m_customer_segment>(objModel);
                        context.m_customer_segment.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(CustomerSegmentViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_customer_segment data = Mapper.Map<CustomerSegmentViewModel, m_customer_segment>(objModel);
                        context.m_customer_segment.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
