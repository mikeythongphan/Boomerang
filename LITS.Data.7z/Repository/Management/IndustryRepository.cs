﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class IndustryRepository : RepositoryBase<IndustryViewModel>, IIndustryRepository
    {
        private LITSEntities _LITSEntities;

        public IndustryRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_industry entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_industry entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_industry, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_industry Get(Expression<Func<m_industry, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_industry> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_industry GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_industry GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_industry> GetMany(Expression<Func<m_industry, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_industry> GetPage<TOrder>(Page page, Expression<Func<m_industry, bool>> where, Expression<Func<m_industry, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_industry entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<IndustryViewModel> GetListActiveAll()
        {
            List<m_industry> bankHolidayList = _LITSEntities.m_industry.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<IndustryViewModel> resultList = new List<IndustryViewModel>();
            foreach (m_industry temp in bankHolidayList)
            {
                IndustryViewModel data = Mapper.Map<m_industry, IndustryViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<IndustryViewModel> GetListActiveById(int? Id)
        {
            List<m_industry> bankHolidayList = _LITSEntities.m_industry.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<IndustryViewModel> resultList = new List<IndustryViewModel>();
            foreach (m_industry temp in bankHolidayList)
            {
                IndustryViewModel data = Mapper.Map<m_industry, IndustryViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<IndustryViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_industry> bankHolidayList = _LITSEntities.m_industry.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<IndustryViewModel> resultList = new List<IndustryViewModel>();
            foreach (m_industry temp in bankHolidayList)
            {
                IndustryViewModel data = Mapper.Map<m_industry, IndustryViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<IndustryViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_industry> bankHolidayList = _LITSEntities.m_industry.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<IndustryViewModel> resultList = new List<IndustryViewModel>();
            foreach (m_industry temp in bankHolidayList)
            {
                IndustryViewModel data = Mapper.Map<m_industry, IndustryViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<IndustryViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_industry> bankHolidayList = _LITSEntities.m_industry.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<IndustryViewModel> resultList = new List<IndustryViewModel>();
            foreach (m_industry temp in bankHolidayList)
            {
                IndustryViewModel data = Mapper.Map<m_industry, IndustryViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<IndustryViewModel> GetListAll()
        {
            List<m_industry> bankHolidayList = _LITSEntities.m_industry.ToList();
            List<IndustryViewModel> resultList = new List<IndustryViewModel>();
            foreach (m_industry temp in bankHolidayList)
            {
                IndustryViewModel data = Mapper.Map<m_industry, IndustryViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<IndustryViewModel> GetListById(int? Id)
        {
            List<m_industry> bankHolidayList = _LITSEntities.m_industry.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<IndustryViewModel> resultList = new List<IndustryViewModel>();
            foreach (m_industry temp in bankHolidayList)
            {
                IndustryViewModel data = Mapper.Map<m_industry, IndustryViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<IndustryViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_industry> bankHolidayList = _LITSEntities.m_industry.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<IndustryViewModel> resultList = new List<IndustryViewModel>();
            foreach (m_industry temp in bankHolidayList)
            {
                IndustryViewModel data = Mapper.Map<m_industry, IndustryViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<IndustryViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_industry> bankHolidayList = _LITSEntities.m_industry.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<IndustryViewModel> resultList = new List<IndustryViewModel>();
            foreach (m_industry temp in bankHolidayList)
            {
                IndustryViewModel data = Mapper.Map<m_industry, IndustryViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<IndustryViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_industry> bankHolidayList = _LITSEntities.m_industry.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<IndustryViewModel> resultList = new List<IndustryViewModel>();
            foreach (m_industry temp in bankHolidayList)
            {
                IndustryViewModel data = Mapper.Map<m_industry, IndustryViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(IndustryViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<IndustryViewModel, m_industry>(model[0]);
                            data.is_active = false;
                            context.m_industry.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(IndustryViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_industry data = AutoMapper.Mapper.Map<IndustryViewModel, m_industry>(objModel);
                        context.m_industry.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(IndustryViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_industry data = Mapper.Map<IndustryViewModel, m_industry>(objModel);
                        context.m_industry.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
