﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class MessageTypeRepository : RepositoryBase<MessageTypeViewModel>, IMessageTypeRepository
    {
        private LITSEntities _LITSEntities;

        public MessageTypeRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_message_type entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_message_type entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_message_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_message_type Get(Expression<Func<m_message_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_message_type> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_message_type GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_message_type GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_message_type> GetMany(Expression<Func<m_message_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_message_type> GetPage<TOrder>(Page page, Expression<Func<m_message_type, bool>> where, Expression<Func<m_message_type, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_message_type entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<MessageTypeViewModel> GetListActiveAll()
        {
            List<m_message_type> bankHolidayList = _LITSEntities.m_message_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<MessageTypeViewModel> resultList = new List<MessageTypeViewModel>();
            foreach (m_message_type temp in bankHolidayList)
            {
                MessageTypeViewModel data = Mapper.Map<m_message_type, MessageTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MessageTypeViewModel> GetListActiveById(int? Id)
        {
            List<m_message_type> bankHolidayList = _LITSEntities.m_message_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<MessageTypeViewModel> resultList = new List<MessageTypeViewModel>();
            foreach (m_message_type temp in bankHolidayList)
            {
                MessageTypeViewModel data = Mapper.Map<m_message_type, MessageTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MessageTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_message_type> bankHolidayList = _LITSEntities.m_message_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<MessageTypeViewModel> resultList = new List<MessageTypeViewModel>();
            foreach (m_message_type temp in bankHolidayList)
            {
                MessageTypeViewModel data = Mapper.Map<m_message_type, MessageTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MessageTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_message_type> bankHolidayList = _LITSEntities.m_message_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<MessageTypeViewModel> resultList = new List<MessageTypeViewModel>();
            foreach (m_message_type temp in bankHolidayList)
            {
                MessageTypeViewModel data = Mapper.Map<m_message_type, MessageTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MessageTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_message_type> bankHolidayList = _LITSEntities.m_message_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<MessageTypeViewModel> resultList = new List<MessageTypeViewModel>();
            foreach (m_message_type temp in bankHolidayList)
            {
                MessageTypeViewModel data = Mapper.Map<m_message_type, MessageTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MessageTypeViewModel> GetListAll()
        {
            List<m_message_type> bankHolidayList = _LITSEntities.m_message_type.ToList();
            List<MessageTypeViewModel> resultList = new List<MessageTypeViewModel>();
            foreach (m_message_type temp in bankHolidayList)
            {
                MessageTypeViewModel data = Mapper.Map<m_message_type, MessageTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MessageTypeViewModel> GetListById(int? Id)
        {
            List<m_message_type> bankHolidayList = _LITSEntities.m_message_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<MessageTypeViewModel> resultList = new List<MessageTypeViewModel>();
            foreach (m_message_type temp in bankHolidayList)
            {
                MessageTypeViewModel data = Mapper.Map<m_message_type, MessageTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MessageTypeViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_message_type> bankHolidayList = _LITSEntities.m_message_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<MessageTypeViewModel> resultList = new List<MessageTypeViewModel>();
            foreach (m_message_type temp in bankHolidayList)
            {
                MessageTypeViewModel data = Mapper.Map<m_message_type, MessageTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MessageTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_message_type> bankHolidayList = _LITSEntities.m_message_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<MessageTypeViewModel> resultList = new List<MessageTypeViewModel>();
            foreach (m_message_type temp in bankHolidayList)
            {
                MessageTypeViewModel data = Mapper.Map<m_message_type, MessageTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MessageTypeViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_message_type> bankHolidayList = _LITSEntities.m_message_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<MessageTypeViewModel> resultList = new List<MessageTypeViewModel>();
            foreach (m_message_type temp in bankHolidayList)
            {
                MessageTypeViewModel data = Mapper.Map<m_message_type, MessageTypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(MessageTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<MessageTypeViewModel, m_message_type>(model[0]);
                            data.is_active = false;
                            context.m_message_type.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(MessageTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_message_type data = AutoMapper.Mapper.Map<MessageTypeViewModel, m_message_type>(objModel);
                        context.m_message_type.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(MessageTypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_message_type data = Mapper.Map<MessageTypeViewModel, m_message_type>(objModel);
                        context.m_message_type.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
