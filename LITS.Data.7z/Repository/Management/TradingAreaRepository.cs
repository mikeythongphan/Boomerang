﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class TradingAreaRepository : RepositoryBase<TradingAreaViewModel>, ITradingAreaRepository
    {
        private LITSEntities _LITSEntities;

        public TradingAreaRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_trading_area entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_trading_area entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_trading_area, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_trading_area Get(Expression<Func<m_trading_area, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_trading_area> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_trading_area GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_trading_area GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_trading_area> GetMany(Expression<Func<m_trading_area, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_trading_area> GetPage<TOrder>(Page page, Expression<Func<m_trading_area, bool>> where, Expression<Func<m_trading_area, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_trading_area entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<TradingAreaViewModel> GetListActiveAll()
        {
            List<m_trading_area> bankHolidayList = _LITSEntities.m_trading_area.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<TradingAreaViewModel> resultList = new List<TradingAreaViewModel>();
            foreach (m_trading_area temp in bankHolidayList)
            {
                TradingAreaViewModel data = Mapper.Map<m_trading_area, TradingAreaViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<TradingAreaViewModel> GetListActiveById(int? Id)
        {
            List<m_trading_area> bankHolidayList = _LITSEntities.m_trading_area.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<TradingAreaViewModel> resultList = new List<TradingAreaViewModel>();
            foreach (m_trading_area temp in bankHolidayList)
            {
                TradingAreaViewModel data = Mapper.Map<m_trading_area, TradingAreaViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<TradingAreaViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_trading_area> bankHolidayList = _LITSEntities.m_trading_area.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<TradingAreaViewModel> resultList = new List<TradingAreaViewModel>();
            foreach (m_trading_area temp in bankHolidayList)
            {
                TradingAreaViewModel data = Mapper.Map<m_trading_area, TradingAreaViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<TradingAreaViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_trading_area> bankHolidayList = _LITSEntities.m_trading_area.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<TradingAreaViewModel> resultList = new List<TradingAreaViewModel>();
            foreach (m_trading_area temp in bankHolidayList)
            {
                TradingAreaViewModel data = Mapper.Map<m_trading_area, TradingAreaViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<TradingAreaViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_trading_area> bankHolidayList = _LITSEntities.m_trading_area.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<TradingAreaViewModel> resultList = new List<TradingAreaViewModel>();
            foreach (m_trading_area temp in bankHolidayList)
            {
                TradingAreaViewModel data = Mapper.Map<m_trading_area, TradingAreaViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<TradingAreaViewModel> GetListAll()
        {
            List<m_trading_area> bankHolidayList = _LITSEntities.m_trading_area.ToList();
            List<TradingAreaViewModel> resultList = new List<TradingAreaViewModel>();
            foreach (m_trading_area temp in bankHolidayList)
            {
                TradingAreaViewModel data = Mapper.Map<m_trading_area, TradingAreaViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<TradingAreaViewModel> GetListById(int? Id)
        {
            List<m_trading_area> bankHolidayList = _LITSEntities.m_trading_area.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<TradingAreaViewModel> resultList = new List<TradingAreaViewModel>();
            foreach (m_trading_area temp in bankHolidayList)
            {
                TradingAreaViewModel data = Mapper.Map<m_trading_area, TradingAreaViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<TradingAreaViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_trading_area> bankHolidayList = _LITSEntities.m_trading_area.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<TradingAreaViewModel> resultList = new List<TradingAreaViewModel>();
            foreach (m_trading_area temp in bankHolidayList)
            {
                TradingAreaViewModel data = Mapper.Map<m_trading_area, TradingAreaViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<TradingAreaViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_trading_area> bankHolidayList = _LITSEntities.m_trading_area.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<TradingAreaViewModel> resultList = new List<TradingAreaViewModel>();
            foreach (m_trading_area temp in bankHolidayList)
            {
                TradingAreaViewModel data = Mapper.Map<m_trading_area, TradingAreaViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<TradingAreaViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_trading_area> bankHolidayList = _LITSEntities.m_trading_area.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<TradingAreaViewModel> resultList = new List<TradingAreaViewModel>();
            foreach (m_trading_area temp in bankHolidayList)
            {
                TradingAreaViewModel data = Mapper.Map<m_trading_area, TradingAreaViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(TradingAreaViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<TradingAreaViewModel, m_trading_area>(model[0]);
                            data.is_active = false;
                            context.m_trading_area.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(TradingAreaViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_trading_area data = AutoMapper.Mapper.Map<TradingAreaViewModel, m_trading_area>(objModel);
                        context.m_trading_area.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(TradingAreaViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_trading_area data = Mapper.Map<TradingAreaViewModel, m_trading_area>(objModel);
                        context.m_trading_area.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
