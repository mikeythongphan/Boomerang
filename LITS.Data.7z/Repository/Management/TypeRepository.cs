﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class TypeRepository : RepositoryBase<TypeViewModel>, ITypeRepository
    {
        private LITSEntities _LITSEntities;

        public TypeRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_type entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_type entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_type Get(Expression<Func<m_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_type> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_type GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_type GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_type> GetMany(Expression<Func<m_type, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_type> GetPage<TOrder>(Page page, Expression<Func<m_type, bool>> where, Expression<Func<m_type, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_type entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<TypeViewModel> GetListActiveAll()
        {
            List<m_type> bankHolidayList = _LITSEntities.m_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<TypeViewModel> resultList = new List<TypeViewModel>();
            foreach (m_type temp in bankHolidayList)
            {
                TypeViewModel data = Mapper.Map<m_type, TypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<TypeViewModel> GetListActiveById(int? Id)
        {
            List<m_type> bankHolidayList = _LITSEntities.m_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<TypeViewModel> resultList = new List<TypeViewModel>();
            foreach (m_type temp in bankHolidayList)
            {
                TypeViewModel data = Mapper.Map<m_type, TypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<TypeViewModel> GetListByParentId(int? ParentId)
        {
            List<m_type> bankHolidayList = _LITSEntities.m_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.parent_id == ParentId).ToList();
            List<TypeViewModel> resultList = new List<TypeViewModel>();
            foreach (m_type temp in bankHolidayList)
            {
                TypeViewModel data = Mapper.Map<m_type, TypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<TypeViewModel> GetListAll()
        {
            List<m_type> bankHolidayList = _LITSEntities.m_type.ToList();
            List<TypeViewModel> resultList = new List<TypeViewModel>();
            foreach (m_type temp in bankHolidayList)
            {
                TypeViewModel data = Mapper.Map<m_type, TypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<TypeViewModel> GetListById(int? Id)
        {
            List<m_type> bankHolidayList = _LITSEntities.m_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<TypeViewModel> resultList = new List<TypeViewModel>();
            foreach (m_type temp in bankHolidayList)
            {
                TypeViewModel data = Mapper.Map<m_type, TypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<TypeViewModel> GetListActiveByParentId(int? ParentId)
        {
            List<m_type> bankHolidayList = _LITSEntities.m_type.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.parent_id == ParentId).ToList();
            List<TypeViewModel> resultList = new List<TypeViewModel>();
            foreach (m_type temp in bankHolidayList)
            {
                TypeViewModel data = Mapper.Map<m_type, TypeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }       

        public bool Delete(TypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<TypeViewModel, m_type>(model[0]);
                            data.is_active = false;
                            context.m_type.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(TypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_type data = AutoMapper.Mapper.Map<TypeViewModel, m_type>(objModel);
                        context.m_type.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(TypeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_type data = Mapper.Map<TypeViewModel, m_type>(objModel);
                        context.m_type.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
