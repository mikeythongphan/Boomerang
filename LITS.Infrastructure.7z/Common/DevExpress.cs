﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Infrastructure.Common
{
    public static class DevExpress
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="combo"></param>
        /// <param name="controlID"></param>
        //public static void SetClientIDCombobox(DevExpress.Web.ASPxComboBox combo, string controlID)
        //{
        //    combo.ClientInstanceName = string.Concat(combo.ID, controlID);
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="textbox"></param>
        /// <param name="controlID"></param>
        //public static void SetClientIDTextBox(DevExpress.Web.ASPxTextBox textbox, string controlID)
        //{
        //    textbox.ClientInstanceName = string.Concat(textbox.ID, controlID);
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="label"></param>
        /// <param name="controlID"></param>
        //public static void SetClientIDLabel(DevExpress.Web.ASPxLabel label, string controlID)
        //{
        //    label.ClientInstanceName = string.Concat(label.ID, controlID);
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="combobox"></param>
        /// <returns></returns>
        //public static bool IsNotValidComboboxValue(DevExpress.Web.ASPxComboBox combobox)
        //{
        //    if (combobox.SelectedItem == null)
        //        return true;

        //    if (combobox.SelectedItem.Value.ToString() == "-1")
        //        return true;

        //    return false;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputString"></param>
        /// <param name="combobox"></param>
        /// <returns></returns>
        //public static bool IsValidValueOfCombobox(string inputString, DevExpress.Web.ASPxComboBox combobox)
        //{
        //    if (!string.IsNullOrEmpty(inputString) && inputString != "-1")
        //        if (combobox.Items.FindByValue(inputString) != null)
        //            return true;

        //    return false;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        /// <param name="ddl"></param>
        /// <returns></returns>
        //public static bool IsValidValueDropDownList(string input, System.Web.UI.WebControls.DropDownList ddl)
        //{
        //    if (!string.IsNullOrEmpty(input) && input != "-1")
        //        if (ddl.Items.FindByValue(input) != null)
        //            return true;

        //    return false;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <param name="combobox"></param>
        //public static void LoadDefaulValuesForCombobox(string value, DevExpress.Web.ASPxComboBox combobox)
        //{
        //    if (!string.IsNullOrEmpty(value))
        //        combobox.Value = value;
        //    else
        //        combobox.Value = "-1";
        //}
    }
}
