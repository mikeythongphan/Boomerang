﻿using System;
using System.Text;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Configuration;
using System.Collections.Specialized;

namespace LITS.Infrastructure.Common
{
    public static class Email
    {
        private static XmlDataSource m_xmlData;

        #region Helpers

        private static XmlDataSource GetXmlDataSource(string usDataFile, string xmlPath)
        {
            XmlDataSource dsData = new XmlDataSource();
            dsData.DataFile = usDataFile;
            dsData.XPath = xmlPath;
            return dsData;
        }

        private static XmlDataSource GetEmailTemplateXmlData(string xmlPath)
        {
            return GetXmlDataSource("~/App_Data/MailTemplate.xml", xmlPath);
        }

        private static string LoadMailInformation()
        {
            if (m_xmlData == null)
                m_xmlData = GetEmailTemplateXmlData("email-template");

            string body = m_xmlData.GetXmlDocument().SelectSingleNode("/email-template/content").InnerText.Trim();
            if (!string.IsNullOrEmpty(body))
                return body;
            else
                return "";
        }

        #endregion

        #region SendEmail

        public static bool SendNotifyEmailSale(string from, string to, string cc, string subject, string strFullName, string strMobileNo,
            string strEmailAddress1, string strEmailAddress2, string strEmailAddress3,
          string appNo, string statusName, string remark, string sentBackCode, decimal? approvedAmount, string pwidDirectSale)
        {
            string content = LoadMailInformation();

            EmailConfirm email = new EmailConfirm();

            email.PWIDDirectSale = pwidDirectSale;
            email.AppNo = appNo;
            email.AppStatus = statusName;
            email.CustomerName = strFullName;
            email.CustomerMobile = strMobileNo;
            email.CustomerEmail = string.Format("{0}; {1}; {2}", strEmailAddress1, strEmailAddress2, strEmailAddress3);
            email.Remark = remark;
            email.SendBackCode = sentBackCode;
            email.ApprovedAmount = (approvedAmount != null ? approvedAmount.Value.ToString("N0") : string.Empty);

            content = email.FillContentToMailTemplate(content);

            if (SendMail(from, to, cc, subject, content))
                return true;

            return false;
        }

        public static bool SendMail(string from, string to, string cc, string subject, string content)
        {
            try
            {
                // To
                MailMessage mailMsg = new MailMessage();
                mailMsg.To.Add(to);

                // From
                MailAddress mailAddress = new MailAddress(from);
                mailMsg.From = mailAddress;
                if (cc != null)
                {
                    string[] listCC = cc.Split(',');
                    foreach (string ccmail in listCC)
                    {
                        if (!string.IsNullOrEmpty(ccmail) && ccmail.Contains("@"))
                            mailMsg.CC.Add(ccmail);
                    }
                }

                // Subject and Body        
                mailMsg.Subject = subject;
                mailMsg.Body = content;
                mailMsg.IsBodyHtml = true;
                mailMsg.SubjectEncoding = mailMsg.BodyEncoding = Encoding.UTF8;

                // Init SmtpClient and send
                if (!ConnectSMTPToSendMail(ConfigurationManager.AppSettings["SMTPHost"], mailMsg))
                    if (!ConnectSMTPToSendMail(ConfigurationManager.AppSettings["SMTPHostBK"], mailMsg))
                        return false;
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

        private static bool ConnectSMTPToSendMail(string host, MailMessage mailMsg)
        {
            try
            {
                SmtpClient smtpClient = new SmtpClient(host);
                smtpClient.Port = 25;

                smtpClient.UseDefaultCredentials = true;
                smtpClient.Send(mailMsg);

                return true;
            }
            catch (Exception ex)
            {
            }
            return false;
        }

        #endregion
    }

    public class EmailConfirm
    {
        private NameValueCollection fields = new NameValueCollection();

        #region Properties

        public NameValueCollection Fields
        {
            get { return fields; }
        }

        public string SeqNoMail
        {
            get { return this.Fields["#SeqNoMail#"]; }
            set { this.Fields["#SeqNoMail#"] = value; }
        }

        public string AppNo
        {
            get { return this.Fields["#AppNo#"]; }
            set { this.Fields["#AppNo#"] = value; }
        }

        public string AppStatus
        {
            get { return this.Fields["#AppStatus#"]; }
            set { this.Fields["#AppStatus#"] = value; }
        }

        public string CustomerName
        {
            get { return this.Fields["#CustomerName#"]; }
            set { this.Fields["#CustomerName#"] = value; }
        }

        public string CustomerMobile
        {
            get { return this.Fields["#CustomerMobile#"]; }
            set { this.Fields["#CustomerMobile#"] = value; }
        }

        public string CustomerEmail
        {
            get { return this.Fields["#CustomerEmail#"]; }
            set { this.Fields["#CustomerEmail#"] = value; }
        }

        public string Remark
        {
            get { return this.Fields["#Remark#"]; }
            set { this.Fields["#Remark#"] = value; }
        }

        public string SendBackCode
        {
            get { return this.Fields["#SendBackCode#"]; }
            set { this.Fields["#SendBackCode#"] = value; }
        }

        public string ApprovedAmount
        {
            get { return this.Fields["#ApprovedAmount#"]; }
            set { this.Fields["#ApprovedAmount#"] = value; }
        }

        public string PWIDDirectSale
        {
            get { return this.Fields["#PWIDDirectSale#"]; }
            set { this.Fields["#PWIDDirectSale#"] = value; }
        }

        #endregion

        #region Methods

        public string FillContentToMailTemplate(string content)
        {
            string body = "";
            // replace field name for body
            StringBuilder sb = new StringBuilder(content);
            foreach (string key in fields.Keys)
            {
                sb.Replace(key, fields[key]);
            }
            body = sb.ToString();
            return body;
        }

        #endregion
    }
}
