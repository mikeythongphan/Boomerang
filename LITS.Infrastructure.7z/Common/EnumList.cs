﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Infrastructure.Common
{
    public class EnumList
    {
        #region Status

        public enum ActiveStatus
        {
            InActive = 0,
            Active = 1
        }

        public enum CustomerStatus
        {
            Active = 0,
            BlackList = 1,
            Remodify = 2
        }

        public enum DisbursalStatus
        {
            Partly_Disbursed = 0,
            Fully_Disbursed = 1,
            Cancelled_By_Customer = 2
        }

        public enum ImportFileStatus
        {
            Successful,
            Warning,
            Failed
        }

        public enum ManagementStatus
        {
            Pending = 1,
            Active = 2,
            Delete_Pending = 3,
            InActive = 4
        }

        public enum CallCheckListStatus
        {
            NEW = 1,
            EXTRACTED = 2
        }

        public enum PendingMarkStatus
        {
            PENDING,
            CALL
        }

        public enum FraudBLStatus
        {
            Pending = 0,
            Approved = 1,
            Rejected = 2,
            Ready = 3
        }

        public enum DAStatus
        {
            Pending,
            Active,
            Pending_Active,
            Pending_InActive,
            InActive
        }

        public enum FraudInvestigationStatus
        {
            Open,
            InProgress,
            Completed,
            SentBack_ByFRM,
            Cancelled_ByApplicant
        }

        public enum FraudInvestigationResult
        {
            Pending,
            Fraud,
            NoFraud,
            PotentialFraud,
            NA
        }

        public enum ActionLogAction
        {
            FraudPending,
            FraudReleased
        }

        public enum ApplicationStatus
        {
            SCFirstEntry = 0,   // SC create customer in Create New Loan                
            SCCreated = 1,      // SC save
            SCSubmitted = 2,    // SC Submit      
            SCDeleted = 3,      // SC Delete Application
            SCRejected = 4,     // if customer in black list then SC Reject
            SCCancelled = 18,   // cancel stop calculate TAT
            OSModified = 5,    // OS modified
            OSSendBack = 6,    // OS send back to SC
            OSReject = 7,      // OS reject
            OSChecked = 8,     // OS submit 
            Approved = 9,      // OS (changed to CI) review to approved after CI recommend
            CIModified = 10,      // CI modified
            CISendBack = 11,      // CI send back to SC
            AIPCompleted = 12,    // waiting for AIP section
            Rejected = 13,        // CI Reject --> user reject
            CIRecommend = 14,     // CI Approved changed to CI Recommend (14 May 2013)
            Cancelled = 15,       // CI Cancelled --> customer reject (stop calculating TAT)
            ReturnFirstCI = 22,   // CI2 Returned CI1
            LODisbursed = 16,       // LO disburse --> Application CLOSED (DONE)      
            LORemodify = 17,        // LO remodify to LO Checker check if LO input wrong
            Resubmitted = 19,   // for rework (resubmit old application)
            AIPRecommend = 20,   // process of AIP (Maker recommend AIP for Checker Complete AIP)
            LORemodifySC = 21,       // LO re-modify data of SC page after disbursement
        }

        public enum TeleQueue
        {
            Tele_Modified,
            Tele_SentBack,
            Tele_SCModified,
            Tele_SCSubmitted,
            Tele_CIRequeue,
            Tele_Completed
        }

        public enum CRApproval
        {
            Approved = 1,
            Rejected = 2,
            Cancelled = 3,
            Pending = 4
        }
        #endregion

        #region Type

        public enum LoanType
        {
            LITS = 2,
            AutoLoan = 3,
            MortgageLoan = 4,
            PersonalLoan = 5,
            CreditCard = 6,
            AutoLoanPersonal = 7,
            AutoLoanCorporate = 8
        }

        public enum IdType
        {
            IdentityCard = 1,
            Passport = 2
        }

        public enum BlackListType
        {
            BlackListSC = 0,
            BlackListOS = 1
        }

        public enum CompanyType
        {
            NonApproved = 0,
            Approved = 1
        }

        public enum BureauType
        {
            Current,
            History
        }

        public enum ExpressType
        {
            Online,
            Secured
        }

        public enum RequeueLogType
        {
            REQUEUE,
            SENTBACK
        }

        public enum IncomeType
        {
            Salaried,
            HouseRental,
            CarRental,
            PrivateBusiness
        }

        public enum ElegibilityType
        {
            Age,
            Tenor
        }

        public enum VerifierContactType
        {
            HOME,
            OFFICE,
            REFEREE,
            MOBILE
        }

        public enum ReworkReasonType
        {
            LV,
            R,
            C_SC,
            C_CI,
            SB,
            RW,
            CC_SB,
            CC_TeleSB
        }

        public enum InvestigaveFileType
        {
            EscalationReport,
            InvestigationReport
        }

        public enum IdentificationType
        {
            ID,
            Passport,
            Previous_ID,
            Previous_PP
        }

        public enum BorrowerType
        {
            MainBorrower,
            CoBorrower1,
            CoBorrower2,
            CoBorrower3
        }

        #endregion

        #region Import File
        public enum DGTImportFileType
        {
            Data,
            CIC
        }

        public enum DGTImportFileStatus
        {
            FailedFormat,
            Success,
            Duplication,
            FailedMandantory,
            FailedRules,
            FailedBL,
            FailedCHK,
            Failed
        }
        #endregion
    }
}
