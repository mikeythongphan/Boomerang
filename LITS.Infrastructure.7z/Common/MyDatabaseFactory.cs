﻿using System;
using System.Data.Common;
using System.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace LITS.Infrastructure.Common
{
    public static class MyDatabaseFactory
    {
        private static string _connectionString;
        public static string ConnectionString
        {
            get { return MyDatabaseFactory._connectionString; }
            set { MyDatabaseFactory._connectionString = value; }
        }

        private static string _databaseName;
        public static string DatabaseName
        {
            get { return MyDatabaseFactory._databaseName; }
            set { MyDatabaseFactory._databaseName = value; }
        }

        public static Database CreateDatabase()
        {
            string dbFactory = "System.Data.SqlClient";
            Database db = null;
            try
            {
                if (!String.IsNullOrEmpty(ConnectionString))
                {
                    db = new GenericDatabase(ConnectionString, DbProviderFactories.GetFactory(dbFactory));
                }
                else
                {
                    if (String.IsNullOrEmpty(DatabaseName))
                    {
                        db = DatabaseFactory.CreateDatabase();
                    }
                    else
                    {
                        db = DatabaseFactory.CreateDatabase(DatabaseName);
                    }
                }
            }
            catch (Exception ex)
            {
            }

            return db;
        }

        public static Database CreateDatabase(string connectionString)
        {
            string dbFactory = "System.Data.SqlClient";
            Database db = null;
            try
            {
                if (!String.IsNullOrEmpty(connectionString))
                {
                    db = new GenericDatabase(connectionString, DbProviderFactories.GetFactory(dbFactory));
                }
                else
                {
                    if (String.IsNullOrEmpty(DatabaseName))
                    {
                        db = DatabaseFactory.CreateDatabase();
                    }
                    else
                    {
                        db = DatabaseFactory.CreateDatabase(DatabaseName);
                    }
                }
            }
            catch (Exception ex)
            {
            }

            return db;
        }

        public static Database CreateDatabaseAccess()
        {
            string dbFactory = "System.Data.OleDb";
            Database db = null;
            try
            {
                if (!String.IsNullOrEmpty(ConnectionString))
                {
                    db = new GenericDatabase(ConnectionString, DbProviderFactories.GetFactory(dbFactory));
                }
                else
                {
                    if (String.IsNullOrEmpty(DatabaseName))
                    {
                        db = DatabaseFactory.CreateDatabase();
                    }
                    else
                    {
                        db = DatabaseFactory.CreateDatabase(DatabaseName);
                    }
                }
            }
            catch (Exception ex)
            {
            }

            return db;
        }

        public static Database CreateDatabaseAccess(string connectionString)
        {
            string dbFactory = "System.Data.OleDb";
            Database db = null;
            try
            {
                if (!String.IsNullOrEmpty(connectionString))
                {
                    db = new GenericDatabase(connectionString, DbProviderFactories.GetFactory(dbFactory));
                }
                else
                {
                    if (String.IsNullOrEmpty(DatabaseName))
                    {
                        db = DatabaseFactory.CreateDatabase();
                    }
                    else
                    {
                        db = DatabaseFactory.CreateDatabase(DatabaseName);
                    }
                }
            }
            catch (Exception ex)
            {
            }

            return db;
        }

        public static bool TestConnection()
        {
            Database db = MyDatabaseFactory.CreateDatabase();
            try
            {
                DbConnection dbConnection = db.CreateConnection();
                dbConnection.Open();
                if (dbConnection.State == ConnectionState.Open)
                {
                    dbConnection.Close();
                    return true;
                }
                else
                {
                    dbConnection.Close();
                    return false;
                }
                return false;

            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
