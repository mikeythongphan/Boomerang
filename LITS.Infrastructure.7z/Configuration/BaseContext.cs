﻿using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace LITS.Infrastructure.Configuration
{
    public class BaseContext : DbContext, IDbContext
    {
        public Guid Id { get; set; }

        public BaseContext(string connectionStringName)
            : base(connectionStringName)
        {
            this.Id = Guid.NewGuid();

            this.Configuration.LazyLoadingEnabled = false;
            this.Configuration.ProxyCreationEnabled = false;
        }

        #region IDbContext Implementation

        public new DbEntityEntry Entry(object entity)
        {
            return base.Entry(entity);
        }

        public new DbEntityEntry<TEntity> Entry<TEntity>(TEntity entity) where TEntity : class
        {
            return base.Entry<TEntity>(entity);
        }

        public new DbSet<TEntity> Set<TEntity>() where TEntity : class
        {
            return base.Set<TEntity>();
        }

        public new DbSet Set(Type entityType)
        {
            return base.Set(entityType);
        }

        public new int SaveChanges()
        {
            return base.SaveChanges();
        }

        #endregion
    }
}
