﻿using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace LITS.Infrastructure.Configuration
{
    public interface IDbContext
    {
        Guid Id { get; set; }

        int SaveChanges();

        void Dispose();

        DbChangeTracker ChangeTracker { get; }

        DbEntityEntry Entry(object entity);

        DbEntityEntry<TEntity> Entry<TEntity>(TEntity entity) where TEntity : class;

        DbSet<TEntity> Set<TEntity>() where TEntity : class;

        DbSet Set(Type entityType);
    }
}
