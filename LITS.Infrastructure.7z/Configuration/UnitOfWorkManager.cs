﻿using System;
using System.Data.Entity;
using LITS.Infrastructure.Context;

namespace LITS.Infrastructure.Configuration
{
    public interface IUnitOfWorkManager : IDisposable
    {
        IUnitOfWork NewUnitOfWork();
    }

    public class UnitOfWorkManager : IUnitOfWorkManager
    {
        private bool _isDisposed;
        private readonly LITSEntities _context;

        public UnitOfWorkManager(LITSEntities context)
        {
            Database.SetInitializer<LITSEntities>(null);
            this._context = context as LITSEntities;
        }

        public IUnitOfWork NewUnitOfWork()
        {
            return new UnitOfWork(this._context);
        }

        public void Dispose()
        {
            if (this._isDisposed == false)
            {
                this._context.Dispose();
                this._isDisposed = true;
            }
        }
    }
}
