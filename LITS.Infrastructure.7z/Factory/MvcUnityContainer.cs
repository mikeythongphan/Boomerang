﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.Unity;

namespace LITS.Infrastructure.Factory
{
    public static class MvcUnityContainer
    {
        public static UnityContainer Container { get; set; }
    }
}
