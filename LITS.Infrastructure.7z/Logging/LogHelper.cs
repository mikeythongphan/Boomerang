﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using System.Reflection;
using System.Configuration;
using System.IO;
using System.Xml;

namespace LITS.Infrastructure.Logging
{
    public class LogHelper
    {
        private static readonly ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        /// <summary>
        /// BeautyErrorMsg
        /// </summary>
        /// <param name="ex">Exception</param>
        /// <returns>string</returns>
        private static string BeautyErrorMsg(Exception ex)
        {
            string errorMsg = string.Format("【Name】：{0} <br>【Message】：{1} <br>【StackTrace】：{2}", new object[] { ex.GetType().Name, ex.Message, ex.StackTrace });
            errorMsg = errorMsg.Replace("\r\n", "<br>");
            return errorMsg;
        }

        /// <summary>
        /// WriteLogInfo
        /// </summary>
        /// <param name="info"></param>
        public static void WriteLogInfo(string info)
        {
            if (log.IsInfoEnabled)
            {
                log.Info(info);
            }
        }

        /// <summary>
        /// WriteLogError
        /// </summary>
        /// <param name="info"></param>
        /// <param name="ex"></param>
        public static void WriteLogError(string info, Exception ex)
        {
            if (!string.IsNullOrEmpty(info) && ex == null)
            {
                log.ErrorFormat("【Extra Information】: {0}<br>", new object[] { info });
            }
            else if (!string.IsNullOrEmpty(info) && ex != null)
            {
                string errorMsg = BeautyErrorMsg(ex);
                log.ErrorFormat("【Extra Information】: {0}<br>{1}", new object[] { info, errorMsg });
            }
            else if (string.IsNullOrEmpty(info) && ex != null)
            {
                string errorMsg = BeautyErrorMsg(ex);
                log.Error(errorMsg);
            }
        }

        /// <summary>
        /// WriteLogWarning
        /// </summary>
        /// <param name="info"></param>
        public static void WriteLogWarning(string info)
        {
            if (log.IsWarnEnabled)
            {
                log.Error(info);
            }
        }

        /// <summary>
        /// WriteLogFatal
        /// </summary>
        /// <param name="info"></param>
        /// <param name="ex"></param>
        public static void WriteLogFatal(string info, Exception ex)
        {
            if (log.IsFatalEnabled)
            {
                log.Fatal(info);
            }
        }

        /// <summary>
        /// WriteLogDebug
        /// </summary>
        /// <param name="info"></param>
        /// <param name="ex"></param>
        public static void WriteLogDebug(string info, Exception ex)
        {
            if (log.IsDebugEnabled)
            {
                log.Debug(info);
            }
        }
    }
}
