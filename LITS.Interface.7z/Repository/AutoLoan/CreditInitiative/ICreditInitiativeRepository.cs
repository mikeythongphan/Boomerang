﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Model.Views.AutoLoan;

namespace LITS.Interface.Repository.AutoLoan.CreditInitiative
{
    public interface ICreditInitiativeRepository : IRepository<CreditInitiativeViewModel>
    {
        CreditInitiativeViewModel LoadIndex(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreditInitiativeViewModel Save(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreditInitiativeViewModel ByPass(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreditInitiativeViewModel SendBackSC(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreditInitiativeViewModel SendBackOS(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreditInitiativeViewModel Recommend(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreditInitiativeViewModel Reject(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreditInitiativeViewModel Cancel(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreditInitiativeViewModel Approved(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreditInitiativeViewModel ReturnCI(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreditInitiativeViewModel Print(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreditInitiativeViewModel NSG(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreditInitiativeViewModel RequeueTeleVerifier(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreditInitiativeViewModel DownloadIncomeSheet(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreditInitiativeViewModel FRMQueue(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
