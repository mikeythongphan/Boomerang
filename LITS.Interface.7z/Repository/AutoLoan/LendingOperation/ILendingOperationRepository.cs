﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Model.Views.AutoLoan;

namespace LITS.Interface.Repository.AutoLoan.LendingOperation
{
    public interface ILendingOperationRepository : IRepository<LendingOperationViewModel>
    {
        LendingOperationViewModel LoadIndex(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        LendingOperationViewModel Save(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        LendingOperationViewModel Submit(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        LendingOperationViewModel SendBackSC(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        LendingOperationViewModel LOModifySC(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        LendingOperationViewModel LOModify(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        LendingOperationViewModel PrintApprovalLetter(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        LendingOperationViewModel PrintApprovalWorksheet(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
