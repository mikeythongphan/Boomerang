﻿using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;

namespace LITS.Interface.Repository.AutoLoan.OperationSupport
{
    public interface IARTARepository : IRepository<ARTAViewModel>
    {
        ARTAViewModel LoadIndex(ARTAViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        ARTAViewModel Save(ARTAViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
