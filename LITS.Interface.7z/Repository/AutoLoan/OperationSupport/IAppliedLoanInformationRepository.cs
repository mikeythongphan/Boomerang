﻿using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;

namespace LITS.Interface.Repository.AutoLoan.OperationSupport
{
    public interface IAppliedLoanInformationRepository : IRepository<AppliedLoanInformationViewModel>
    {
        AppliedLoanInformationViewModel LoadIndex(AppliedLoanInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        AppliedLoanInformationViewModel Save(AppliedLoanInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
