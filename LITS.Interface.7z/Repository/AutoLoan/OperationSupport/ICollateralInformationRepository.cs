﻿using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;

namespace LITS.Interface.Repository.AutoLoan.OperationSupport
{
    public interface ICollateralInformationRepository : IRepository<CollateralInformationViewModel>
    {
        CollateralInformationViewModel LoadIndex(CollateralInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CollateralInformationViewModel Save(CollateralInformationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
