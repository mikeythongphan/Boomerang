﻿using System;
using LITS.Infrastructure.Factory;
using LITS.Model.Views.AutoLoan;

namespace LITS.Interface.Repository.AutoLoan.OperationSupport
{
    public interface IOperationSupportRepository : IRepository<OperationSupportViewModel>
    {
        OperationSupportViewModel LoadIndex(OperationSupportViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        OperationSupportViewModel Save(OperationSupportViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        OperationSupportViewModel Approved(OperationSupportViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        OperationSupportViewModel Reject(OperationSupportViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        OperationSupportViewModel NSG(OperationSupportViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        OperationSupportViewModel SendbackSC(OperationSupportViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        OperationSupportViewModel FRM(OperationSupportViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
