﻿using LITS.Infrastructure.Factory;
using LITS.Model.Views.AutoLoan;

namespace LITS.Interface.Repository.AutoLoan.SalesCoordinators
{
    public interface ISalesCoordinatorsRepository : IRepository<SalesCoordinatorsViewModel>
    {
        SalesCoordinatorsViewModel LoadIndex(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        SalesCoordinatorsViewModel Save (SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        SalesCoordinatorsViewModel Submit (SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        SalesCoordinatorsViewModel NSG(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        SalesCoordinatorsViewModel Cancel(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        SalesCoordinatorsViewModel Delete(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        SalesCoordinatorsViewModel FRMQueue(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
