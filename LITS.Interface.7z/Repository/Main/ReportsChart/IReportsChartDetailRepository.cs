﻿using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.Main.ReportsChart;

namespace LITS.Interface.Repository.Main.ReportsChart
{
    public interface IReportsChartDetailRepository : IRepository<ReportsChartDetailViewModel>
    {
    }
}
