﻿using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.Main.ReportsChart;
using System.Collections.Generic;

namespace LITS.Interface.Repository.Main.ReportsChart
{
    public interface IReportsChartMasterRepository : IRepository<ReportsChartMasterViewModel>
    {
        List<ReportsChartMasterCustomerViewModel> GetListCustomerLargeDatabase();
        List<ReportsChartMasterCompanyViewModel> GetListCompanyLargeDatabase();
    }
}
