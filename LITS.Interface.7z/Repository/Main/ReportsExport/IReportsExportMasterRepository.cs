﻿using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.Main.ReportsExport;
using System.Collections.Generic;

namespace LITS.Interface.Repository.Main.ReportsExport
{
    public interface IReportsExportMasterRepository : IRepository<ReportsExportMasterViewModel>
    {
        List<ReportsExportMasterCustomerViewModel> GetListCustomerLargeDatabase();
        List<ReportsExportMasterCompanyViewModel> GetListCompanyLargeDatabase();
    }
}
