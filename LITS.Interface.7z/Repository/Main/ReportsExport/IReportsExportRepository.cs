﻿using LITS.Infrastructure.Factory;
using LITS.Model.Views.Main;

namespace LITS.Interface.Repository.Main.ReportsExport
{
    public interface IReportsExportRepository : IRepository<ReportsExportViewModel>
    {
        ReportsExportViewModel SearchData(ReportsExportViewModel obj, string strAreaName, string strControllerName);
    }
}
