﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface ICompanyTypeRepository : IRepository<m_company_type>
    {
        List<CompanyTypeViewModel> GetListAll();

        List<CompanyTypeViewModel> GetListById(int? Id);

        List<CompanyTypeViewModel> GetListByStatusId(int? StatusId);

        List<CompanyTypeViewModel> GetListByTypeId(int? TypeId);

        List<CompanyTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CompanyTypeViewModel> GetListActiveAll();

        List<CompanyTypeViewModel> GetListActiveById(int? Id);

        List<CompanyTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<CompanyTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<CompanyTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CompanyTypeViewModel objModel);

        bool Update(CompanyTypeViewModel objModel);

        bool Delete(CompanyTypeViewModel objModel);
    }
}
