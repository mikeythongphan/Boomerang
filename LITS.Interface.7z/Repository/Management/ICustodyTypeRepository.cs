﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface ICustodyTypeRepository : IRepository<m_custody_type>
    {
        List<CustodyTypeViewModel> GetListAll();

        List<CustodyTypeViewModel> GetListById(int? Id);

        List<CustodyTypeViewModel> GetListByStatusId(int? StatusId);

        List<CustodyTypeViewModel> GetListByTypeId(int? TypeId);

        List<CustodyTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CustodyTypeViewModel> GetListActiveAll();

        List<CustodyTypeViewModel> GetListActiveById(int? Id);

        List<CustodyTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<CustodyTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<CustodyTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CustodyTypeViewModel objModel);

        bool Update(CustodyTypeViewModel objModel);

        bool Delete(CustodyTypeViewModel objModel);
    }
}
