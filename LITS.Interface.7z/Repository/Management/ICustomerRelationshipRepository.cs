﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface ICustomerRelationshipRepository : IRepository<m_customer_relationship>
    {
        List<CustomerRelationshipViewModel> GetListAll();

        List<CustomerRelationshipViewModel> GetListById(int? Id);

        List<CustomerRelationshipViewModel> GetListByStatusId(int? StatusId);

        List<CustomerRelationshipViewModel> GetListByTypeId(int? TypeId);

        List<CustomerRelationshipViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CustomerRelationshipViewModel> GetListActiveAll();

        List<CustomerRelationshipViewModel> GetListActiveById(int? Id);

        List<CustomerRelationshipViewModel> GetListActiveByStatusId(int? StatusId);

        List<CustomerRelationshipViewModel> GetListActiveByTypeId(int? TypeId);

        List<CustomerRelationshipViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CustomerRelationshipViewModel objModel);

        bool Update(CustomerRelationshipViewModel objModel);

        bool Delete(CustomerRelationshipViewModel objModel);
    }
}
