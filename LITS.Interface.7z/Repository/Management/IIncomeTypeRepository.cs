﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IIncomeTypeRepository : IRepository<m_income_type>
    {
        List<IncomeTypeViewModel> GetListAll();

        List<IncomeTypeViewModel> GetListById(int? Id);

        List<IncomeTypeViewModel> GetListByStatusId(int? StatusId);

        List<IncomeTypeViewModel> GetListByTypeId(int? TypeId);

        List<IncomeTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<IncomeTypeViewModel> GetListActiveAll();

        List<IncomeTypeViewModel> GetListActiveById(int? Id);

        List<IncomeTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<IncomeTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<IncomeTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(IncomeTypeViewModel objModel);

        bool Update(IncomeTypeViewModel objModel);

        bool Delete(IncomeTypeViewModel objModel);
    }
}
