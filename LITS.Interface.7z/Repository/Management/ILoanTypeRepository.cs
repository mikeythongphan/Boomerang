﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface ILoanTypeRepository : IRepository<m_loan_type>
    {
        List<LoanTypeViewModel> GetListAll();

        List<LoanTypeViewModel> GetListById(int? Id);

        List<LoanTypeViewModel> GetListByStatusId(int? StatusId);

        List<LoanTypeViewModel> GetListByTypeId(int? TypeId);

        List<LoanTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<LoanTypeViewModel> GetListActiveAll();

        List<LoanTypeViewModel> GetListActiveById(int? Id);

        List<LoanTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<LoanTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<LoanTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(LoanTypeViewModel objModel);

        bool Update(LoanTypeViewModel objModel);

        bool Delete(LoanTypeViewModel objModel);
    }
}
