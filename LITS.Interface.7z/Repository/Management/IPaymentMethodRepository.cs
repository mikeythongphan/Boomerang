﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IPaymentMethodRepository : IRepository<m_payment_method>
    {
        List<PaymentMethodViewModel> GetListAll();

        List<PaymentMethodViewModel> GetListById(int? Id);

        List<PaymentMethodViewModel> GetListByStatusId(int? StatusId);

        List<PaymentMethodViewModel> GetListByTypeId(int? TypeId);

        List<PaymentMethodViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<PaymentMethodViewModel> GetListActiveAll();

        List<PaymentMethodViewModel> GetListActiveById(int? Id);

        List<PaymentMethodViewModel> GetListActiveByStatusId(int? StatusId);

        List<PaymentMethodViewModel> GetListActiveByTypeId(int? TypeId);

        List<PaymentMethodViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(PaymentMethodViewModel objModel);

        bool Update(PaymentMethodViewModel objModel);

        bool Delete(PaymentMethodViewModel objModel);
    }
}
