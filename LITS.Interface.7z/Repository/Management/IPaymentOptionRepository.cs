﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IPaymentOptionRepository : IRepository<m_payment_option>
    {
        List<PaymentOptionViewModel> GetListAll();

        List<PaymentOptionViewModel> GetListById(int? Id);

        List<PaymentOptionViewModel> GetListByStatusId(int? StatusId);

        List<PaymentOptionViewModel> GetListByTypeId(int? TypeId);

        List<PaymentOptionViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<PaymentOptionViewModel> GetListActiveAll();

        List<PaymentOptionViewModel> GetListActiveById(int? Id);

        List<PaymentOptionViewModel> GetListActiveByStatusId(int? StatusId);

        List<PaymentOptionViewModel> GetListActiveByTypeId(int? TypeId);

        List<PaymentOptionViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(PaymentOptionViewModel objModel);

        bool Update(PaymentOptionViewModel objModel);

        bool Delete(PaymentOptionViewModel objModel);
    }
}
