﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IReasonRepository : IRepository<m_reason>
    {
        List<ReasonViewModel> GetListAll();

        List<ReasonViewModel> GetListById(int? Id);

        List<ReasonViewModel> GetListByStatusId(int? StatusId);

        List<ReasonViewModel> GetListByTypeId(int? TypeId);

        List<ReasonViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<ReasonViewModel> GetListActiveAll();

        List<ReasonViewModel> GetListActiveById(int? Id);

        List<ReasonViewModel> GetListActiveByStatusId(int? StatusId);

        List<ReasonViewModel> GetListActiveByTypeId(int? TypeId);

        List<ReasonViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(ReasonViewModel objModel);

        bool Update(ReasonViewModel objModel);

        bool Delete(ReasonViewModel objModel);
    }
}
