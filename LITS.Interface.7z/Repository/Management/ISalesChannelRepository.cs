﻿using System.Collections.Generic;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Model.Views.Management;

namespace LITS.Interface.Repository.Management
{
    public interface ISalesChannelRepository : IRepository<m_sales_channel>
    { 
        List<SalesChannelViewModel> GetListAll();

        List<SalesChannelViewModel> GetListById(int? Id);

        List<SalesChannelViewModel> GetListByStatusId(int? StatusId);

        List<SalesChannelViewModel> GetListByTypeId(int? TypeId);

        List<SalesChannelViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<SalesChannelViewModel> GetListActiveAll();

        List<SalesChannelViewModel> GetListActiveById(int? Id);

        List<SalesChannelViewModel> GetListActiveByStatusId(int? StatusId);

        List<SalesChannelViewModel> GetListActiveByTypeId(int? TypeId);

        List<SalesChannelViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(SalesChannelViewModel objModel);

        bool Update(SalesChannelViewModel objModel);

        bool Delete(SalesChannelViewModel objModel);
    }
}
