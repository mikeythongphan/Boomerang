﻿using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;


namespace LITS.Interface.Service.AutoLoan.CreditInitiative
{
    public interface IARTAService
    {
        ARTAViewModel GetById(int? Id);

        ARTAViewModel GetAll();

       // application_information GetApplicationInformation(int? Id);

        void Create(ARTAViewModel obj);

        void Delete(ARTAViewModel obj);

        void Update(ARTAViewModel obj);
    }
}
