﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.AutoLoan.LendingOperation;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.AutoLoan.LendingOperation
{
    public interface IDisbursementInformationService
    {
        DisbursementInformationViewModel GetById(int? Id);

        DisbursementInformationViewModel GetAll();

       // application_information GetDisbursementInformation(int? Id);

        void Create(DisbursementInformationViewModel obj);

        void Delete(DisbursementInformationViewModel obj);

        void Update(DisbursementInformationViewModel obj);
    }
}
