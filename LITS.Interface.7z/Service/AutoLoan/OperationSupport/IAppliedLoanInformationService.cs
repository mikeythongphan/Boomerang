﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;

namespace LITS.Interface.Service.AutoLoan.OperationSupport
{
    public interface IAppliedLoanInformationService
    {
        AppliedLoanInformationViewModel GetById(int? Id);

        AppliedLoanInformationViewModel GetAll();

       // application_information GetApplicationInformation(int? Id);        

        void Create(AppliedLoanInformationViewModel obj);

        void Delete(AppliedLoanInformationViewModel obj);

        void Save();
    }
}
