﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.AutoLoan.SalesCoordinators
{
    public interface ICustomerIncomeService
    {
        CustomerIncomeViewModel GetById(int? Id);

        CustomerIncomeViewModel GetAll();

      //  application_information GetApplicationInformation(int? Id);        

        void Create(CustomerIncomeViewModel obj);

        void Delete(CustomerIncomeViewModel obj);

        void Save();
    }
}
