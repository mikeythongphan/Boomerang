﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.Main.CreateNewLoan
{
    public interface ICreateNewLoanService
    {        
        CreateNewLoanViewModel LoadIndexStep1(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreateNewLoanViewModel LoadIndexStep2(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreateNewLoanViewModel LoadIndexStep3(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);

        CreateNewLoanViewModel Submit(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
