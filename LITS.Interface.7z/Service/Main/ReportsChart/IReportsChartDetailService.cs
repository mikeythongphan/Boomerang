﻿using LITS.Model.PartialViews.Main.ReportsChart;

namespace LITS.Interface.Service.Main.ReportsChart
{
    public interface IReportsChartDetailService
    {
        ReportsChartDetailViewModel GetById(int? Id);

        ReportsChartDetailViewModel GetAll();      

        void Create(ReportsChartDetailViewModel obj);

        void Delete(int? Id);

        void Save();
    }
}
