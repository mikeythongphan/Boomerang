﻿using LITS.Model.PartialViews.Main.ReportsChart;

namespace LITS.Interface.Service.Main.ReportsChart
{
    public interface IReportsChartMasterService
    {
        ReportsChartMasterViewModel GetById(int? Id);

        ReportsChartMasterViewModel GetAll();        

        void Create(ReportsChartMasterViewModel obj);

        void Delete(int? Id);

        void Save();
    }
}
