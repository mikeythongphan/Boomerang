﻿
using LITS.Model.PartialViews.Main.ReportsChart;

namespace LITS.Interface.Service.Main.ReportsChart
{
    public interface IReportsChartTreelService
    {
        ReportsChartTreeViewModel GetById(int? Id);

        ReportsChartTreeViewModel GetAll();

        void Create(ReportsChartTreeViewModel obj);

        void Delete(int? Id);

        void Save();
    }
}
