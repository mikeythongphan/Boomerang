﻿using LITS.Model.PartialViews.Main.ReportsExport;

namespace LITS.Interface.Service.Main.ReportsExport
{
    public interface IReportsExportMasterService
    {
        ReportsExportMasterViewModel GetById(int? Id);

        ReportsExportMasterViewModel GetAll();        

        void Create(ReportsExportMasterViewModel obj);

        void Delete(int? Id);

        void Save();
    }
}
