﻿
using LITS.Model.PartialViews.Main.ReportsExport;

namespace LITS.Interface.Service.Main.ReportsExport
{
    public interface IReportsExportTreelService
    {
        ReportsExportTreeViewModel GetById(int? Id);

        ReportsExportTreeViewModel GetAll();

        void Create(ReportsExportTreeViewModel obj);

        void Delete(int? Id);

        void Save();
    }
}
