﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Model.Views.Main;
using LITS.Model.PartialViews.Main;

namespace LITS.Interface.Service.Main.SalesCoordinators
{
    public interface ISalesCoordinatorsService
    {        
        SalesCoordinatorsViewModel GetSalesCoordinatorsByAppId(int? Id);

        application_information GetApplicationInformation();

        customer_information GetCustomerInformation(int? Id);

        IEnumerable<customer_identification> GetCustomerIdentificationByCustId(int CustId);

        void CreateSalesCoordinators(SalesCoordinatorsViewModel sc);        

        void DeleteSalesCoordinators(int? Id);

        void SaveSalesCoordinators();
    }
}
