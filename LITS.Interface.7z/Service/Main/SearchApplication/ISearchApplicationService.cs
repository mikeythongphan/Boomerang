﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.Main.SearchApplication
{
    public interface ISearchApplicationService
    {
        WorkInProgressViewModel LoadIndex();

        WorkInProgressViewModel SearchData(WorkInProgressViewModel obj, string strAreaName, string strControllerName);

        WorkInProgressViewModel LoadChildDetail(int appId, string strAreaName, string strControllerName);
    }
}
