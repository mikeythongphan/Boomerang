﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface IBorrowerTypeService
    {
        List<BorrowerTypeViewModel> GetListAll();

        List<BorrowerTypeViewModel> GetListById(int? Id);

        List<BorrowerTypeViewModel> GetListByStatusId(int? StatusId);

        List<BorrowerTypeViewModel> GetListByTypeId(int? TypeId);

        List<BorrowerTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<BorrowerTypeViewModel> GetListActiveAll();

        List<BorrowerTypeViewModel> GetListActiveById(int? Id);

        List<BorrowerTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<BorrowerTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<BorrowerTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(BorrowerTypeViewModel objModel);

        bool Update(BorrowerTypeViewModel objModel);

        bool Delete(BorrowerTypeViewModel objModel);
    }
}
