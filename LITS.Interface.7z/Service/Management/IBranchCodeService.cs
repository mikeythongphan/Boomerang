﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface IBranchCodeService
    {
        List<BranchCodeViewModel> GetListAll();

        List<BranchCodeViewModel> GetListById(int? Id);

        List<BranchCodeViewModel> GetListByStatusId(int? StatusId);

        List<BranchCodeViewModel> GetListByTypeId(int? TypeId);

        List<BranchCodeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<BranchCodeViewModel> GetListActiveAll();

        List<BranchCodeViewModel> GetListActiveById(int? Id);

        List<BranchCodeViewModel> GetListActiveByStatusId(int? StatusId);

        List<BranchCodeViewModel> GetListActiveByTypeId(int? TypeId);

        List<BranchCodeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(BranchCodeViewModel objModel);

        bool Update(BranchCodeViewModel objModel);

        bool Delete(BranchCodeViewModel objModel);
    }
}
