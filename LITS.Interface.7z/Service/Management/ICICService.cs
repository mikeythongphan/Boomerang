﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
namespace LITS.Interface.Service.Management
{
    public interface ICICService
    {
        List<CicViewModel> GetListAll();

        List<CicViewModel> GetListById(int? Id);

        List<CicViewModel> GetListByStatusId(int? StatusId);

        List<CicViewModel> GetListByTypeId(int? TypeId);

        List<CicViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CicViewModel> GetListActiveAll();

        List<CicViewModel> GetListActiveById(int? Id);

        List<CicViewModel> GetListActiveByStatusId(int? StatusId);

        List<CicViewModel> GetListActiveByTypeId(int? TypeId);

        List<CicViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CicViewModel objModel);

        bool Update(CicViewModel objModel);

        bool Delete(CicViewModel objModel);
    }
}
