﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface ICreditBureauTypeService
    {
        List<CreditBureauTypeViewModel> GetListAll();

        List<CreditBureauTypeViewModel> GetListById(int? Id);

        List<CreditBureauTypeViewModel> GetListByStatusId(int? StatusId);

        List<CreditBureauTypeViewModel> GetListByTypeId(int? TypeId);

        List<CreditBureauTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CreditBureauTypeViewModel> GetListActiveAll();

        List<CreditBureauTypeViewModel> GetListActiveById(int? Id);

        List<CreditBureauTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<CreditBureauTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<CreditBureauTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CreditBureauTypeViewModel objModel);

        bool Update(CreditBureauTypeViewModel objModel);

        bool Delete(CreditBureauTypeViewModel objModel);
    }
}
