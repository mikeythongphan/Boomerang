﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
namespace LITS.Interface.Service.Management
{
    public interface ICustomerTypeService
    {
        List<CustomerTypeViewModel> GetListAll();

        List<CustomerTypeViewModel> GetListById(int? Id);

        List<CustomerTypeViewModel> GetListByStatusId(int? StatusId);

        List<CustomerTypeViewModel> GetListByTypeId(int? TypeId);

        List<CustomerTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CustomerTypeViewModel> GetListActiveAll();

        List<CustomerTypeViewModel> GetListActiveById(int? Id);

        List<CustomerTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<CustomerTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<CustomerTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CustomerTypeViewModel objModel);

        bool Update(CustomerTypeViewModel objModel);

        bool Delete(CustomerTypeViewModel objModel);
    }
}
