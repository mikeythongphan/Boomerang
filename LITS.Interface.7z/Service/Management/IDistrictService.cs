﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface IDistrictService
    {
        List<DistrictViewModel> GetListAll();

        List<DistrictViewModel> GetListById(int? Id);

        List<DistrictViewModel> GetListByStatusId(int? StatusId);

        List<DistrictViewModel> GetListByTypeId(int? TypeId);

        List<DistrictViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<DistrictViewModel> GetListByCityId(int? Id);

        List<DistrictViewModel> GetListActiveAll();

        List<DistrictViewModel> GetListActiveById(int? Id);

        List<DistrictViewModel> GetListActiveByStatusId(int? StatusId);

        List<DistrictViewModel> GetListActiveByTypeId(int? TypeId);

        List<DistrictViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<DistrictViewModel> GetListActiveByCityId(int? Id);

        bool Create(DistrictViewModel objModel);

        bool Update(DistrictViewModel objModel);

        bool Delete(DistrictViewModel objModel);
    }
}
