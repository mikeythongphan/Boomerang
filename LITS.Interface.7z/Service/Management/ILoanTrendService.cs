﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface ILoanTrendService
    {
        List<LoanTrendViewModel> GetListAll();

        List<LoanTrendViewModel> GetListById(int? Id);

        List<LoanTrendViewModel> GetListByStatusId(int? StatusId);

        List<LoanTrendViewModel> GetListByTypeId(int? TypeId);

        List<LoanTrendViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<LoanTrendViewModel> GetListActiveAll();

        List<LoanTrendViewModel> GetListActiveById(int? Id);

        List<LoanTrendViewModel> GetListActiveByStatusId(int? StatusId);

        List<LoanTrendViewModel> GetListActiveByTypeId(int? TypeId);

        List<LoanTrendViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(LoanTrendViewModel objModel);

        bool Update(LoanTrendViewModel objModel);

        bool Delete(LoanTrendViewModel objModel);
    }
}
