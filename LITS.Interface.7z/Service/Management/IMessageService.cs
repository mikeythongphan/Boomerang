﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface IMessageService
    {
        List<MessageViewModel> GetListAll();

        List<MessageViewModel> GetListById(int? Id);

        List<MessageViewModel> GetListByStatusId(int? StatusId);

        List<MessageViewModel> GetListByTypeId(int? TypeId);

        List<MessageViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<MessageViewModel> GetListActiveAll();

        List<MessageViewModel> GetListActiveById(int? Id);

        List<MessageViewModel> GetListActiveByStatusId(int? StatusId);

        List<MessageViewModel> GetListActiveByTypeId(int? TypeId);

        List<MessageViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(MessageViewModel objModel);

        bool Update(MessageViewModel objModel);

        bool Delete(MessageViewModel objModel);
    }
}
