﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace LITS.Model.Domain.AutoLoan
{
    public class CustomerBonusMonthlyViewModel
    {
        public int ID { get; set; }
        public bool IsVisibleID { get; set; }
        public bool IsDisableID { get; set; }

        public int? ApplicationInformationID { get; set; }
        public bool IsVisibleApplicationInformationID { get; set; }
        public bool IsDisableApplicationInformationID { get; set; }

        public int? CustomerInformationID { get; set; }
        public bool IsVisibleCustomerInformationID { get; set; }
        public bool IsDisableCustomerInformationID { get; set; }

        public int? CustomerIncomeID { get; set; }
        public bool IsVisibleCustomerIncomeID { get; set; }
        public bool IsDisableCustomerIncomeID { get; set; }

        public int? ALApplicationInformationID { get; set; }
        public bool IsVisibleALApplicationInformationID { get; set; }
        public bool IsDisableALApplicationInformationID { get; set; }

        public int? ALCustomerInformationID { get; set; }
        public bool IsVisibleALCustomerInformationID { get; set; }
        public bool IsDisableALCustomerInformationID { get; set; }

        public int? ALCustomerIncomeID { get; set; }
        public bool IsVisibleALCustomerIncomeID { get; set; }
        public bool IsDisableALCustomerIncomeID { get; set; }

        public int? ALCustomerSalariedIncomeID { get; set; }
        public bool IsVisibleALCustomerSalariedIncomeID { get; set; }
        public bool IsDisableALCustomerSalariedIncomeID { get; set; }

        public int? BonusTypeID { get; set; }
        public bool IsVisibleBonusTypeID { get; set; }
        public bool IsDisableBonusTypeID { get; set; }

        public int? BorrowerTypeID { get; set; }
        public bool IsVisibleBorrowerTypeID { get; set; }
        public bool IsDisableBorrowerTypeID { get; set; }

        public string Remark { get; set; }
        public bool IsVisibleRemark { get; set; }
        public bool IsDisableRemark { get; set; }

        public string InputVerification { get; set; }
        public bool IsVisibleInputVerification { get; set; }
        public bool IsDisableInputVerification { get; set; }

        public int? TypeID { get; set; }
        public bool IsVisibleTypeID { get; set; }
        public bool IsDisableTypeID { get; set; }

        public int? StatusID { get; set; }
        public bool IsVisibleStatusID { get; set; }
        public bool IsDisableStatusID { get; set; }

        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public bool? IsActive { get; set; }

        public decimal? Monthly { get; set; }
        public bool IsVisibleMonthly { get; set; }
        public bool IsDisableMonthly { get; set; }

        public decimal? FirstTime { get; set; }
        public bool IsVisibleFirstTime { get; set; }
        public bool IsDisableFirstTime { get; set; }

        public decimal? SecondTime { get; set; }
        public bool IsVisibleSecondTime { get; set; }
        public bool IsDisableSecondTime { get; set; }

        public decimal? ThirdTime { get; set; }
        public bool IsVisibleThirdTime { get; set; }
        public bool IsDisableThirdTime { get; set; }

        public decimal? FourthTime { get; set; }
        public bool IsVisibleFourthTime { get; set; }
        public bool IsDisableFourthTime { get; set; }

        public decimal? FifthTime { get; set; }
        public bool IsVisibleFifthTime { get; set; }
        public bool IsDisableFifthTime { get; set; }
    }
}
