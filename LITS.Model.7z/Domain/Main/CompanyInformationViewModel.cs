﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.Domain.Main
{
    public class CompanyInformationViewModel
    {
        public int? GUIID { get; set; }

        public int? CompanyID { get; set; }

        public string CompanyName { get; set; }
        public bool IsVisibleCompanyName { get; set; }
        public bool IsDisableCompanyName { get; set; }

        public string CompanyCode { get; set; }
        public bool IsVisibleCompanyCode { get; set; }
        public bool IsDisableCompanyCode { get; set; }

        public string CompanyCAT { get; set; }
        public bool IsVisibleCompanyCAT { get; set; }
        public bool IsDisableCompanyCAT { get; set; }

        public string CompanyType { get; set; }
        public int? CompanyTypeID { get; set; }
        public bool IsVisibleCompanyType { get; set; }
        public bool IsDisableCompanyType { get; set; }

        public string CompanyAddress { get; set; }        
        public bool IsVisibleCompanyAddress { get; set; }
        public bool IsDisableCompanyAddress { get; set; }

        public string CompanyWard { get; set; }
        public bool IsVisibleCompanyWard { get; set; }
        public bool IsDisableCompanyWard { get; set; }

        public string CompanyDistrict { get; set; }
        public int? CompanyDistrictID { get; set; }
        public bool IsVisibleCompanyDistrict { get; set; }
        public bool IsDisableCompanyDistrict { get; set; }

        public string CompanyCity { get; set; }
        public int? CompanyCityD { get; set; }
        public bool IsVisibleCompanyCity { get; set; }
        public bool IsDisableCompanyCity { get; set; }

        public string Description { get; set; }
        public bool IsVisibleDescription { get; set; }
        public bool IsDisableDescription { get; set; }

        public int ApplicationID { get; set; }
        public string ApplicationNo { get; set; }
        public bool IsVisibleApplicationNo { get; set; }
        public bool IsDisableApplicationNo { get; set; }

        public string ApplicationType { get; set; }
        public int? ApplicationTypeID { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsDisableApplicationType { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsDisableApplicationStatus { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool? IsActive { get; set; }
    }
}
