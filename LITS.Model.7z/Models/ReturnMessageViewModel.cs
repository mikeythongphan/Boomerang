﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.Models
{
    public class ReturnMessageViewModel
    {        
        public int ID { get; set; }
        public bool IsVisibleID { get; set; }
        public bool IsDisableID { get; set; }        

        public string Code { get; set; }
        public bool IsVisibleCode { get; set; }
        public bool IsDisableCode { get; set; }

        public string Name { get; set; }
        public bool IsVisibleName { get; set; }
        public bool IsDisableName { get; set; }

        public string Subject { get; set; }
        public bool IsVisibleSubject { get; set; }
        public bool IsDisableSubject { get; set; }

        public string Content { get; set; }
        public bool IsVisibleContent { get; set; }
        public bool IsDisableContent { get; set; }

        public string Solution { get; set; }
        public bool IsVisibleSolution { get; set; }
        public bool IsDisableSolution { get; set; }

        public string Description { get; set; }
        public bool IsVisibleDescription { get; set; }
        public bool IsDisableDescription { get; set; }

        public int? MessageTypeID { get; set; }
        public string MessageType { get; set; }
        public bool IsVisibleMessageTypeID { get; set; }
        public bool IsDisableMessageTypeID { get; set; }

        public int? TypeID { get; set; }
        public string Type { get; set; }
        public bool IsVisibleTypeID { get; set; }
        public bool IsDisableTypeID { get; set; }

        public int? StatusID { get; set; }
        public string Status { get; set; }
        public bool IsVisibleStatusID { get; set; }
        public bool IsDisableStatusID { get; set; }

        public int? GroupID { get; set; }
        public string Group { get; set; }
        public bool IsVisibleGroupID { get; set; }
        public bool IsDisableGroupID { get; set; }

        public bool IsActive { get; set; }
        public bool IsVisible_IsActive { get; set; }
        public bool IsDisable_IsActive { get; set; }
    }
}
