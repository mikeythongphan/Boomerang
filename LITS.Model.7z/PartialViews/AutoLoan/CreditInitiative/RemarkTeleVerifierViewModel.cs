﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.CreditInitiative
{
    public class RemarkTeleVerifierViewModel
    {
        public bool IsActive { get; set; }
        public bool SendSMS { get; set; }
        public bool IsVisibleARTA { get; set; }
        public bool IsDisableARTA { get; set; }      

    }
}
