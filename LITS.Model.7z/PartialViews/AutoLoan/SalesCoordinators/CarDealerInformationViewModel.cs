﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.SalesCoordinators
{
    public class CarDealerInformationViewModel
    {
        public int ApplicationInformationID { get; set; }
        public int? ALApplicationInformationID { get; set; }

        public string CarDealerName { get; set; }
        public bool IsVisibleCarDealerName { get; set; }
        public bool IsDisableCarDealerName { get; set; }
        public int? CarDealerNameID { get; set; }

        public string CarDealerAddress { get; set; }
        public bool IsVisibleCarDealerAddress { get; set; }
        public bool IsDisableCarDealerAddress { get; set; }

        public string CarDealerWards { get; set; }
        public bool IsVisibleCarDealerWards { get; set; }
        public bool IsDisableCarDealerWards { get; set; }

        public string CarDealerDistrict { get; set; }
        public bool IsVisibleCarDealerDistrict { get; set; }
        public bool IsDisableCarDealerDistrict { get; set; }
        public int? CarDealerDistrictID { get; set; }

        public string CarDealerCity { get; set; }
        public bool IsVisibleCarDealerCity { get; set; }
        public bool IsDisableCarDealerCity { get; set; }
        public int? CarDealerCityID { get; set; }

        public string CooperationContractActive { get; set; }
        public bool IsVisibleCooperationContractActive { get; set; }
        public bool IsDisableCooperationContractActive { get; set; }
        public int? CooperationContractActiveID { get; set; }

        public decimal? CarDealerPromissoryDisbursementCap { get; set; }
        public bool IsVisibleCarDealerPromissoryDisbursementCap { get; set; }
        public bool IsDisableCarDealerPromissoryDisbursementCap { get; set; }

        public decimal? CarDealerPromissoryDisbursementAvailableLimit { get; set; }
        public bool IsVisibleCarDealerPromissoryDisbursementAvailableLimit { get; set; }
        public bool IsDisableCarDealerPromissoryDisbursementAvailableLimit { get; set; }

        public decimal? CarDealerTotalDisbursement { get; set; }
        public bool IsVisibleCarDealerTotalDisbursement { get; set; }
        public bool IsDisableCarDealerTotalDisbursement { get; set; }

        public decimal? CarDealerILCap { get; set; }
        public bool IsVisibleCarDealerILCap { get; set; }
        public bool IsDisableCarDealerILCap { get; set; }

        public string ApplicationType { get; set; }
        public int? ApplicationTypeID { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsDisableApplicationType { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsDisableApplicationStatus { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }
    }
}
