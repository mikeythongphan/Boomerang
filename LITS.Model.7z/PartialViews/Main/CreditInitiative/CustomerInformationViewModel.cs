﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.Main.CreditInitiative
{
    public class CustomerInformationViewModel
    {
        public bool IsActive { get; set; }
        [Required]
        public string CustomerSCRelationship { get; set; }
        public bool IsVisibleCustomerSCRelationship { get; set; }
        public bool IsDisableCustomerSCRelationship { get; set; }
        public int CustomerSCRelationshipID { get; set; }
        [Required]
        public Nullable<System.DateTime> DOB { get; set; }
        public bool IsVisibleDOB { get; set; }
        public bool IsDisableDOB { get; set; }
        [Required]
        public string PermanentAddress { get; set; }
        public bool IsVisiblePermanentAddress { get; set; }
        public bool IsDisablePermanentAddress { get; set; }
        [Required]
        public string PermanentAddressCity { get; set; }
        public bool IsVisiblePermanentAddressCity { get; set; }
        public bool IsDisablePermanentAddressCity { get; set; }
        [Required]
        public string District { get; set; }
        public bool IsVisibleDistrict { get; set; }
        public bool IsDisableDistrict { get; set; }
        public int DistrictID { get; set; }
        [Required]
        public string TypeOfResidenceOwnership { get; set; }
        public bool IsVisibleTypeOfResidenceOwnership { get; set; }
        public bool IsDisableTypeOfResidenceOwnership { get; set; }
        public int TypeOfResidenceOwnershipID { get; set; }
        [Required]
        public string EmailAddress1 { get; set; }
        public bool IsVisibleEmailAddress1 { get; set; }
        public bool IsDisableEmailAddress1 { get; set; }
        [Required]
        public string MaritalStatus { get; set; }
        public bool IsVisibleMaritalStatus { get; set; }
        public bool IsDisableMaritalStatus { get; set; }
        public int MaritalStatusID { get; set; }
        [Required]
        public string Intitial { get; set; }
        public bool IsVisibleIntitial { get; set; }
        public bool IsDisableIntitial { get; set; }
        public int IntitialID { get; set; }
        [Required]
        public string Nationality { get; set; }
        public bool IsVisibleNationality { get; set; }
        public bool IsDisableNationality { get; set; }
        public int NationalityID { get; set; }
        [Required]
        public string PermanentAddressWard { get; set; }
        public bool IsVisiblePermanentAddressWard { get; set; }
        public bool IsDisablePermanentAddressWard { get; set; }
        [Required]
        public string CurrentResidentalAddress { get; set; }
        public bool IsVisibleCurrentResidentalAddress { get; set; }
        public bool IsDisableCurrentResidentalAddress { get; set; }
        [Required]
        public string City { get; set; }
        public bool IsVisibleCity { get; set; }
        public bool IsDisableCity { get; set; }
        public int CityID { get; set; }
        [Required]
        public string MobileNo { get; set; }
        public bool IsVisibleMobileNo { get; set; }
        public bool IsDisableMobileNo { get; set; }
        public string EmailAddress2 { get; set; }
        public bool IsVisibleEmailAddress2 { get; set; }
        public bool IsDisableEmailAddress2 { get; set; }
        public int EmailAddress2ID { get; set; }
        public string EducationLevel { get; set; }
        public bool IsVisibleEducationLevel { get; set; }
        public bool IsDisableEducationLevel { get; set; }
        public int EducationLevelID { get; set; }
        [Required]
        public string FullName { get; set; }
        public bool IsVisibleFullName { get; set; }
        public bool IsDisableFullName { get; set; }
        public string NumberOfDependants { get; set; }
        public bool IsVisibleNumberOfDependants { get; set; }
        public bool IsDisableNumberOfDependants { get; set; }
        [Required]
        public string PermanentAddressDistrict { get; set; }
        public bool IsVisiblePermanentAddressDistrict { get; set; }
        public bool IsDisablePermanentAddressDistrict { get; set; }
        [Required]
        public string Ward { get; set; }
        public bool IsVisibleWard { get; set; }
        public bool IsDisableWard { get; set; }
        [Required]
        public int TimeAtCurrentAddress { get; set; }
        public bool IsVisibleTimeAtCurrentAddress { get; set; }
        public bool IsDisableTimeAtCurrentAddress { get; set; }
        public string HomePhoneNo { get; set; }
        public bool IsVisibleHomePhoneNo { get; set; }
        public bool IsDisableHomePhoneNo { get; set; }
        [Required]
        public string BillingAddress { get; set; }
        public bool IsVisibleBillingAddress { get; set; }
        public bool IsDisableBillingAddress { get; set; }
        public int BillingAddressID { get; set; }
        [Required]
        public string EmploymentBusinessTerm { get; set; }
        public bool IsVisibleEmploymentBusinessTerm { get; set; }
        public bool IsDisableEmploymentBusinessTerm { get; set; }
        public int EmploymentBusinessTermID { get; set; }


    }
}
