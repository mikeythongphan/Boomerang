﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.Main.OperationSupport
{
    public class CustomerInformationViewModel
    {
        #region Main
        [Required]
        public string CustomerSCRelationship_Main { get; set; }
        public int CustomerSCRelationshipID_Main { get; set; }
        public bool IsVisibleCustomerSCRelationship_Main { get; set; }
        public bool IsDisableCustomerSCRelationship_Main { get; set; }

        [Required]
        public Nullable<System.DateTime> DOB_Main { get; set; }
        public bool IsVisibleDOB_Main { get; set; }
        public bool IsDisableDOB_Main { get; set; }

        [Required]
        public string PermanentAddress_Main { get; set; }
        public bool IsVisiblePermanentAddress_Main { get; set; }
        public bool IsDisablePermanentAddress_Main { get; set; }

        [Required]
        public string PermanentAddressCity_Main { get; set; }
        public bool IsVisiblePermanentAddressCity_Main { get; set; }
        public bool IsDisablePermanentAddressCity_Main { get; set; }

        [Required]
        public string District_Main { get; set; }
        public int DistrictID_Main { get; set; }
        public bool IsVisibleDistrict_Main { get; set; }
        public bool IsDisableDistrict_Main { get; set; }

        [Required]
        public string TypeOfResidenceOwnership_Main { get; set; }
        public int TypeOfResidenceOwnershipID_Main { get; set; }
        public bool IsVisibleTypeOfResidenceOwnership_Main { get; set; }
        public bool IsDisableTypeOfResidenceOwnership_Main { get; set; }

        [Required]
        public string EmailAddress1_Main { get; set; }
        public bool IsVisibleEmailAddress1_Main { get; set; }
        public bool IsDisableEmailAddress1_Main { get; set; }

        [Required]
        public string MaritalStatus_Main { get; set; }
        public int MaritalStatusID_Main { get; set; }
        public bool IsVisibleMaritalStatus_Main { get; set; }
        public bool IsDisableMaritalStatus_Main { get; set; }

        [Required]
        public string Intitial_Main { get; set; }
        public int IntitialID_Main { get; set; }
        public bool IsVisibleIntitial_Main { get; set; }
        public bool IsDisableIntitial_Main { get; set; }

        [Required]
        public string Nationality_Main { get; set; }
        public int NationalityID_Main { get; set; }
        public bool IsVisibleNationality_Main { get; set; }
        public bool IsDisableNationality_Main { get; set; }

        [Required]
        public string PermanentAddressWard_Main { get; set; }
        public bool IsVisiblePermanentAddressWard_Main { get; set; }
        public bool IsDisablePermanentAddressWard_Main { get; set; }

        [Required]
        public string CurrentResidentalAddress_Main { get; set; }
        public bool IsVisibleCurrentResidentalAddress_Main { get; set; }
        public bool IsDisableCurrentResidentalAddress_Main { get; set; }

        [Required]
        public string City_Main { get; set; }
        public int CityID_Main { get; set; }
        public bool IsVisibleCity_Main { get; set; }
        public bool IsDisableCity_Main { get; set; }

        [Required]
        public string MobileNo_Main { get; set; }
        public bool IsVisibleMobileNo_Main { get; set; }
        public bool IsDisableMobileNo_Main { get; set; }

        public string EmailAddress2_Main { get; set; }
        public bool IsVisibleEmailAddress2_Main { get; set; }
        public bool IsDisableEmailAddress2_Main { get; set; }

        public string EducationLever_Main { get; set; }
        public int EducationLeverID_Main { get; set; }
        public bool IsVisibleEducationLever_Main { get; set; }
        public bool IsDisableEducationLever_Main { get; set; }

        [Required]
        public string FullName_Main { get; set; }
        public bool IsVisibleFullName_Main { get; set; }
        public bool IsDisableFullName_Main { get; set; }

        public string NumberOfDependants_Main { get; set; }
        public int NumberOfDependantsID_Main { get; set; }
        public bool IsVisibleNumberOfDependants_Main { get; set; }
        public bool IsDisableNumberOfDependants_Main { get; set; }

        [Required]
        public string PermanentAddressDistrict_Main { get; set; }
        public bool IsVisiblePermanentAddressDistrict_Main { get; set; }
        public bool IsDisablePermanentAddressDistrict_Main { get; set; }

        [Required]
        public string Ward_Main { get; set; }
        public bool IsVisibleWard_Main { get; set; }
        public bool IsDisableWard_Main { get; set; }

        [Required]
        public string TimeAtCurrentAddress_Main { get; set; }
        public bool IsVisibleTimeAtCurrentAddress_Main { get; set; }
        public bool IsDisableTimeAtCurrentAddress_Main { get; set; }

        public string HomePhoneNo_Main { get; set; }
        public bool IsVisibleHomePhoneNo_Main { get; set; }
        public bool IsDisableHomePhoneNo_Main { get; set; }
        [Required]
        public string BillingAddress_Main { get; set; }
        public int BillingAddressID_Main { get; set; }
        public bool IsVisibleBillingAddress_Main { get; set; }
        public bool IsDisableBillingAddress_Main { get; set; }
        [Required]
        public string EmploymentBusinessTerm_Main { get; set; }
        public int EmploymentBusinessTermID_Main { get; set; }
        public bool IsVisibleEmploymentBusinessTerm_Main { get; set; }
        public bool IsDisableEmploymentBusinessTerm_Main { get; set; }
        #endregion

        #region Co1
        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Customer SC Relationship")]
        public string CustomerSCRelationship_Co1 { get; set; }
        public int CustomerSCRelationshipID_Co1 { get; set; }
        public bool IsVisibleCustomerSCRelationship_Co1 { get; set; }
        public bool IsDisableCustomerSCRelationship_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "DOB")]
        public Nullable<System.DateTime> DOB_Co1 { get; set; }
        public bool IsVisibleDOB_Co1 { get; set; }
        public bool IsDisableDOB_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Permanent Address")]
        public string PermanentAddress_Co1 { get; set; }
        public bool IsVisiblePermanentAddress_Co1 { get; set; }
        public bool IsDisablePermanentAddress_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Permanent Address City")]
        public string PermanentAddressCity_Co1 { get; set; }
        public bool IsVisiblePermanentAddressCity_Co1 { get; set; }
        public bool IsDisablePermanentAddressCity_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "District")]
        public string District_Co1 { get; set; }
        public int DistrictID_Co1 { get; set; }
        public bool IsVisibleDistrict_Co1 { get; set; }
        public bool IsDisableDistrict_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Type Of Residence Ownership")]
        public string TypeOfResidenceOwnership_Co1 { get; set; }
        public int TypeOfResidenceOwnershipID_Co1 { get; set; }
        public bool IsVisibleTypeOfResidenceOwnership_Co1 { get; set; }
        public bool IsDisableTypeOfResidenceOwnership_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Email Address")]
        public string EmailAddress1_Co1 { get; set; }
        public bool IsVisibleEmailAddress1_Co1 { get; set; }
        public bool IsDisableEmailAddress1_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Marital Status")]
        public string MaritalStatus_Co1 { get; set; }
        public int MaritalStatusID_Co1 { get; set; }
        public bool IsVisibleMaritalStatus_Co1 { get; set; }
        public bool IsDisableMaritalStatus_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Intitial")]
        public string Intitial_Co1 { get; set; }
        public int IntitialID_Co1 { get; set; }
        public bool IsVisibleIntitial_Co1 { get; set; }
        public bool IsDisableIntitial_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Nationality")]
        public string Nationality_Co1 { get; set; }
        public int NationalityID_Co1 { get; set; }
        public bool IsVisibleNationality_Co1 { get; set; }
        public bool IsDisableNationality_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Permanent Address Ward")]
        public string PermanentAddressWard_Co1 { get; set; }
        public bool IsVisiblePermanentAddressWard_Co1 { get; set; }
        public bool IsDisablePermanentAddressWard_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Current Resident al Address")]
        public string CurrentResidentalAddress_Co1 { get; set; }
        public bool IsVisibleCurrentResidentalAddress_Co1 { get; set; }
        public bool IsDisableCurrentResidentalAddress_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "City")]
        public string City_Co1 { get; set; }
        public int CityID_Co1 { get; set; }
        public bool IsVisibleCity_Co1 { get; set; }
        public bool IsDisableCity_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Mobile No")]
        public string MobileNo_Co1 { get; set; }
        public bool IsVisibleMobileNo_Co1 { get; set; }
        public bool IsDisableMobileNo_Co1 { get; set; }

        public string EmailAddress2_Co1 { get; set; }
        public bool IsVisibleEmailAddress2_Co1 { get; set; }
        public bool IsDisableEmailAddress2_Co1 { get; set; }

        public string EducationLever_Co1 { get; set; }
        public int EducationLeverID_Co1 { get; set; }
        public bool IsVisibleEducationLever_Co1 { get; set; }
        public bool IsDisableEducationLever_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Full Name")]
        public string FullName_Co1 { get; set; }
        public bool IsVisibleFullName_Co1 { get; set; }
        public bool IsDisableFullName_Co1 { get; set; }

        public string NumberOfDependants_Co1 { get; set; }
        public bool IsVisibleNumberOfDependants_Co1 { get; set; }
        public bool IsDisableNumberOfDependants_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Permanent Address District")]
        public string PermanentAddressDistrict_Co1 { get; set; }
        public bool IsVisiblePermanentAddressDistrict_Co1 { get; set; }
        public bool IsDisablePermanentAddressDistrict_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Ward")]
        public string Ward_Co1 { get; set; }
        public bool IsVisibleWard_Co1 { get; set; }
        public bool IsDisableWard_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "TimeAtCurrentAddress")]
        public string TimeAtCurrentAddress_Co1 { get; set; }
        public bool IsVisibleTimeAtCurrentAddress_Co1 { get; set; }
        public bool IsDisableTimeAtCurrentAddress_Co1 { get; set; }

        public string HomePhoneNo_Co1 { get; set; }
        public bool IsVisibleHomePhoneNo_Co1 { get; set; }
        public bool IsDisableHomePhoneNo_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Time At Current Address")]
        public string BillingAddress_Co1 { get; set; }
        public int BillingAddressID_Co1 { get; set; }
        public bool IsVisibleBillingAddress_Co1 { get; set; }
        public bool IsDisableBillingAddress_Co1 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Time At Current Address")]
        public string EmploymentBusinessTerm_Co1 { get; set; }
        public int EmploymentBusinessTermID_Co1 { get; set; }
        public bool IsVisibleEmploymentBusinessTerm_Co1 { get; set; }
        public bool IsDisableEmploymentBusinessTerm_Co1 { get; set; }
        #endregion

        #region Co2
        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Customer SC Relationship")]
        public string CustomerSCRelationship_Co2 { get; set; }
        public int CustomerSCRelationshipID_Co2 { get; set; }
        public bool IsVisibleCustomerSCRelationship_Co2 { get; set; }
        public bool IsDisableCustomerSCRelationship_Co2 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "DOB")]
        public Nullable<System.DateTime> DOB_Co2 { get; set; }
        public bool IsVisibleDOB_Co2 { get; set; }
        public bool IsDisableDOB_Co2 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Permanent Address")]
        public string PermanentAddress_Co2 { get; set; }
        public bool IsVisiblePermanentAddress_Co2 { get; set; }
        public bool IsDisablePermanentAddress_Co2 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Permanent Address City")]
        public string PermanentAddressCity_Co2 { get; set; }
        public bool IsVisiblePermanentAddressCity_Co2 { get; set; }
        public bool IsDisablePermanentAddressCity_Co2 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "District")]
        public string District_Co2 { get; set; }
        public int DistrictID_Co2 { get; set; }
        public bool IsVisibleDistrict_Co2 { get; set; }
        public bool IsDisableDistrict_Co2 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Type Of Residence Ownership")]
        public string TypeOfResidenceOwnership_Co2 { get; set; }
        public int TypeOfResidenceOwnershipID_Co2 { get; set; }
        public bool IsVisibleTypeOfResidenceOwnership_Co2 { get; set; }
        public bool IsDisableTypeOfResidenceOwnership_Co2 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Email Address1")]
        public string EmailAddress1_Co2 { get; set; }
        public bool IsVisibleEmailAddress1_Co2 { get; set; }
        public bool IsDisableEmailAddress1_Co2 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Marital Status")]
        public string MaritalStatus_Co2 { get; set; }
        public int MaritalStatusID_Co2 { get; set; }
        public bool IsVisibleMaritalStatus_Co2 { get; set; }
        public bool IsDisableMaritalStatus_Co2 { get; set; }


        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Intitial")]
        public string Intitial_Co2 { get; set; }
        public int IntitialID_Co2 { get; set; }
        public bool IsVisibleIntitial_Co2 { get; set; }
        public bool IsDisableIntitial_Co2 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Nationality")]
        public string Nationality_Co2 { get; set; }
        public int NationalityID_Co2 { get; set; }
        public bool IsVisibleNationality_Co2 { get; set; }
        public bool IsDisableNationality_Co2 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Permanent Address Ward")]
        public string PermanentAddressWard_Co2 { get; set; }
        public bool IsVisiblePermanentAddressWard_Co2 { get; set; }
        public bool IsDisablePermanentAddressWard_Co2 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Current Residental Address")]
        public string CurrentResidentalAddress_Co2 { get; set; }
        public bool IsVisibleCurrentResidentalAddress_Co2 { get; set; }
        public bool IsDisableCurrentResidentalAddress_Co2 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "City")]
        public string City_Co2 { get; set; }
        public int CityID_Co2 { get; set; }
        public bool IsVisibleCity_Co2 { get; set; }
        public bool IsDisableCity_Co2 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Mobile No")]
        public string MobileNo_Co2 { get; set; }
        public bool IsVisibleMobileNo_Co2 { get; set; }
        public bool IsDisableMobileNo_Co2 { get; set; }

        public string EmailAddress2_Co2 { get; set; }
        public int EmailAddress2ID_Co2 { get; set; }
        public bool IsVisibleEmailAddress2_Co2 { get; set; }
        public bool IsDisableEmailAddress2_Co2 { get; set; }

        public string EducationLever_Co2 { get; set; }
        public int EducationLeverID_Co2 { get; set; }
        public bool IsVisibleEducationLever_Co2 { get; set; }
        public bool IsDisableEducationLever_Co2 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Full Name")]
        public string FullName_Co2 { get; set; }
        public bool IsVisibleFullName_Co2 { get; set; }
        public bool IsDisableFullName_Co2 { get; set; }

        public string NumberOfDependants_Co2 { get; set; }
        public bool IsVisibleNumberOfDependants_Co2 { get; set; }
        public bool IsDisableNumberOfDependants_Co2 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Permanent Address District")]
        public string PermanentAddressDistrict_Co2 { get; set; }
        public bool IsVisiblePermanentAddressDistrict_Co2 { get; set; }
        public bool IsDisablePermanentAddressDistrict_Co2 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Ward")]
        public string Ward_Co2 { get; set; }
        public bool IsVisibleWard_Co2 { get; set; }
        public bool IsDisableWard_Co2 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Time At Current Address")]
        public string TimeAtCurrentAddress_Co2 { get; set; }
        public bool IsVisibleTimeAtCurrentAddress_Co2 { get; set; }
        public bool IsDisableTimeAtCurrentAddress_Co2 { get; set; }

        public string HomePhoneNo_Co2 { get; set; }
        public bool IsVisibleHomePhoneNo_Co2 { get; set; }
        public bool IsDisableHomePhoneNo_Co2 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Billing Address")]
        public string BillingAddress_Co2 { get; set; }
        public int BillingAddressID_Co2 { get; set; }
        public bool IsVisibleBillingAddress_Co2 { get; set; }
        public bool IsDisableBillingAddress_Co2 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Employment Business Term")]
        public string EmploymentBusinessTerm_Co2 { get; set; }
        public int EmploymentBusinessTermID_Co2 { get; set; }
        public bool IsVisibleEmploymentBusinessTerm_Co2 { get; set; }
        public bool IsDisableEmploymentBusinessTerm_Co2 { get; set; }
        #endregion

        #region Co3
        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Customer SC Relationship")]
        public string CustomerSCRelationship_Co3 { get; set; }
        public int CustomerSCRelationshipID_Co3 { get; set; }
        public bool IsVisibleCustomerSCRelationship_Co3 { get; set; }
        public bool IsDisableCustomerSCRelationship_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "DOB")]
        public Nullable<System.DateTime> DOB_Co3 { get; set; }
        public bool IsVisibleDOB_Co3 { get; set; }
        public bool IsDisableDOB_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Permanent Address")]
        public string PermanentAddress_Co3 { get; set; }
        public bool IsVisiblePermanentAddress_Co3 { get; set; }
        public bool IsDisablePermanentAddress_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Permanent Address City")]
        public string PermanentAddressCity_Co3 { get; set; }
        public bool IsVisiblePermanentAddressCity_Co3 { get; set; }
        public bool IsDisablePermanentAddressCity_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Permanent Address City")]
        public string District_Co3 { get; set; }
        public int DistrictID_Co3 { get; set; }
        public bool IsVisibleDistrict_Co3 { get; set; }
        public bool IsDisableDistrict_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Type Of Residence Ownership")]
        public string TypeOfResidenceOwnership_Co3 { get; set; }
        public int TypeOfResidenceOwnershipID_Co3 { get; set; }
        public bool IsVisibleTypeOfResidenceOwnership_Co3 { get; set; }
        public bool IsDisableTypeOfResidenceOwnership_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Email Address1")]
        public string EmailAddress1_Co3 { get; set; }
        public bool IsVisibleEmailAddress1_Co3 { get; set; }
        public bool IsDisableEmailAddress1_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Marital Status")]
        public string MaritalStatus_Co3 { get; set; }
        public int MaritalStatusID_Co3 { get; set; }
        public bool IsVisibleMaritalStatus_Co3 { get; set; }
        public bool IsDisableMaritalStatus_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Intitial")]
        public string Intitial_Co3 { get; set; }
        public int IntitialID_Co3 { get; set; }
        public bool IsVisibleIntitial_Co3 { get; set; }
        public bool IsDisableIntitial_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Nationality")]
        public string Nationality_Co3 { get; set; }
        public int NationalityID_Co3 { get; set; }
        public bool IsVisibleNationality_Co3 { get; set; }
        public bool IsDisableNationality_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Permanent Address Ward")]
        public string PermanentAddressWard_Co3 { get; set; }
        public bool IsVisiblePermanentAddressWard_Co3 { get; set; }
        public bool IsDisablePermanentAddressWard_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Current Resident al Address")]
        public string CurrentResidentalAddress_Co3 { get; set; }
        public bool IsVisibleCurrentResidentalAddress_Co3 { get; set; }
        public bool IsDisableCurrentResidentalAddress_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "City")]
        public string City_Co3 { get; set; }
        public int CityID_Co3 { get; set; }
        public bool IsVisibleCity_Co3 { get; set; }
        public bool IsDisableCity_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Mobile No")]
        public string MobileNo_Co3 { get; set; }
        public bool IsVisibleMobileNo_Co3 { get; set; }
        public bool IsDisableMobileNo_Co3 { get; set; }

        public string EmailAddress2_Co3 { get; set; }
        public bool IsVisibleEmailAddress2_Co3 { get; set; }
        public bool IsDisableEmailAddress2_Co3 { get; set; }

        public string EducationLever_Co3 { get; set; }
        public int EducationLeverID_Co3 { get; set; }
        public bool IsVisibleEducationLever_Co3 { get; set; }
        public bool IsDisableEducationLever_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Full Name")]
        public string FullName_Co3 { get; set; }
        public bool IsVisibleFullName_Co3 { get; set; }
        public bool IsDisableFullName_Co3 { get; set; }

        public string NumberOfDependants_Co3 { get; set; }
        public bool IsVisibleNumberOfDependants_Co3 { get; set; }
        public bool IsDisableNumberOfDependants_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Permanent Address District")]
        public string PermanentAddressDistrict_Co3 { get; set; }
        public bool IsVisiblePermanentAddressDistrict_Co3 { get; set; }
        public bool IsDisablePermanentAddressDistrict_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Ward")]
        public string Ward_Co3 { get; set; }
        public bool IsVisibleWard_Co3 { get; set; }
        public bool IsDisableWard_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Time At Current Address")]
        public string TimeAtCurrentAddress_Co3 { get; set; }
        public bool IsVisibleTimeAtCurrentAddress_Co3 { get; set; }
        public bool IsDisableTimeAtCurrentAddress_Co3 { get; set; }

        public string HomePhoneNo_Co3 { get; set; }
        public bool IsVisibleHomePhoneNo_Co3 { get; set; }
        public bool IsDisableHomePhoneNo_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Billing Address")]
        public string BillingAddress_Co3 { get; set; }
        public int BillingAddressID_Co3 { get; set; }
        public bool IsVisibleBillingAddress_Co3 { get; set; }
        public bool IsDisableBillingAddress_Co3 { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Employment Business Term")]
        public string EmploymentBusinessTerm_Co3 { get; set; }
        public int EmploymentBusinessTermID_Co3 { get; set; }
        public bool IsVisibleEmploymentBusinessTerm_Co3 { get; set; }
        public bool IsDisableEmploymentBusinessTerm_Co3 { get; set; }
        #endregion
        public bool IsActive { get; set; }
    }
}
