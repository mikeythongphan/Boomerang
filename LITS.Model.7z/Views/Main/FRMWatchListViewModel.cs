﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.PartialViews.Main.FRMWatchList;
using LITS.Model.Views.Management;

namespace LITS.Model.Views.Main
{
    public class FRMWatchListViewModel
    {
        public FRMWatchListMasterViewModel _FRMWatchListMasterViewModel { get; set; }
        public List<FRMWatchListDetailViewModel> _FRMWatchListDetailViewModel { get; set; }
        public List<FRMWatchListTreeViewModel> _FRMWatchListTreeViewModel { get; set; }

        public List<StatusViewModel> _StatusViewModel { get; set; }
        public List<TypeViewModel> _TypeViewModel { get; set; }
    }
}
