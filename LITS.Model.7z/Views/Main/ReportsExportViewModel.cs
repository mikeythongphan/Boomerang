﻿using System;
using System.Collections.Generic;
using LITS.Model.PartialViews.Main.ReportsExport;
using LITS.Model.Views.Management;

namespace LITS.Model.Views.Main
{
    public class ReportsExportViewModel
    {
        private ReportsExportMasterViewModel _objReportsExportMasterViewModel = new ReportsExportMasterViewModel();
        public ReportsExportMasterViewModel _ReportsExportMasterViewModel
        {
            get
            {
                return _objReportsExportMasterViewModel;
            }
            set { _objReportsExportMasterViewModel = value; }
        }
        private List<ReportsExportDetailViewModel> _objReportsExportDetailViewModel = new List<ReportsExportDetailViewModel>();
        public List<ReportsExportDetailViewModel> _ReportsExportDetailViewModel
        {
            get
            {
                return _objReportsExportDetailViewModel;
            }
            set { _objReportsExportDetailViewModel = value; }
        }

        private List<ReportsExportTreeViewModel> _objReportsExportTreeViewModel = new List<ReportsExportTreeViewModel>();
        public List<ReportsExportTreeViewModel> _ReportsExportTreeViewModel
        {
            get
            {
                return _objReportsExportTreeViewModel;
            }
            set { _objReportsExportTreeViewModel = value; }
        }

        private List<StatusViewModel> _objStatusViewModel = new List<StatusViewModel>();
        public List<StatusViewModel> lstStatusViewModel
        {
            get
            {
                return _objStatusViewModel;
            }
            set { _objStatusViewModel = value; }
        }
        private List<TypeViewModel> _objTypeViewModel = new List<TypeViewModel>();
        public List<TypeViewModel> lstTypeViewModel
        {
            get
            {
                return _objTypeViewModel;
            }
            set { _objTypeViewModel = value; }
        }
    }
}
