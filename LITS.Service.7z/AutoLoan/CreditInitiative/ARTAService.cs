﻿using System;
using System.Data.Entity;
using System.Linq;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.AutoLoan.CreditInitiative;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;

namespace LITS.Service.AutoLoan.CreditInitiative
{
    public class ARTAService : IARTAService
    {
        public ARTAService()
        {
        }

        public void Create(ARTAViewModel sc)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        al_approval_information data = AutoMapper.Mapper.Map<ARTAViewModel, al_approval_information>(sc);

                        context.al_approval_information.Add(data);
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        public void Delete(ARTAViewModel obj)
        {
            if (obj != null)
            {
                using (var context = new LITSEntities())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            obj.IsActive = false;
                            var data = AutoMapper.Mapper.Map<ARTAViewModel, al_approval_information>(obj);
                            context.al_approval_information.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
            }
        }

        public ARTAViewModel GetAll()
        {
            throw new NotImplementedException();
        }


        public ARTAViewModel GetById(int? Id)
        {
            ARTAViewModel obj = new ARTAViewModel();
            LITSEntities entities = new LITSEntities();
            var data = entities.al_approval_information.FirstOrDefault(p => p.pk_id == Id);
            obj = AutoMapper.Mapper.Map<al_approval_information, ARTAViewModel>(data);
            return obj;
        }

        public void Update(ARTAViewModel obj)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var data = AutoMapper.Mapper.Map<ARTAViewModel, al_approval_information>(obj);
                        context.al_approval_information.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }
    }
}
