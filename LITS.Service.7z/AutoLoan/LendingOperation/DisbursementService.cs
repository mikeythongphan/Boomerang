﻿using System;
using System.Data.Entity;
using System.Linq;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.AutoLoan.LendingOperation;
using LITS.Model.PartialViews.AutoLoan.LendingOperation;

namespace LITS.Service.AutoLoan.LendingOperation
{
    public class DisbursementService : IDisbursementService
    {
        public void Create(DisbursementViewModel sc)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        disbursement_information data = AutoMapper.Mapper.Map<DisbursementViewModel, disbursement_information>(sc);

                        context.disbursement_information.Add(data);
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        public void Delete(DisbursementViewModel obj)
        {
            if (obj != null)
            {
                using (var context = new LITSEntities())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            obj.IsActive = false;
                            var data = AutoMapper.Mapper.Map<DisbursementViewModel, disbursement_information>(obj);
                            context.disbursement_information.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
            }
        }

        public DisbursementViewModel GetAll()
        {
            throw new NotImplementedException();
        }

        public DisbursementViewModel GetById(int? Id)
        {
            DisbursementViewModel obj = new DisbursementViewModel();
            LITSEntities entities = new LITSEntities();
            var data = entities.disbursement_information.FirstOrDefault(p => p.pk_id == Id);
            obj = AutoMapper.Mapper.Map<disbursement_information, DisbursementViewModel>(data);
            return obj;
        }

        public void Update(DisbursementViewModel obj)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var data = AutoMapper.Mapper.Map<DisbursementViewModel, disbursement_information>(obj);

                        context.disbursement_information.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }
    }
}
