﻿using System;
using System.Linq;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.AutoLoan.OperationSupport;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;
using System.Data.Entity;

namespace LITS.Service.AutoLoan.OperationSupport
{
    public class CarDealerInformationService : ICarDealerInformationService
    {

        /// <summary>
        /// Car Dealer Information Service
        /// </summary>
        public CarDealerInformationService()
        { }

        /// <summary>
        /// Create
        /// </summary>
        /// <param name="obj">CarDealerInformationViewModel</param>
        public void Create(CarDealerInformationViewModel sc)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        al_car_dealer data = AutoMapper.Mapper.Map<CarDealerInformationViewModel, al_car_dealer>(sc);

                        context.al_car_dealer.Add(data);
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="id">int</param>
        public void Delete(CarDealerInformationViewModel obj)
        {
            if (obj != null)
            {
                using (var context = new LITSEntities())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            CarDealerInformationViewModel model = obj;
                            model.IsActive = false;
                            obj.IsActive = false;
                            var data = AutoMapper.Mapper.Map<CarDealerInformationViewModel, al_car_dealer>(model);
                            context.al_car_dealer.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// GetAll
        /// </summary>
        /// <returns></returns>
        public CarDealerInformationViewModel GetAll()
        {
            throw new NotImplementedException();
        }


        /// <summary>
        /// GetById
        /// </summary>
        /// <param name="Id">int</param>
        /// <returns></returns>
        public CarDealerInformationViewModel GetById(int? Id)
        {
            CarDealerInformationViewModel obj = new CarDealerInformationViewModel();
            LITSEntities entities = new LITSEntities();
            var data = entities.al_car_dealer.FirstOrDefault(p => p.pk_id == Id);
            obj = AutoMapper.Mapper.Map<al_car_dealer, CarDealerInformationViewModel>(data);
            return obj;
        }

        public void Update(CarDealerInformationViewModel obj)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var data = AutoMapper.Mapper.Map<CarDealerInformationViewModel, al_car_dealer>(obj);

                        context.al_car_dealer.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }
    }
}
