﻿using System;
using LITS.Interface.Service.Main.ReportsChart;
using LITS.Model.PartialViews.Main.ReportsChart;

namespace LITS.Service.Main.ReportsChart
{
    public class ReportsChartMasterService : IReportsChartMasterService
    {
        public ReportsChartMasterService()
        {

        }

        public void Create(ReportsChartMasterViewModel obj)
        {
            throw new NotImplementedException();
        }

        public void Delete(int? Id)
        {
            throw new NotImplementedException();
        }

        public ReportsChartMasterViewModel GetAll()
        {
            throw new NotImplementedException();
        }

        public ReportsChartMasterViewModel GetById(int? Id)
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            throw new NotImplementedException();
        }
    }
}
