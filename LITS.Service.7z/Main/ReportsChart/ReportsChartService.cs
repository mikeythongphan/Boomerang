﻿using LITS.Infrastructure.Configuration;
using LITS.Infrastructure.Context;
using LITS.Interface.Repository.Main.ReportsChart;
using LITS.Interface.Service.Main.ReportsChart;
using LITS.Model.Views.Main;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Service.Main.ReportsChart
{
    public class ReportsChartService : IReportsChartService
    {
        private readonly IReportsChartMasterRepository _ReportsChartMasterRepository;
        private readonly IReportsChartDetailRepository _ReportsChartDetailRepository;
        private readonly IReportsChartTreeRepository _ReportsChartTreeRepository;
        private readonly IReportsChartRepository _ReportsChartRepository;
        private LITSEntities _LITSEntities;

        private readonly IUnitOfWork _unitOfWork;

        public ReportsChartService(IReportsChartMasterRepository reportsChartMasterRepository,
            IReportsChartDetailRepository reportsChartDetailRepository,
            IReportsChartTreeRepository reportsChartTreeRepository,
            IReportsChartRepository reportsChartRepository,
            IUnitOfWork unitOfWork,
            LITSEntities litsEntities)
        {
            this._ReportsChartDetailRepository = reportsChartDetailRepository;
            this._ReportsChartMasterRepository = reportsChartMasterRepository;
            this._ReportsChartTreeRepository = reportsChartTreeRepository;
            this._ReportsChartRepository = reportsChartRepository;
            this._unitOfWork = unitOfWork;
            this._LITSEntities = litsEntities;
        }
        public ReportsChartViewModel LoadIndex()
        {
            ReportsChartViewModel obj = new ReportsChartViewModel();

            obj._ReportsChartTreeViewModel = _ReportsChartTreeRepository.GetListTreeProductIsActive();
            obj._ReportsChartMasterViewModel._ReportsChartMasterCustomerViewModel = _ReportsChartMasterRepository.GetListCustomerLargeDatabase();
            obj._ReportsChartMasterViewModel._ReportsChartMasterCompanyViewModel = _ReportsChartMasterRepository.GetListCompanyLargeDatabase();

            return obj;
        }
    }
}
