﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.Main.SalesCoordinators;
using LITS.Interface.Repository.Main.SalesCoordinators;
using LITS.Data.Repository.Main.SalesCoordinators;
using LITS.Model.PartialViews.Main.SalesCoordinators;

namespace LITS.Service.Main.SalesCoordinators
{
    public class CustomerInformationService : ICustomerInformationService
    {
        private readonly ICustomerInformationRepository _customerInformationRepository;

        private readonly IUnitOfWork _unitOfWork;

        public CustomerInformationService(ICustomerInformationRepository customerInformationRepository,
            IUnitOfWork unitOfWork)
        {
            this._customerInformationRepository = customerInformationRepository;
            this._unitOfWork = unitOfWork;
        }

        #region ApplicationInformationService Members

        public CustomerInformationViewModel GetById(int? Id)
        {
            CustomerInformationViewModel obj = new CustomerInformationViewModel();

            return obj;
        }

        public CustomerInformationViewModel GetAll()
        {
            CustomerInformationViewModel obj = new CustomerInformationViewModel();

            return obj;
        }

        public customer_information GetCustomerInformation(int? Id)
        {
            customer_information obj = new customer_information();

            return obj;
        }

        public IEnumerable<customer_identification> GetCustomerIdentificationByCustId(int CustId)
        {
            List<customer_identification> obj = new List<customer_identification>();
            //obj = _customerIdentificationRepository.GetMany(c => c.fk_customer_information_id == CustId).ToList();            //obj = _customerIdentificationRepository.GetMany(c => c.fk_customer_information_id == CustId).ToList();
            return obj;
        }

        public void Create(CustomerInformationViewModel sc)
        { }

        public void Delete(int? Id)
        { }

        public void Save()
        { }

        #endregion
    }
}
