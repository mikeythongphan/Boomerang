﻿using System;
using LITS.Interface.Service.Main.WorkInProgress;
using LITS.Model.PartialViews.Main.WorkInProgress;

namespace LITS.Service.Main.WorkInProgress
{
    public class WorkInProgressDetailService : IWorkInProgressDetailService
    {


        public WorkInProgressDetailService()
        {

        }

        public void Create(WorkInProgressDetailViewModel obj)
        {
            throw new NotImplementedException();
        }

        public void Delete(int? Id)
        {
            throw new NotImplementedException();
        }

        public WorkInProgressDetailViewModel GetAll()
        {
            throw new NotImplementedException();
        }

        public WorkInProgressDetailViewModel GetById(int? Id)
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            throw new NotImplementedException();
        }
    }
}
