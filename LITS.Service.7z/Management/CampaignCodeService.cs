﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class CampaignCodeService : ICampaignCodeService
    {
        private readonly ICampaignCodeRepository _CampaignCodeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public CampaignCodeService(ICampaignCodeRepository CampaignCodeRepository,
            IUnitOfWork unitOfWork)
        {
            this._CampaignCodeRepository = CampaignCodeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<CampaignCodeViewModel> GetListAll()
        {
            return _CampaignCodeRepository.GetListAll();
        }

        public List<CampaignCodeViewModel> GetListById(int? Id)
        {
            return _CampaignCodeRepository.GetListById(Id);
        }

        public List<CampaignCodeViewModel> GetListByStatusId(int? StatusId)
        {
            return _CampaignCodeRepository.GetListByStatusId(StatusId);
        }

        public List<CampaignCodeViewModel> GetListByTypeId(int? TypeId)
        {
            return _CampaignCodeRepository.GetListByTypeId(TypeId);
        }

        public List<CampaignCodeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CampaignCodeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<CampaignCodeViewModel> GetListActiveAll()
        {
            return _CampaignCodeRepository.GetListActiveAll();
        }

        public List<CampaignCodeViewModel> GetListActiveById(int? Id)
        {
            return _CampaignCodeRepository.GetListActiveById(Id);
        }

        public List<CampaignCodeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _CampaignCodeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<CampaignCodeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _CampaignCodeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<CampaignCodeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CampaignCodeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(CampaignCodeViewModel objModel)
        {
            return _CampaignCodeRepository.Create(objModel);
        }

        public bool Update(CampaignCodeViewModel objModel)
        {
            return _CampaignCodeRepository.Update(objModel);
        }

        public bool Delete(CampaignCodeViewModel objModel)
        {
            return _CampaignCodeRepository.Delete(objModel);
        }
    }
}
