﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class CustodyTypeService : ICustodyTypeService
    {
        private readonly ICustodyTypeRepository _CustodyTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public CustodyTypeService(ICustodyTypeRepository CustodyTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._CustodyTypeRepository = CustodyTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<CustodyTypeViewModel> GetListAll()
        {
            return _CustodyTypeRepository.GetListAll();
        }

        public List<CustodyTypeViewModel> GetListById(int? Id)
        {
            return _CustodyTypeRepository.GetListById(Id);
        }

        public List<CustodyTypeViewModel> GetListByStatusId(int? StatusId)
        {
            return _CustodyTypeRepository.GetListByStatusId(StatusId);
        }

        public List<CustodyTypeViewModel> GetListByTypeId(int? TypeId)
        {
            return _CustodyTypeRepository.GetListByTypeId(TypeId);
        }

        public List<CustodyTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CustodyTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<CustodyTypeViewModel> GetListActiveAll()
        {
            return _CustodyTypeRepository.GetListActiveAll();
        }

        public List<CustodyTypeViewModel> GetListActiveById(int? Id)
        {
            return _CustodyTypeRepository.GetListActiveById(Id);
        }

        public List<CustodyTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _CustodyTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<CustodyTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _CustodyTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<CustodyTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CustodyTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(CustodyTypeViewModel objModel)
        {
            return _CustodyTypeRepository.Create(objModel);
        }

        public bool Update(CustodyTypeViewModel objModel)
        {
            return _CustodyTypeRepository.Update(objModel);
        }

        public bool Delete(CustodyTypeViewModel objModel)
        {
            return _CustodyTypeRepository.Delete(objModel);
        }
    }
}
