﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class IncomeTypeService : IIncomeTypeService
    {
        private readonly IIncomeTypeRepository _IncomeTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public IncomeTypeService(IIncomeTypeRepository IncomeTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._IncomeTypeRepository = IncomeTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<IncomeTypeViewModel> GetListAll()
        {
            return _IncomeTypeRepository.GetListAll();
        }

        public List<IncomeTypeViewModel> GetListById(int? Id)
        {
            return _IncomeTypeRepository.GetListById(Id);
        }

        public List<IncomeTypeViewModel> GetListByStatusId(int? StatusId)
        {
            return _IncomeTypeRepository.GetListByStatusId(StatusId);
        }

        public List<IncomeTypeViewModel> GetListByTypeId(int? TypeId)
        {
            return _IncomeTypeRepository.GetListByTypeId(TypeId);
        }

        public List<IncomeTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _IncomeTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<IncomeTypeViewModel> GetListActiveAll()
        {
            return _IncomeTypeRepository.GetListActiveAll();
        }

        public List<IncomeTypeViewModel> GetListActiveById(int? Id)
        {
            return _IncomeTypeRepository.GetListActiveById(Id);
        }

        public List<IncomeTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _IncomeTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<IncomeTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _IncomeTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<IncomeTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _IncomeTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(IncomeTypeViewModel objModel)
        {
            return _IncomeTypeRepository.Create(objModel);
        }

        public bool Update(IncomeTypeViewModel objModel)
        {
            return _IncomeTypeRepository.Update(objModel);
        }

        public bool Delete(IncomeTypeViewModel objModel)
        {
            return _IncomeTypeRepository.Delete(objModel);
        }
    }
}
