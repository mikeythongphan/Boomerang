﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class LabourContractTypeService : ILabourContractTypeService
    {
        private readonly ILabourContractTypeRepository _LabourContractTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public LabourContractTypeService(ILabourContractTypeRepository LabourContractTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._LabourContractTypeRepository = LabourContractTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<LabourContractTypeViewModel> GetListAll()
        {
            return _LabourContractTypeRepository.GetListAll();
        }

        public List<LabourContractTypeViewModel> GetListById(int? Id)
        {
            return _LabourContractTypeRepository.GetListById(Id);
        }

        public List<LabourContractTypeViewModel> GetListByStatusId(int? StatusId)
        {
            return _LabourContractTypeRepository.GetListByStatusId(StatusId);
        }

        public List<LabourContractTypeViewModel> GetListByTypeId(int? TypeId)
        {
            return _LabourContractTypeRepository.GetListByTypeId(TypeId);
        }

        public List<LabourContractTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _LabourContractTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<LabourContractTypeViewModel> GetListActiveAll()
        {
            return _LabourContractTypeRepository.GetListActiveAll();
        }

        public List<LabourContractTypeViewModel> GetListActiveById(int? Id)
        {
            return _LabourContractTypeRepository.GetListActiveById(Id);
        }

        public List<LabourContractTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _LabourContractTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<LabourContractTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _LabourContractTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<LabourContractTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _LabourContractTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(LabourContractTypeViewModel objModel)
        {
            return _LabourContractTypeRepository.Create(objModel);
        }

        public bool Update(LabourContractTypeViewModel objModel)
        {
            return _LabourContractTypeRepository.Update(objModel);
        }

        public bool Delete(LabourContractTypeViewModel objModel)
        {
            return _LabourContractTypeRepository.Delete(objModel);
        }
    }
}
