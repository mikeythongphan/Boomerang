﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class NationalityService : INationalityService
    {
        private readonly INationalityRepository _NationalityRepository;

        private readonly IUnitOfWork _unitOfWork;

        public NationalityService(INationalityRepository NationalityRepository,
            IUnitOfWork unitOfWork)
        {
            this._NationalityRepository = NationalityRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<NationalityViewModel> GetListAll()
        {
            return _NationalityRepository.GetListAll();
        }

        public List<NationalityViewModel> GetListById(int? Id)
        {
            return _NationalityRepository.GetListById(Id);
        }

        public List<NationalityViewModel> GetListByStatusId(int? StatusId)
        {
            return _NationalityRepository.GetListByStatusId(StatusId);
        }

        public List<NationalityViewModel> GetListByTypeId(int? TypeId)
        {
            return _NationalityRepository.GetListByTypeId(TypeId);
        }

        public List<NationalityViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _NationalityRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<NationalityViewModel> GetListActiveAll()
        {
            return _NationalityRepository.GetListActiveAll();
        }

        public List<NationalityViewModel> GetListActiveById(int? Id)
        {
            return _NationalityRepository.GetListActiveById(Id);
        }

        public List<NationalityViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _NationalityRepository.GetListActiveByStatusId(StatusId);
        }

        public List<NationalityViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _NationalityRepository.GetListActiveByTypeId(TypeId);
        }

        public List<NationalityViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _NationalityRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(NationalityViewModel objModel)
        {
            return _NationalityRepository.Create(objModel);
        }

        public bool Update(NationalityViewModel objModel)
        {
            return _NationalityRepository.Update(objModel);
        }

        public bool Delete(NationalityViewModel objModel)
        {
            return _NationalityRepository.Delete(objModel);
        }
    }
}
