﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class PaymentMethodService : IPaymentMethodService
    {
        private readonly IPaymentMethodRepository _PaymentMethodRepository;

        private readonly IUnitOfWork _unitOfWork;

        public PaymentMethodService(IPaymentMethodRepository PaymentMethodRepository,
            IUnitOfWork unitOfWork)
        {
            this._PaymentMethodRepository = PaymentMethodRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<PaymentMethodViewModel> GetListAll()
        {
            return _PaymentMethodRepository.GetListAll();
        }

        public List<PaymentMethodViewModel> GetListById(int? Id)
        {
            return _PaymentMethodRepository.GetListById(Id);
        }

        public List<PaymentMethodViewModel> GetListByStatusId(int? StatusId)
        {
            return _PaymentMethodRepository.GetListByStatusId(StatusId);
        }

        public List<PaymentMethodViewModel> GetListByTypeId(int? TypeId)
        {
            return _PaymentMethodRepository.GetListByTypeId(TypeId);
        }

        public List<PaymentMethodViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _PaymentMethodRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<PaymentMethodViewModel> GetListActiveAll()
        {
            return _PaymentMethodRepository.GetListActiveAll();
        }

        public List<PaymentMethodViewModel> GetListActiveById(int? Id)
        {
            return _PaymentMethodRepository.GetListActiveById(Id);
        }

        public List<PaymentMethodViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _PaymentMethodRepository.GetListActiveByStatusId(StatusId);
        }

        public List<PaymentMethodViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _PaymentMethodRepository.GetListActiveByTypeId(TypeId);
        }

        public List<PaymentMethodViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _PaymentMethodRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(PaymentMethodViewModel objModel)
        {
            return _PaymentMethodRepository.Create(objModel);
        }

        public bool Update(PaymentMethodViewModel objModel)
        {
            return _PaymentMethodRepository.Update(objModel);
        }

        public bool Delete(PaymentMethodViewModel objModel)
        {
            return _PaymentMethodRepository.Delete(objModel);
        }
    }
}
