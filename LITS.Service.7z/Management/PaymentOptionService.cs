﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class PaymentOptionService : IPaymentOptionService
    {
        private readonly IPaymentOptionRepository _PaymentOptionRepository;

        private readonly IUnitOfWork _unitOfWork;

        public PaymentOptionService(IPaymentOptionRepository PaymentOptionRepository,
            IUnitOfWork unitOfWork)
        {
            this._PaymentOptionRepository = PaymentOptionRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<PaymentOptionViewModel> GetListAll()
        {
            return _PaymentOptionRepository.GetListAll();
        }

        public List<PaymentOptionViewModel> GetListById(int? Id)
        {
            return _PaymentOptionRepository.GetListById(Id);
        }

        public List<PaymentOptionViewModel> GetListByStatusId(int? StatusId)
        {
            return _PaymentOptionRepository.GetListByStatusId(StatusId);
        }

        public List<PaymentOptionViewModel> GetListByTypeId(int? TypeId)
        {
            return _PaymentOptionRepository.GetListByTypeId(TypeId);
        }

        public List<PaymentOptionViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _PaymentOptionRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<PaymentOptionViewModel> GetListActiveAll()
        {
            return _PaymentOptionRepository.GetListActiveAll();
        }

        public List<PaymentOptionViewModel> GetListActiveById(int? Id)
        {
            return _PaymentOptionRepository.GetListActiveById(Id);
        }

        public List<PaymentOptionViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _PaymentOptionRepository.GetListActiveByStatusId(StatusId);
        }

        public List<PaymentOptionViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _PaymentOptionRepository.GetListActiveByTypeId(TypeId);
        }

        public List<PaymentOptionViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _PaymentOptionRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(PaymentOptionViewModel objModel)
        {
            return _PaymentOptionRepository.Create(objModel);
        }

        public bool Update(PaymentOptionViewModel objModel)
        {
            return _PaymentOptionRepository.Update(objModel);
        }

        public bool Delete(PaymentOptionViewModel objModel)
        {
            return _PaymentOptionRepository.Delete(objModel);
        }
    }
}
