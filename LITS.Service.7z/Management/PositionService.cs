﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class PositionService : IPositionService
    {
        private readonly IPositionRepository _PositionRepository;

        private readonly IUnitOfWork _unitOfWork;

        public PositionService(IPositionRepository PositionRepository,
            IUnitOfWork unitOfWork)
        {
            this._PositionRepository = PositionRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<PositionViewModel> GetListAll()
        {
            return _PositionRepository.GetListAll();
        }

        public List<PositionViewModel> GetListById(int? Id)
        {
            return _PositionRepository.GetListById(Id);
        }

        public List<PositionViewModel> GetListByStatusId(int? StatusId)
        {
            return _PositionRepository.GetListByStatusId(StatusId);
        }

        public List<PositionViewModel> GetListByTypeId(int? TypeId)
        {
            return _PositionRepository.GetListByTypeId(TypeId);
        }

        public List<PositionViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _PositionRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<PositionViewModel> GetListActiveAll()
        {
            return _PositionRepository.GetListActiveAll();
        }

        public List<PositionViewModel> GetListActiveById(int? Id)
        {
            return _PositionRepository.GetListActiveById(Id);
        }

        public List<PositionViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _PositionRepository.GetListActiveByStatusId(StatusId);
        }

        public List<PositionViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _PositionRepository.GetListActiveByTypeId(TypeId);
        }

        public List<PositionViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _PositionRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(PositionViewModel objModel)
        {
            return _PositionRepository.Create(objModel);
        }

        public bool Update(PositionViewModel objModel)
        {
            return _PositionRepository.Update(objModel);
        }

        public bool Delete(PositionViewModel objModel)
        {
            return _PositionRepository.Delete(objModel);
        }
    }
}
