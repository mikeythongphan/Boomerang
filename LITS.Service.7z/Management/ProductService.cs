﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _ProductRepository;

        private readonly IUnitOfWork _unitOfWork;

        public ProductService(IProductRepository ProductRepository,
            IUnitOfWork unitOfWork)
        {
            this._ProductRepository = ProductRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<ProductViewModel> GetListAll()
        {
            return _ProductRepository.GetListAll();
        }

        public List<ProductViewModel> GetListById(int? Id)
        {
            return _ProductRepository.GetListById(Id);
        }

        public List<ProductViewModel> GetListByStatusId(int? StatusId)
        {
            return _ProductRepository.GetListByStatusId(StatusId);
        }

        public List<ProductViewModel> GetListByTypeId(int? TypeId)
        {
            return _ProductRepository.GetListByTypeId(TypeId);
        }

        public List<ProductViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _ProductRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<ProductViewModel> GetListActiveAll()
        {
            return _ProductRepository.GetListActiveAll();
        }

        public List<ProductViewModel> GetListActiveById(int? Id)
        {
            return _ProductRepository.GetListActiveById(Id);
        }

        public List<ProductViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _ProductRepository.GetListActiveByStatusId(StatusId);
        }

        public List<ProductViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _ProductRepository.GetListActiveByTypeId(TypeId);
        }

        public List<ProductViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _ProductRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(ProductViewModel objModel)
        {
            return _ProductRepository.Create(objModel);
        }

        public bool Update(ProductViewModel objModel)
        {
            return _ProductRepository.Update(objModel);
        }

        public bool Delete(ProductViewModel objModel)
        {
            return _ProductRepository.Delete(objModel);
        }
    }
}
