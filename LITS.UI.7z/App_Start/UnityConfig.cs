using System;
using Unity;
using System.Web;
using System.Data.Entity;
using System.Web.Mvc;
using Microsoft.Owin.Security;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Configuration;
using LITS.UI.Models;

#region Interface
using LITS.Interface.Service.AutoLoan.SalesCoordinators;
using LITS.Interface.Service.AutoLoan.OperationSupport;
using LITS.Interface.Service.Main.WorkInProgress;
using LITS.Interface.Service.Main.ReportsChart;
using LITS.Interface.Service.Main.ReportsExport;
using LITS.Interface.Service.Main.CreateNewLoan;
using LITS.Interface.Service.Management;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Interface.Repository.AutoLoan.OperationSupport;
using LITS.Interface.Repository.Management;
using LITS.Interface.Repository.Main.CreateNewLoan;
using LITS.Interface.Repository.Main.WorkInProgress;
using LITS.Interface.Repository.Main.ReportsChart;
using LITS.Interface.Repository.Main.ReportsExport;
#endregion 

#region Repository
using LITS.Data.Repository.AutoLoan.SalesCoordinators;
using LITS.Data.Repository.AutoLoan.OperationSupport;
using LITS.Data.Repository.Management;
using LITS.Data.Repository.Main.WorkInProgress;
using LITS.Data.Repository.Main.ReportsChart;
using LITS.Data.Repository.Main.ReportsExport;
using LITS.Data.Repository.Main.CreateNewLoan;
#endregion

#region Service
using LITS.Service.AutoLoan.SalesCoordinators;
using LITS.Service.AutoLoan.OperationSupport;
using LITS.Service.Main.WorkInProgress;
using LITS.Service.Main.ReportsChart;
using LITS.Service.Main.ReportsExport;
using LITS.Service.Main.CreateNewLoan;
using LITS.Service.Management;
#endregion

namespace LITS.UI
{
    /// <summary>
    /// Specifies the Unity configuration for the main container.
    /// </summary>
    public static class UnityConfig
    {
        #region Unity Container
        private static Lazy<IUnityContainer> container =
          new Lazy<IUnityContainer>(() =>
          {
              var container = new UnityContainer();
              RegisterTypes(container);
              return container;
          });

        /// <summary>
        /// Configured Unity Container.
        /// </summary>
        public static IUnityContainer Container => container.Value;
        #endregion

        /// <summary>
        /// Registers the type mappings with the Unity container.
        /// </summary>
        /// <param name="container">The unity container to configure.</param>
        /// <remarks>
        /// There is no need to register concrete types such as controllers or
        /// API controllers (unless you want to change the defaults), as Unity
        /// allows resolving a concrete type even if it was not previously
        /// registered.
        /// </remarks>
        public static void RegisterTypes(IUnityContainer container)
        {
            #region DbContext
            container.RegisterType<DbContext, LITSEntities>();
            container.RegisterType<DbContext, ADCSEntities>();
            container.RegisterType<DbContext, ApplicationDbContext>();
            #endregion

            #region Controller
            container.RegisterType<IController, Controller>();
            #endregion

            #region Identity
            container.RegisterType<Infrastructure.Factory.IUnitOfWork, Infrastructure.Factory.UnitOfWork>();
            container.RegisterType<Infrastructure.Configuration.IUnitOfWork, Infrastructure.Configuration.UnitOfWork>();
            container.RegisterType<IUnitOfWorkManager, UnitOfWorkManager>();
            container.RegisterType<IDisposable, Disposable>();
            container.RegisterType<IDatabaseFactory, DatabaseFactory>();
            container.RegisterType<IUserStore<ApplicationUser>, UserStore<ApplicationUser>>();
            container.RegisterType<IRoleStore<ApplicationRole, string>, RoleStore<ApplicationRole>>();
            container.RegisterType<IAuthenticationManager>
                (new Unity.Injection.InjectionFactory(x => HttpContext.Current.GetOwinContext().Authentication));
            #endregion

            #region Repository

            #region SalesCoordinators
            container.RegisterType<Interface.Repository.AutoLoan.SalesCoordinators.IApplicationInformationRepository,
                Data.Repository.AutoLoan.SalesCoordinators.ApplicationInformationRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.SalesCoordinators.ICustomerInformationRepository,
                Data.Repository.AutoLoan.SalesCoordinators.CustomerInformationRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.SalesCoordinators.ISalesCoordinatorsRepository,
                Data.Repository.AutoLoan.SalesCoordinators.SalesCoordinatorsRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.SalesCoordinators.IAppliedLoanInformationRepository,
                Data.Repository.AutoLoan.SalesCoordinators.AppliedLoanInformationRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.SalesCoordinators.IARTARepository,
                Data.Repository.AutoLoan.SalesCoordinators.ARTARepository>();
            container.RegisterType<Interface.Repository.AutoLoan.SalesCoordinators.ICarDealerInformationRepository,
                Data.Repository.AutoLoan.SalesCoordinators.CarDealerInformationRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.SalesCoordinators.ICollateralInformationRepository,
                Data.Repository.AutoLoan.SalesCoordinators.CollateralInformationRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.SalesCoordinators.ICustomerCreditBureauRepository,
                Data.Repository.AutoLoan.SalesCoordinators.CustomerCreditBureauRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.SalesCoordinators.ICustomerDemostrationRepository,
                Data.Repository.AutoLoan.SalesCoordinators.CustomerDemostrationRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.SalesCoordinators.ICustomerIncomeRepository,
                Data.Repository.AutoLoan.SalesCoordinators.CustomerIncomeRepository>();
            #endregion

            #region OperationSupport
            container.RegisterType<Interface.Repository.AutoLoan.OperationSupport.IOperationSupportRepository,
                Data.Repository.AutoLoan.OperationSupport.OperationSupportRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.OperationSupport.IApplicationInformationRepository,
                Data.Repository.AutoLoan.OperationSupport.ApplicationInformationRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.OperationSupport.IAppliedLoanInformationRepository,
                Data.Repository.AutoLoan.OperationSupport.AppliedLoanInformationRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.OperationSupport.IARTARepository,
                Data.Repository.AutoLoan.OperationSupport.ARTARepository>();
            container.RegisterType<Interface.Repository.AutoLoan.OperationSupport.ICarDealerInformationRepository,
                Data.Repository.AutoLoan.OperationSupport.CarDealerInformationRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.OperationSupport.ICollateralInformationRepository,
                Data.Repository.AutoLoan.OperationSupport.CollateralInformationRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.OperationSupport.ICustomerCreditBureauRepository,
                Data.Repository.AutoLoan.OperationSupport.CustomerCreditBureauRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.OperationSupport.ICustomerDemostrationRepository,
                Data.Repository.AutoLoan.OperationSupport.CustomerDemostrationRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.OperationSupport.ICustomerIncomeRepository,
                Data.Repository.AutoLoan.OperationSupport.CustomerIncomeRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.OperationSupport.ICustomerInformationRepository,
                Data.Repository.AutoLoan.OperationSupport.CustomerInformationRepository>();
            #endregion

            #region LendingOperation
            container.RegisterType<Interface.Repository.AutoLoan.LendingOperation.ILendingOperationRepository,
                Data.Repository.AutoLoan.LendingOperation.LendingOperationRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.LendingOperation.IDisbursementInformationRepository,
                Data.Repository.AutoLoan.LendingOperation.DisbursementInformationRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.LendingOperation.IDisbursementRepository,
                Data.Repository.AutoLoan.LendingOperation.DisbursementRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.LendingOperation.IInsuranceRepository,
                Data.Repository.AutoLoan.LendingOperation.InsuranceRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.LendingOperation.IPersonalDetailRepository,
                Data.Repository.AutoLoan.LendingOperation.PersonalDetailRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.LendingOperation.IPostDisbursementConditionRepository,
                Data.Repository.AutoLoan.LendingOperation.PostDisbursementConditionRepository>();
            #endregion

            #region CreditInitiative
            container.RegisterType<Interface.Repository.AutoLoan.CreditInitiative.ICreditInitiativeRepository,
                Data.Repository.AutoLoan.CreditInitiative.CreditInitiativeRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.CreditInitiative.IApplicationInformationRepository,
                Data.Repository.AutoLoan.CreditInitiative.ApplicationInformationRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.CreditInitiative.IAppliedLoanInformationRepository,
                Data.Repository.AutoLoan.CreditInitiative.AppliedLoanInformationRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.CreditInitiative.IApprovalInformationRepository,
                Data.Repository.AutoLoan.CreditInitiative.ApprovalInformationRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.CreditInitiative.IARTARepository,
                Data.Repository.AutoLoan.CreditInitiative.ARTARepository>();
            container.RegisterType<Interface.Repository.AutoLoan.CreditInitiative.ICollateralInformationRepository,
                Data.Repository.AutoLoan.CreditInitiative.CollateralInformationRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.CreditInitiative.ICustomerCreditBureauRepository,
                Data.Repository.AutoLoan.CreditInitiative.CustomerCreditBureauRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.CreditInitiative.ICustomerDemostrationRepository,
                Data.Repository.AutoLoan.CreditInitiative.CustomerDemostrationRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.CreditInitiative.ICustomerIncomeRepository,
                Data.Repository.AutoLoan.CreditInitiative.CustomerIncomeRepository>();
            container.RegisterType<Interface.Repository.AutoLoan.CreditInitiative.ICustomerInformationRepository,
                Data.Repository.AutoLoan.CreditInitiative.CustomerInformationRepository>();
            #endregion

            #region Main
            container.RegisterType<IWorkInProgressRepository, WorkInProgressRepository>();
            container.RegisterType<IWorkInProgressDetailRepository, WorkInProgressDetailRepository>();
            container.RegisterType<IWorkInProgressMasterRepository, WorkInProgressMasterRepository>();
            container.RegisterType<IWorkInProgressTreeRepository, WorkInProgressTreeRepository>();
            container.RegisterType<IReportsChartRepository, ReportsChartRepository>();
            container.RegisterType<IReportsChartDetailRepository, ReportsChartDetailRepository>();
            container.RegisterType<IReportsChartMasterRepository, ReportsChartMasterRepository>();
            container.RegisterType<IReportsChartTreeRepository, ReportsChartTreeRepository>();
            container.RegisterType<IReportsExportRepository, ReportsExportRepository>();
            container.RegisterType<IReportsExportDetailRepository, ReportsExportDetailRepository>();
            container.RegisterType<IReportsExportMasterRepository, ReportsExportMasterRepository>();
            container.RegisterType<IReportsExportTreeRepository, ReportsExportTreeRepository>();

            container.RegisterType<ICreateNewLoanRepository, CreateNewLoanRepository>();
            container.RegisterType<ICreateNewLoanStep1Repository, CreateNewLoanStep1Repository>();
            container.RegisterType<ICreateNewLoanStep2Repository, CreateNewLoanStep2Repository>();
            container.RegisterType<ICreateNewLoanStep3Repository, CreateNewLoanStep3Repository>();
            #endregion

            #region Management
            container.RegisterType<IBankHolidayRepository, BankHolidayRepository>();
            container.RegisterType<IBankTypeRepository, BankTypeRepository>();
            container.RegisterType<IBonusTypeRepository, BonusTypeRepository>();
            container.RegisterType<IBorrowerTypeRepository, BorrowerTypeRepository>();
            container.RegisterType<IBranchCodeRepository, BranchCodeRepository>();
            container.RegisterType<IBranchLocationRepository, BranchLocationRepository>();
            container.RegisterType<IBusinessNatureRepository, BusinessNatureRepository>();
            container.RegisterType<IBusinessTypeRepository, BusinessTypeRepository>();
            container.RegisterType<ICampaignCodeRepository, CampaignCodeRepository>();
            container.RegisterType<ICDDRepository, CDDRepository>();
            container.RegisterType<ICICRepository, CicRepository>();
            container.RegisterType<ICityRepository, CityRepository>();
            container.RegisterType<ICommisionTypeRepository, CommisionTypeRepository>();
            container.RegisterType<ICompanyCodeRepository, CompanyCodeRepository>();
            container.RegisterType<ICompanyTypeRepository, CompanyTypeRepository>();
            container.RegisterType<ICreditBureauTypeRepository, CreditBureauTypeRepository>();
            container.RegisterType<ICreditDeviationRepository, CreditDeviationRepository>();
            container.RegisterType<ICriteriaRepository, CriteriaRepository>();
            container.RegisterType<ICurrentResidentTypeRepository, CurrentResidentTypeRepository>();
            container.RegisterType<ICustodyTypeRepository, CustodyTypeRepository>();
            container.RegisterType<ICustomerRelationshipRepository, CustomerRelationshipRepository>();
            container.RegisterType<ICustomerSegmentRepository, CustomerSegmentRepository>();
            container.RegisterType<ICustomerTypeRepository, CustomerTypeRepository>();
            container.RegisterType<IDefinitionTypeRepository, DefinitionTypeRepository>();
            container.RegisterType<IDeviationCodeRepository, DeviationCodeRepository>();
            container.RegisterType<IDisbursalScenarioConditionRepository, DisbursalScenarioConditionRepository>();
            container.RegisterType<IDisbursalScenarioRepository, DisbursalScenarioRepository>();
            container.RegisterType<IDistrictRepository, DistrictRepository>();
            container.RegisterType<IDuplicationTypeRepository, DuplicationTypeRepository>();
            container.RegisterType<IEducationRepository, EducationRepository>();
            container.RegisterType<IEmploymentTypeRepository, EmploymentTypeRepository>();
            container.RegisterType<IFloatingInterestRateRepository, FloatingInterestRateRepository>();
            container.RegisterType<IIdentificationTypeRepository, IdentificationTypeRepository>();
            container.RegisterType<IIncomeTypeRepository, IncomeTypeRepository>();
            container.RegisterType<IIndustryRepository, IndustryRepository>();
            container.RegisterType<IInterestClassificationRepository, InterestClassificationRepository>();
            container.RegisterType<IInvestigaveTypeRepository, InvestigaveTypeRepository>();
            container.RegisterType<ILabourContractTypeRepository, LabourContractTypeRepository>();
            container.RegisterType<ILoanPurposeRepository, LoanPurposeRepository>();
            container.RegisterType<ILoanTenorRepository, LoanTenorRepository>();
            container.RegisterType<ILoanTrendRepository, LoanTrendRepository>();
            container.RegisterType<ILoanTypeRepository, LoanTypeRepository>();
            container.RegisterType<IMaritalStatusRepository, MaritalStatusRepository>();
            container.RegisterType<IMessageRepository, MessageRepository>();
            container.RegisterType<IMessageTypeRepository, MessageTypeRepository>();
            container.RegisterType<INationalityRepository, NationalityRepository>();
            container.RegisterType<IOccupationRepository, OccupationRepository>();
            container.RegisterType<IOwnershipTypeRepository, OwnershipTypeRepository>();
            container.RegisterType<IPaymentTypeRepository, PaymentTypeRepository>();
            container.RegisterType<IPositionRepository, PositionRepository>();
            container.RegisterType<IProductRepository, ProductRepository>();
            container.RegisterType<IProductTypeRepository, ProductTypeRepository>();
            container.RegisterType<IProgramCodeRepository, ProgramCodeRepository>();
            container.RegisterType<IProgramTypeRepository, ProgramTypeRepository>();
            container.RegisterType<IPropertySaleRepository, PropertySaleRepository>();
            container.RegisterType<IPropertyStatusRepository, PropertyStatusRepository>();
            container.RegisterType<IPropertyTypeRepository, PropertyTypeRepository>();
            container.RegisterType<IReasonRepository, ReasonRepository>();
            container.RegisterType<IResidenceOwnershipRepository, ResidenceOwnershipRepository>();
            container.RegisterType<IStatusRepository, StatusRepository>();
            container.RegisterType<ITradingAreaRepository, TradingAreaRepository>();
            container.RegisterType<ISalesChannelRepository, SalesChannelRepository>();
            container.RegisterType<ITypeRepository, TypeRepository>();
            container.RegisterType<IDefinitionTypeRepository, DefinitionTypeRepository>();
            container.RegisterType<IPaymentMethodRepository, PaymentMethodRepository>();
            container.RegisterType<IPaymentOptionRepository, PaymentOptionRepository>();
            #endregion

            #endregion

            #region Service

            #region SalesCoordinators
            container.RegisterType<Interface.Service.AutoLoan.SalesCoordinators.IApplicationInformationService,
                Service.AutoLoan.SalesCoordinators.ApplicationInformationService>();
            container.RegisterType<Interface.Service.AutoLoan.SalesCoordinators.ICustomerInformationService,
                Service.AutoLoan.SalesCoordinators.CustomerInformationService>();
            container.RegisterType<Interface.Service.AutoLoan.SalesCoordinators.IAppliedLoanInformationService,
                Service.AutoLoan.SalesCoordinators.AppliedLoanInformationService>();
            container.RegisterType<Interface.Service.AutoLoan.SalesCoordinators.IARTAService,
                Service.AutoLoan.SalesCoordinators.ARTAService>();
            container.RegisterType<Interface.Service.AutoLoan.SalesCoordinators.ICarDealerInformationService,
                Service.AutoLoan.SalesCoordinators.CarDealerInformationService>();
            container.RegisterType<Interface.Service.AutoLoan.SalesCoordinators.ICollateralInformationService,
                Service.AutoLoan.SalesCoordinators.CollateralInformationService>();
            container.RegisterType<Interface.Service.AutoLoan.SalesCoordinators.ICustomerCreditBureauService,
                Service.AutoLoan.SalesCoordinators.CustomerCreditBureauService>();
            container.RegisterType<Interface.Service.AutoLoan.SalesCoordinators.ICustomerDemostrationService,
                Service.AutoLoan.SalesCoordinators.CustomerDemostrationService>();
            container.RegisterType<Interface.Service.AutoLoan.SalesCoordinators.ICustomerIncomeService,
                Service.AutoLoan.SalesCoordinators.CustomerIncomeService>();
            container.RegisterType<Interface.Service.AutoLoan.SalesCoordinators.ISalesCoordinatorsService,
                Service.AutoLoan.SalesCoordinators.SalesCoordinatorsService>();
            #endregion

            #region OperationSupport
            container.RegisterType<Interface.Service.AutoLoan.OperationSupport.IApplicationInformationService,
                Service.AutoLoan.OperationSupport.ApplicationInformationService>();
            container.RegisterType<Interface.Service.AutoLoan.OperationSupport.IAppliedLoanInformationService,
                Service.AutoLoan.OperationSupport.AppliedLoanInformationService>();
            container.RegisterType<Interface.Service.AutoLoan.OperationSupport.IARTAService,
                Service.AutoLoan.OperationSupport.ARTAService>();
            container.RegisterType<Interface.Service.AutoLoan.OperationSupport.ICarDealerInformationService,
                Service.AutoLoan.OperationSupport.CarDealerInformationService>();
            container.RegisterType<Interface.Service.AutoLoan.OperationSupport.ICollateralInformationService,
                Service.AutoLoan.OperationSupport.CollateralInformationService>();
            container.RegisterType<Interface.Service.AutoLoan.OperationSupport.ICustomerCreditBureauService,
                Service.AutoLoan.OperationSupport.CustomerCreditBureauService>();
            container.RegisterType<Interface.Service.AutoLoan.OperationSupport.ICustomerDemostrationService,
                Service.AutoLoan.OperationSupport.CustomerDemostrationService>();
            container.RegisterType<Interface.Service.AutoLoan.OperationSupport.ICustomerIncomeService,
                Service.AutoLoan.OperationSupport.CustomerIncomeService>();
            container.RegisterType<Interface.Service.AutoLoan.OperationSupport.ICustomerInformationService,
                Service.AutoLoan.OperationSupport.CustomerInformationService>();
            container.RegisterType<Interface.Service.AutoLoan.OperationSupport.IOperationSupportService,
                Service.AutoLoan.OperationSupport.OperationSupportService>();
            #endregion

            #region LendingOperation
            container.RegisterType<Interface.Service.AutoLoan.LendingOperation.IDisbursementInformationService,
                Service.AutoLoan.LendingOperation.DisbursementInformationService>();
            container.RegisterType<Interface.Service.AutoLoan.LendingOperation.IDisbursementService,
                Service.AutoLoan.LendingOperation.DisbursementService>();
            container.RegisterType<Interface.Service.AutoLoan.LendingOperation.IInsuranceService,
                Service.AutoLoan.LendingOperation.InsuranceService>();
            container.RegisterType<Interface.Service.AutoLoan.LendingOperation.IPersonalDetailService,
                Service.AutoLoan.LendingOperation.PersonalDetailService>();
            container.RegisterType<Interface.Service.AutoLoan.LendingOperation.IPostDisbursementConditionService,
                Service.AutoLoan.LendingOperation.PostDisbursementConditionService>();
            container.RegisterType<Interface.Service.AutoLoan.LendingOperation.ILendingOperationService,
                Service.AutoLoan.LendingOperation.LendingOperationService>();
            #endregion

            #region CreditInitiative
            container.RegisterType<Interface.Service.AutoLoan.CreditInitiative.IApplicationInformationService,
                Service.AutoLoan.CreditInitiative.ApplicationInformationService>();
            container.RegisterType<Interface.Service.AutoLoan.CreditInitiative.IAppliedLoanInformationService,
                Service.AutoLoan.CreditInitiative.AppliedLoanInformationService>();
            container.RegisterType<Interface.Service.AutoLoan.CreditInitiative.IApprovalInformationService,
                Service.AutoLoan.CreditInitiative.ApprovalInformationService>();
            container.RegisterType<Interface.Service.AutoLoan.CreditInitiative.IARTAService,
                Service.AutoLoan.CreditInitiative.ARTAService>();
            container.RegisterType<Interface.Service.AutoLoan.CreditInitiative.ICollateralInformationService,
                Service.AutoLoan.CreditInitiative.CollateralInformationService>();
            container.RegisterType<Interface.Service.AutoLoan.CreditInitiative.ICreditInitiativeService,
                Service.AutoLoan.CreditInitiative.CreditInitiativeService>();
            container.RegisterType<Interface.Service.AutoLoan.CreditInitiative.ICustomerCreditBureauService,
                Service.AutoLoan.CreditInitiative.CustomerCreditBureauService>();
            container.RegisterType<Interface.Service.AutoLoan.CreditInitiative.ICustomerDemostrationService,
                Service.AutoLoan.CreditInitiative.CustomerDemostrationService>();
            container.RegisterType<Interface.Service.AutoLoan.CreditInitiative.ICustomerIncomeService,
                Service.AutoLoan.CreditInitiative.CustomerIncomeService>();
            container.RegisterType<Interface.Service.AutoLoan.CreditInitiative.ICustomerInformationService,
                Service.AutoLoan.CreditInitiative.CustomerInformationService>();
            #endregion

            #region Main
            container.RegisterType<IWorkInProgressService, WorkInProgressService>();
            container.RegisterType<IReportsChartService, ReportsChartService>();
            container.RegisterType<IReportsExportService, ReportsExportService>();
            container.RegisterType<ICreateNewLoanService, CreateNewLoanService>();
            #endregion

            #region Management
            container.RegisterType<IBankHolidayService, BankHolidayService>();
            container.RegisterType<IBankTypeService, BankTypeService>();
            container.RegisterType<IBonusTypeService, BonusTypeService>();
            container.RegisterType<IBorrowerTypeService, BorrowerTypeService>();
            container.RegisterType<IBranchCodeService, BranchCodeService>();
            container.RegisterType<IBranchLocationService, BranchLocationService>();
            container.RegisterType<IBusinessNatureService, BusinessNatureService>();
            container.RegisterType<IBusinessTypeService, BusinessTypeService>();
            container.RegisterType<ICampaignCodeService, CampaignCodeService>();
            container.RegisterType<ICDDService, CDDService>();
            container.RegisterType<ICICService, CICService>();
            container.RegisterType<ICityService, CityService>();
            container.RegisterType<ICommisionTypeService, CommisionTypeService>();
            container.RegisterType<ICompanyCodeService, CompanyCodeService>();
            container.RegisterType<ICompanyTypeService, CompanyTypeService>();
            container.RegisterType<ICreditBureauTypeService, CreditBureauTypeService>();
            container.RegisterType<ICreditDeviationService, CreditDeviationService>();
            container.RegisterType<ICriteriaService, CriteriaService>();
            container.RegisterType<ICurrentResidentTypeService, CurrentResidentTypeService>();
            container.RegisterType<ICustodyTypeService, CustodyTypeService>();
            container.RegisterType<ICustomerRelationshipService, CustomerRelationshipService>();
            container.RegisterType<ICustomerSegmentService, CustomerSegmentService>();
            container.RegisterType<ICustomerTypeService, CustomerTypeService>();
            container.RegisterType<IDeviationCodeService, DeviationCodeService>();
            container.RegisterType<IDisbursalScenarioConditionService, DisbursalScenarioConditionService>();
            container.RegisterType<IDisbursalScenarioService, DisbursalScenarioService>();
            container.RegisterType<IDistrictService, DistrictService>();
            container.RegisterType<IDuplicationTypeService, DuplicationTypeService>();
            container.RegisterType<IEducationService, EducationService>();
            container.RegisterType<IEmploymentTypeService, EmploymentTypeService>();
            container.RegisterType<IFloatingInterestRateService, FloatingInterestRateService>();
            container.RegisterType<IIdentificationTypeService, IdentificationTypeService>();
            container.RegisterType<IIncomeTypeService, IncomeTypeService>();
            container.RegisterType<IIndustryService, IndustryService>();
            container.RegisterType<IInterestClassificationService, InterestClassificationService>();
            container.RegisterType<IInvestigaveTypeService, InvestigaveTypeService>();
            container.RegisterType<ILabourContractTypeService, LabourContractTypeService>();
            container.RegisterType<ILoanPurposeService, LoanPurposeService>();
            container.RegisterType<ILoanTenorService, LoanTenorService>();
            container.RegisterType<ILoanTrendService, LoanTrendService>();
            container.RegisterType<ILoanTypeService, LoanTypeService>();
            container.RegisterType<IMaritalStatusService, MaritalStatusService>();
            container.RegisterType<IMessageService, MessageService>();
            container.RegisterType<IMessageTypeService, MessageTypeService>();
            container.RegisterType<INationalityService, NationalityService>();
            container.RegisterType<IOccupationService, OccupationService>();
            container.RegisterType<IOwnershipTypeService, OwnershipTypeService>();
            container.RegisterType<IPaymentTypeService, PaymentTypeService>();
            container.RegisterType<IPositionService, PositionService>();
            container.RegisterType<IProductService, ProductService>();
            container.RegisterType<IProductTypeService, ProductTypeService>();
            container.RegisterType<IProgramCodeService, ProgramCodeService>();
            container.RegisterType<IProgramTypeService, ProgramTypeService>();
            container.RegisterType<IPropertySaleService, PropertySaleService>();
            container.RegisterType<IPropertyStatusService, PropertyStatusService>();
            container.RegisterType<IPropertyTypeService, PropertyTypeService>();
            container.RegisterType<IReasonService, ReasonService>();
            container.RegisterType<IResidenceOwnershipService, ResidenceOwnershipService>();
            container.RegisterType<IStatusService, StatusService>();
            container.RegisterType<ITradingAreaService, TradingAreaService>();
            container.RegisterType<ISalesChannelService, SalesChannelService>();
            container.RegisterType<ITypeService, TypeService>();
            container.RegisterType<IPaymentMethodService, PaymentMethodService>();
            container.RegisterType<IPaymentOptionService, PaymentOptionService>();
            container.RegisterType<IDefinitionTypeService, DefinitionTypeService>();

            #endregion

            #endregion
        }
    }
}