﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LITS.Model.Views.Main;
using LITS.UI.Custom;

namespace LITS.UI.Areas.AutoLoanCorporate.Controllers
{
    public class OSMakerController : Controller
    {

        #region variables
        const string OperationSupport_ApplicationInput_DeduplicateGrid = "OperationSupport_ApplicationInput_DeduplicateGrid";


        #endregion

        // GET: OSMaker
        [ExceptionHandler]
        public ActionResult Index()
        {
            return View("~/Areas/AutoLoanCorporate/Views/OperationSupport/OperationSupport.cshtml");
        }

        #region ApplicationInput

        public ActionResult _ApplicationInput_DeduplicateGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml");
        }

        public ActionResult _ApplicationInput_DeduplicateGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml");
        }

        public ActionResult _ApplicationInput_DeduplicateGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml");
        }

        public ActionResult _ApplicationInput_DeduplicateGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml");
        }

        #endregion

        #region LegalRepresentativeInformation
        public ActionResult OperationSupport_LegalInformation_IdentifCationGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/LegalRepresentativeInformation/_LegalInformation_IdentifCationGrid.cshtml");
        }

        public ActionResult OperationSupport_LegalInformation_IdentifCationGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/LegalRepresentativeInformation/_LegalInformation_IdentifCationGrid.cshtml");
        }

        public ActionResult OperationSupport_LegalInformation_IdentifCationGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/LegalRepresentativeInformation/_LegalInformation_IdentifCationGrid.cshtml");
        }

        public ActionResult OperationSupport_LegalInformation_IdentifCationGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/LegalRepresentativeInformation/_LegalInformation_IdentifCationGrid.cshtml");
        }
        #endregion

        #region CompanyIncome

        public ActionResult OperationSupport_CompanyIncome_TypeOfIGMVATGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMVATGrid.cshtml");
        }
        public ActionResult OperationSupport_CompanyIncome_TypeOfIGMVATGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMVATGrid.cshtml");
        }
        public ActionResult OperationSupport_CompanyIncome_TypeOfIGMVATGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMVATGrid.cshtml");
        }
        public ActionResult OperationSupport_CompanyIncome_TypeOfIGMVATGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMVATGrid.cshtml");
        }


        public ActionResult OperationSupport_CompanyIncome_TypeOfIGMBankGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMBankGrid.cshtml");
        }
        public ActionResult OperationSupport_CompanyIncome_TypeOfIGMBankGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMBankGrid.cshtml");
        }
        public ActionResult OperationSupport_CompanyIncome_TypeOfIGMBankGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMBankGrid.cshtml");
        }
        public ActionResult OperationSupport_CompanyIncome_TypeOfIGMBankGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CompanyIncome/_CompanyIncome_TypeOfIGMBankGrid.cshtml");
        }


        public ActionResult OperationSupport_CompanyIncome_CPPGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CompanyIncome/_CompanyIncome_CPPGrid.cshtml");
        }
        public ActionResult OperationSupport_CompanyIncome_CPPGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CompanyIncome/_CompanyIncome_CPPGrid.cshtml");
        }
        public ActionResult OperationSupport_CompanyIncome_CPPGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CompanyIncome/_CompanyIncome_CPPGrid.cshtml");
        }
        public ActionResult OperationSupport_CompanyIncome_CPPGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CompanyIncome/_CompanyIncome_CPPGrid.cshtml");
        }

        public ActionResult OperationSupport_CompanyIncome_OtherIncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CompanyIncome/_CompanyIncome_OtherIncomeGrid.cshtml");
        }
        public ActionResult OperationSupport_CompanyIncome_OtherIncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CompanyIncome/_CompanyIncome_OtherIncomeGrid.cshtml");
        }
        public ActionResult OperationSupport_CompanyIncome_OtherIncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CompanyIncome/_CompanyIncome_OtherIncomeGrid.cshtml");
        }
        public ActionResult OperationSupport_CompanyIncome_OtherIncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CompanyIncome/_CompanyIncome_OtherIncomeGrid.cshtml");
        }
        #endregion

        #region BorrowerCreditBureau
        public ActionResult OperationSupport_BorrowerCreditBureau_Grid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_Grid.cshtml");
        }
        public ActionResult OperationSupport_BorrowerCreditBureau_Grid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_Grid.cshtml");
        }
        public ActionResult OperationSupport_BorrowerCreditBureau_Grid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_Grid.cshtml");
        }
        public ActionResult OperationSupport_BorrowerCreditBureau_Grid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_Grid.cshtml");
        }

        public ActionResult OperationSupport_BorrowerCreditBureau_CreditCardGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_CreditCardGrid.cshtml");
        }
        public ActionResult OperationSupport_BorrowerCreditBureau_CreditCardGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_CreditCardGrid.cshtml");
        }
        public ActionResult OperationSupport_BorrowerCreditBureau_CreditCardGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_CreditCardGrid.cshtml");
        }
        public ActionResult OperationSupport_BorrowerCreditBureau_CreditCardGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/BorrowerCreditBureau/_BorrowerCreditBureau_CreditCardGrid.cshtml");
        }
        #endregion

        #region CarSalesInformation
        public ActionResult OperationSupport_CarSalesInformation_Grid_Callback()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml");
        }
        public ActionResult OperationSupport_CarSalesInformation_Grid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml");
        }
        public ActionResult OperationSupport_CarSalesInformation_Grid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml");
        }
        public ActionResult OperationSupport_CarSalesInformation_Grid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanCorporate/Views/OperationSupport/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml");
        }
        #endregion





    }
}
