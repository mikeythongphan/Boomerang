﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LITS.Interface.Repository.Main.SalesCoordinators;
using LITS.Interface.Service.Main.SalesCoordinators;
using LITS.Service.Main.SalesCoordinators;
using LITS.Model.Views.Main;
using LITS.UI.Custom;

namespace LITS.UI.Areas.AutoLoanPersonal.Controllers
{
    public class OSMakerController : Controller
    {

        #region variables
        const string OperationSupport_ApplicationInput_DeduplicateGrid = "OperationSupport_ApplicationInput_DeduplicateGrid";


        #endregion

        // GET: OSMaker
        [ExceptionHandler]
        public ActionResult Index()
        {
            return View("~/Areas/AutoLoanPersonal/Views/OperationSupport/OperationSupport.cshtml");
        }

        #region _ApplicationInput_DeduplicateGrid

        public ActionResult OperationSupport_ApplicationInput_DeduplicateGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml");
        }

        public ActionResult OperationSupport_ApplicationInput_DeduplicateGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml");
        }

        public ActionResult OperationSupport_ApplicationInput_DeduplicateGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml");
        }

        public ActionResult OperationSupport_ApplicationInput_DeduplicateGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/ApplicationInput/_ApplicationInput_DeduplicateGrid.cshtml");
        }
        #endregion

        #region CustomersInformation

        #region _MainBorrower_IdentifyCationGrid
        public ActionResult _MainBorrower_IdentifyCationGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersInformation/MainBorrower/_MainBorrower_IdentifyCationGrid.cshtml");
        }
        public ActionResult _MainBorrower_IdentifyCationGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersInformation/MainBorrower/_MainBorrower_IdentifyCationGrid.cshtml");
        }
        public ActionResult _MainBorrower_IdentifyCationGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersInformation/MainBorrower/_MainBorrower_IdentifyCationGrid.cshtml");
        }
        public ActionResult _MainBorrower_IdentifyCationGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersInformation/MainBorrower/_MainBorrower_IdentifyCationGrid.cshtml");
        }
        #endregion

        #region _CoBorrower1_IdentifyCationGrid
        public ActionResult _CoBorrower1_IdentifyCationGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersInformation/CoBorrower1/_CoBorrower1_IdentifyCationGrid.cshtml");
        }
        public ActionResult _CoBorrower1_IdentifyCationGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersInformation/CoBorrower1/_CoBorrower1_IdentifyCationGrid.cshtml");
        }
        public ActionResult _CoBorrower1_IdentifyCationGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersInformation/CoBorrower1/_CoBorrower1_IdentifyCationGrid.cshtml");
        }
        public ActionResult _CoBorrower1_IdentifyCationGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersInformation/CoBorrower1/_CoBorrower1_IdentifyCationGrid.cshtml");
        }
        #endregion

        #region _CoBorrower2_IdentifyCationGrid
        public ActionResult _CoBorrower2_IdentifyCationGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersInformation/CoBorrower2/_CoBorrower2_IdentifyCationGrid.cshtml");
        }
        public ActionResult _CoBorrower2_IdentifyCationGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersInformation/CoBorrower2/_CoBorrower2_IdentifyCationGrid.cshtml");
        }
        public ActionResult _CoBorrower2_IdentifyCationGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersInformation/CoBorrower2/_CoBorrower2_IdentifyCationGrid.cshtml");
        }
        public ActionResult _CoBorrower2_IdentifyCationGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersInformation/CoBorrower2/_CoBorrower2_IdentifyCationGrid.cshtml");
        }
        #endregion

        #region _CoBorrower2_IdentifyCationGrid
        public ActionResult _CoBorrower3_IdentifyCationGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersInformation/CoBorrower3/_CoBorrower3_IdentifyCationGrid.cshtml");
        }
        public ActionResult _CoBorrower3_IdentifyCationGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersInformation/CoBorrower3/_CoBorrower3_IdentifyCationGrid.cshtml");
        }
        public ActionResult _CoBorrower3_IdentifyCationGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersInformation/CoBorrower3/_CoBorrower3_IdentifyCationGrid.cshtml");
        }
        public ActionResult _CoBorrower3_IdentifyCationGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersInformation/CoBorrower3/_CoBorrower3_IdentifyCationGrid.cshtml");
        }
        #endregion

        #endregion

        #region CustomersIncome

        #region MainBorrower

        #region SalariedClient

        #region Income1
        public ActionResult _Income1_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SalariedClient/Income1/_Income1_MonthlyInComeGrid.cshtml");
        }
        public ActionResult _Income1_MonthlyInComeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SalariedClient/Income1/_Income1_MonthlyInComeGrid.cshtml");
        }
        public ActionResult _Income1_MonthlyInComeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SalariedClient/Income1/_Income1_MonthlyInComeGrid.cshtml");
        }
        public ActionResult _Income1_MonthlyInComeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SalariedClient/Income1/_Income1_MonthlyInComeGrid.cshtml");
        }
        public ActionResult _Income1_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SalariedClient/Income1/_Income1_BonusGrid.cshtml");
        }
        public ActionResult _Income1_BonusGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SalariedClient/Income1/_Income1_BonusGrid.cshtml");
        }
        public ActionResult _Income1_BonusGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SalariedClient/Income1/_Income1_BonusGrid.cshtml");
        }
        public ActionResult _Income1_BonusGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SalariedClient/Income1/_Income1_BonusGrid.cshtml");
        }
        #endregion
        #region Income2
        public ActionResult _Income2_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SalariedClient/Income2/_Income2_MonthlyInComeGrid.cshtml");
        }
        public ActionResult _Income2_MonthlyInComeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SalariedClient/Income2/_Income2_MonthlyInComeGrid.cshtml");
        }
        public ActionResult _Income2_MonthlyInComeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SalariedClient/Income2/_Income2_MonthlyInComeGrid.cshtml");
        }
        public ActionResult _Income2_MonthlyInComeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SalariedClient/Income2/_Income2_MonthlyInComeGrid.cshtml");
        }
        public ActionResult _Income2_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SalariedClient/Income2/_Income2_BonusGrid.cshtml");
        }
        public ActionResult _Income2_BonusGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SalariedClient/Income2/_Income2_BonusGrid.cshtml");
        }
        public ActionResult _Income2_BonusGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SalariedClient/Income2/_Income2_BonusGrid.cshtml");
        }
        public ActionResult _Income2_BonusGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SalariedClient/Income2/_Income2_BonusGrid.cshtml");
        }

        #endregion

        #endregion

        #region Rental

        #region HouseRentalIncome 
        public ActionResult _RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult _RentalIncome1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult _RentalIncome1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult _RentalIncome1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        /// <summary>
        /// RentalIncome2
        /// </summary>
        /// <returns></returns>
        public ActionResult _RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult _RentalIncome2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult _RentalIncome2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult _RentalIncome2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }

        /// <summary>
        /// RentalIncome3
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult _RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult _RentalIncome3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult _RentalIncome3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult _RentalIncome3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }

        /// <summary>
        /// RentalIncome4
        /// </summary>
        /// <returns></returns>
        /// 

        public ActionResult _RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult _RentalIncome4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult _RentalIncome4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult _RentalIncome4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }

        /// <summary>
        /// RentalIncome5
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult _RentalIncome5_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome5/_RentalIncome5_IncomeGrid.cshtml");
        }
        public ActionResult _RentalIncome5_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome5/_RentalIncome5_IncomeGrid.cshtml");
        }
        public ActionResult _RentalIncome5_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome5/_RentalIncome5_IncomeGrid.cshtml");
        }
        public ActionResult _RentalIncome5_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome5/_RentalIncome5_IncomeGrid.cshtml");
        }

        /// <summary>
        /// RentalIncome6
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult _RentalIncome6_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        public ActionResult _RentalIncome6_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        public ActionResult _RentalIncome6_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        public ActionResult _RentalIncome6_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        #endregion

        #region CarRentalIncome
        public ActionResult CarRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/CarRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CarRentalIncome_RentalIncome1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/CarRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CarRentalIncome_RentalIncome1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/CarRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CarRentalIncome_RentalIncome1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/CarRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }

        public ActionResult CarRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/CarRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CarRentalIncome_RentalIncome2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/CarRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CarRentalIncome_RentalIncome2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/CarRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CarRentalIncome_RentalIncome2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/CarRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }

        public ActionResult CarRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/CarRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CarRentalIncome_RentalIncome3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/CarRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CarRentalIncome_RentalIncome3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/CarRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CarRentalIncome_RentalIncome3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/CarRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }

        public ActionResult CarRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/CarRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CarRentalIncome_RentalIncome4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/CarRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CarRentalIncome_RentalIncome4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/CarRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CarRentalIncome_RentalIncome4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Rental/CarRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        #endregion

        #endregion

        #region Other

        #region Income1
        public ActionResult MainBorrower_Other_Income1_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Other/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult MainBorrower_Other_Income1_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Other/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult MainBorrower_Other_Income1_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Other/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult MainBorrower_Other_Income1_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Other/Income1/_Income1_IncomeGrid.cshtml");
        }
        #endregion
        #region Income2
        public ActionResult MainBorrower_Other_Income2_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Other/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult MainBorrower_Other_Income2_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Other/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult MainBorrower_Other_Income2_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Other/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult MainBorrower_Other_Income2_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Other/Income2/_Income2_IncomeGrid.cshtml");
        }
        #endregion
        #region Income3
        public ActionResult MainBorrower_Other_Income3_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Other/Income3/_Income3_IncomeGrid.cshtml");
        }
        public ActionResult MainBorrower_Other_Income3_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Other/Income3/_Income3_IncomeGrid.cshtml");
        }
        public ActionResult MainBorrower_Other_Income3_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Other/Income3/_Income3_IncomeGrid.cshtml");
        }
        public ActionResult MainBorrower_Other_Income3_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Other/Income3/_Income3_IncomeGrid.cshtml");
        }
        #endregion
        #region Income4
        public ActionResult MainBorrower_Other_Income4_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Other/Income4/_Income4_IncomeGrid.cshtml");
        }
        public ActionResult MainBorrower_Other_Income4_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Other/Income4/_Income4_IncomeGrid.cshtml");
        }
        public ActionResult MainBorrower_Other_Income4_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Other/Income4/_Income4_IncomeGrid.cshtml");
        }
        public ActionResult MainBorrower_Other_Income4_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/Other/Income4/_Income4_IncomeGrid.cshtml");
        }
        #endregion

        #endregion

        #region SelfEmployed

        /// <summary>
        /// Income1
        /// </summary>
        /// <returns></returns>
        public ActionResult SelfEmployed_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income1/_Income1_IncomeGrid.cshtml");
        }


        public ActionResult SelfEmployed_Income1_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income1/_Income1_TotalCreditInGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income1_TotalCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income1/_Income1_TotalCreditInGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income1_TotalCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income1/_Income1_TotalCreditInGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income1_TotalCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income1/_Income1_TotalCreditInGrid.cshtml");
        }

        public ActionResult SelfEmployed_Income1_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income1_TotalLoanGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income1_TotalLoanGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income1_TotalLoanGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }

        public ActionResult SelfEmployed_Income1_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income1/_Income1_EligibleCreditInGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income1_EligibleCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income1/_Income1_EligibleCreditInGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income1_EligibleCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income1/_Income1_EligibleCreditInGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income1_EligibleCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income1/_Income1_EligibleCreditInGrid.cshtml");
        }

        /// <summary>
        /// Income2
        /// </summary>
        /// <returns></returns>
        public ActionResult SelfEmployed_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }


        public ActionResult SelfEmployed_Income2_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_TotalCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_TotalCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_TotalCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }

        public ActionResult SelfEmployed_Income2_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_TotalLoanGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_TotalLoanGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_TotalLoanGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }

        public ActionResult SelfEmployed_Income2_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_EligibleCreditInGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_EligibleCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_EligibleCreditInGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_EligibleCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_EligibleCreditInGrid.cshtml");
        }
        public ActionResult SelfEmployed_Income2_EligibleCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/MainBorrower/SelfEmployed/Income2/_Income2_EligibleCreditInGrid.cshtml");
        }
        #endregion

        #endregion

        #region CoBorrower1

        #region SalariedClient

        #region Income1
        public ActionResult CustomersIncome_CoBorrower1_Income1_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income1/_Income1_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Income1_MonthlyInComeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income1/_Income1_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Income1_MonthlyInComeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income1/_Income1_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Income1_MonthlyInComeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income1/_Income1_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Income1_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income1/_Income1_BonusGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Income1_BonusGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income1/_Income1_BonusGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Income1_BonusGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income1/_Income1_BonusGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Income1_BonusGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income1/_Income1_BonusGrid.cshtml");
        }
        #endregion
        #region Income2
        public ActionResult CustomersIncome_CoBorrower1_Income2_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income2/_Income2_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Income2_MonthlyInComeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income2/_Income2_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Income2_MonthlyInComeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income2/_Income2_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Income2_MonthlyInComeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income2/_Income2_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Income2_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income2/_Income2_BonusGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Income2_BonusGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income2/_Income2_BonusGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Income2_BonusGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income2/_Income2_BonusGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Income2_BonusGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SalariedClient/Income2/_Income2_BonusGrid.cshtml");
        }

        #endregion

        #endregion

        #region Rental

        #region HouseRentalIncome 
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        /// <summary>
        /// RentalIncome2
        /// </summary>
        /// <returns></returns>
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }

        /// <summary>
        /// RentalIncome3
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }

        /// <summary>
        /// RentalIncome4
        /// </summary>
        /// <returns></returns>
        /// 

        public ActionResult CustomersIncome_CoBorrower1_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }

        /// <summary>
        /// RentalIncome5
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome5_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome5/_RentalIncome5_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome5_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome5/_RentalIncome5_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome5_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome5/_RentalIncome5_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome5_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome5/_RentalIncome5_IncomeGrid.cshtml");
        }

        /// <summary>
        /// RentalIncome6
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome6_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome6_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome6_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_RentalIncome6_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        #endregion

        #region CarRentalIncome
        public ActionResult CustomersIncome_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/CarRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/CarRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/CarRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_CarRentalIncome_RentalIncome1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/CarRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/CarRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/CarRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/CarRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_CarRentalIncome_RentalIncome2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/CarRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/CarRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/CarRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/CarRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_CarRentalIncome_RentalIncome3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/CarRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/CarRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/CarRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/CarRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_CarRentalIncome_RentalIncome4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Rental/CarRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        #endregion

        #endregion

        #region Other

        #region Income1
        public ActionResult CustomersIncome_CoBorrower1_Other_Income1_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Other/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Other_Income1_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Other/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Other_Income1_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Other/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Other_Income1_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Other/Income1/_Income1_IncomeGrid.cshtml");
        }
        #endregion
        #region Income2
        public ActionResult CustomersIncome_CoBorrower1_Other_Income2_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Other/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Other_Income2_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Other/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Other_Income2_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Other/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Other_Income2_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Other/Income2/_Income2_IncomeGrid.cshtml");
        }
        #endregion
        #region Income3
        public ActionResult CustomersIncome_CoBorrower1_Other_Income3_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Other/Income3/_Income3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Other_Income3_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Other/Income3/_Income3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Other_Income3_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Other/Income3/_Income3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Other_Income3_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Other/Income3/_Income3_IncomeGrid.cshtml");
        }
        #endregion
        #region Income4
        public ActionResult CustomersIncome_CoBorrower1_Other_Income4_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Other/Income4/_Income4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Other_Income4_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Other/Income4/_Income4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Other_Income4_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Other/Income4/_Income4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_Other_Income4_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/Other/Income4/_Income4_IncomeGrid.cshtml");
        }
        #endregion

        #endregion

        #region SelfEmployed

        /// <summary>
        /// Income1
        /// </summary>
        /// <returns></returns>
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income1/_Income1_IncomeGrid.cshtml");
        }


        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income1/_Income1_TotalCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income1/_Income1_TotalCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income1/_Income1_TotalCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income1_TotalCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income1/_Income1_TotalCreditInGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income1_TotalLoanGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income1/_Income1_EligibleCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income1/_Income1_EligibleCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income1/_Income1_EligibleCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income1_EligibleCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income1/_Income1_EligibleCreditInGrid.cshtml");
        }

        /// <summary>
        /// Income2
        /// </summary>
        /// <returns></returns>
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }


        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income2_TotalCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income2_TotalLoanGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_Income2_EligibleCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_Income2_EligibleCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_Income2_EligibleCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower1_SelfEmployed_Income2_EligibleCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower1/SelfEmployed/Income2/_Income2_EligibleCreditInGrid.cshtml");
        }
        #endregion

        #endregion

        #region CoBorrower2

        #region SalariedClient

        #region Income1
        public ActionResult CustomersIncome_CoBorrower2_Income1_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SalariedClient/Income1/_Income1_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Income1_MonthlyInComeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SalariedClient/Income1/_Income1_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Income1_MonthlyInComeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SalariedClient/Income1/_Income1_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Income1_MonthlyInComeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SalariedClient/Income1/_Income1_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Income1_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SalariedClient/Income1/_Income1_BonusGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Income1_BonusGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SalariedClient/Income1/_Income1_BonusGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Income1_BonusGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SalariedClient/Income1/_Income1_BonusGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Income1_BonusGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SalariedClient/Income1/_Income1_BonusGrid.cshtml");
        }
        #endregion
        #region Income2
        public ActionResult CustomersIncome_CoBorrower2_Income2_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SalariedClient/Income2/_Income2_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Income2_MonthlyInComeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SalariedClient/Income2/_Income2_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Income2_MonthlyInComeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SalariedClient/Income2/_Income2_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Income2_MonthlyInComeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SalariedClient/Income2/_Income2_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Income2_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SalariedClient/Income2/_Income2_BonusGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Income2_BonusGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SalariedClient/Income2/_Income2_BonusGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Income2_BonusGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SalariedClient/Income2/_Income2_BonusGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Income2_BonusGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SalariedClient/Income2/_Income2_BonusGrid.cshtml");
        }

        #endregion

        #endregion

        #region Rental

        #region HouseRentalIncome 
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        /// <summary>
        /// RentalIncome2
        /// </summary>
        /// <returns></returns>
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }

        /// <summary>
        /// RentalIncome3
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }

        /// <summary>
        /// RentalIncome4
        /// </summary>
        /// <returns></returns>
        /// 

        public ActionResult CustomersIncome_CoBorrower2_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }

        /// <summary>
        /// RentalIncome5
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome5_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome5/_RentalIncome5_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome5_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome5/_RentalIncome5_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome5_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome5/_RentalIncome5_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome5_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome5/_RentalIncome5_IncomeGrid.cshtml");
        }

        /// <summary>
        /// RentalIncome6
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome6_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome6_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome6_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_RentalIncome6_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        #endregion

        #region CarRentalIncome
        public ActionResult CustomersIncome_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/CarRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/CarRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/CarRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_CarRentalIncome_RentalIncome1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/CarRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/CarRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/CarRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/CarRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_CarRentalIncome_RentalIncome2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/CarRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/CarRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/CarRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/CarRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_CarRentalIncome_RentalIncome3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/CarRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/CarRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/CarRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/CarRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_CarRentalIncome_RentalIncome4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Rental/CarRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        #endregion

        #endregion

        #region Other

        #region Income1
        public ActionResult CustomersIncome_CoBorrower2_Other_Income1_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Other/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Other_Income1_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Other/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Other_Income1_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Other/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Other_Income1_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Other/Income1/_Income1_IncomeGrid.cshtml");
        }
        #endregion
        #region Income2
        public ActionResult CustomersIncome_CoBorrower2_Other_Income2_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Other/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Other_Income2_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Other/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Other_Income2_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Other/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Other_Income2_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Other/Income2/_Income2_IncomeGrid.cshtml");
        }
        #endregion
        #region Income3
        public ActionResult CustomersIncome_CoBorrower2_Other_Income3_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Other/Income3/_Income3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Other_Income3_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Other/Income3/_Income3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Other_Income3_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Other/Income3/_Income3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Other_Income3_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Other/Income3/_Income3_IncomeGrid.cshtml");
        }
        #endregion
        #region Income4
        public ActionResult CustomersIncome_CoBorrower2_Other_Income4_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Other/Income4/_Income4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Other_Income4_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Other/Income4/_Income4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Other_Income4_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Other/Income4/_Income4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_Other_Income4_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/Other/Income4/_Income4_IncomeGrid.cshtml");
        }
        #endregion

        #endregion

        #region SelfEmployed

        /// <summary>
        /// Income1
        /// </summary>
        /// <returns></returns>
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income1/_Income1_IncomeGrid.cshtml");
        }


        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income1/_Income1_TotalCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income1/_Income1_TotalCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income1/_Income1_TotalCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income1_TotalCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income1/_Income1_TotalCreditInGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income1_TotalLoanGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income1/_Income1_EligibleCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income1/_Income1_EligibleCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income1/_Income1_EligibleCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income1_EligibleCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income1/_Income1_EligibleCreditInGrid.cshtml");
        }

        /// <summary>
        /// Income2
        /// </summary>
        /// <returns></returns>
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }


        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income2_TotalCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income2_TotalLoanGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income2/_Income2_EligibleCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income2/_Income2_EligibleCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income2/_Income2_EligibleCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower2_SelfEmployed_Income2_EligibleCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower2/SelfEmployed/Income2/_Income2_EligibleCreditInGrid.cshtml");
        }
        #endregion

        #endregion

        #region CoBorrower3

        #region SalariedClient

        #region Income1
        public ActionResult CustomersIncome_CoBorrower3_Income1_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SalariedClient/Income1/_Income1_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Income1_MonthlyInComeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SalariedClient/Income1/_Income1_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Income1_MonthlyInComeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SalariedClient/Income1/_Income1_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Income1_MonthlyInComeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SalariedClient/Income1/_Income1_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Income1_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SalariedClient/Income1/_Income1_BonusGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Income1_BonusGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SalariedClient/Income1/_Income1_BonusGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Income1_BonusGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SalariedClient/Income1/_Income1_BonusGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Income1_BonusGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SalariedClient/Income1/_Income1_BonusGrid.cshtml");
        }
        #endregion
        #region Income2
        public ActionResult CustomersIncome_CoBorrower3_Income2_MonthlyInComeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SalariedClient/Income2/_Income2_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Income2_MonthlyInComeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SalariedClient/Income2/_Income2_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Income2_MonthlyInComeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SalariedClient/Income2/_Income2_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Income2_MonthlyInComeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SalariedClient/Income2/_Income2_MonthlyInComeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Income2_BonusGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SalariedClient/Income2/_Income2_BonusGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Income2_BonusGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SalariedClient/Income2/_Income2_BonusGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Income2_BonusGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SalariedClient/Income2/_Income2_BonusGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Income2_BonusGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SalariedClient/Income2/_Income2_BonusGrid.cshtml");
        }

        #endregion

        #endregion

        #region Rental

        #region HouseRentalIncome 
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        /// <summary>
        /// RentalIncome2
        /// </summary>
        /// <returns></returns>
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }

        /// <summary>
        /// RentalIncome3
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }

        /// <summary>
        /// RentalIncome4
        /// </summary>
        /// <returns></returns>
        /// 

        public ActionResult CustomersIncome_CoBorrower3_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }

        /// <summary>
        /// RentalIncome5
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome5_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome5/_RentalIncome5_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome5_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome5/_RentalIncome5_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome5_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome5/_RentalIncome5_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome5_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome5/_RentalIncome5_IncomeGrid.cshtml");
        }

        /// <summary>
        /// RentalIncome6
        /// </summary>
        /// <returns></returns>
        /// 
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome6_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome6_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome6_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_RentalIncome6_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/HouseRentalIncome/RentalIncome6/_RentalIncome6_IncomeGrid.cshtml");
        }
        #endregion

        #region CarRentalIncome
        public ActionResult CustomersIncome_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/CarRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/CarRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/CarRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_CarRentalIncome_RentalIncome1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/CarRentalIncome/RentalIncome1/_RentalIncome1_IncomeGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/CarRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/CarRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/CarRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_CarRentalIncome_RentalIncome2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/CarRentalIncome/RentalIncome2/_RentalIncome2_IncomeGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/CarRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/CarRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/CarRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_CarRentalIncome_RentalIncome3_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/CarRentalIncome/RentalIncome3/_RentalIncome3_IncomeGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/CarRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/CarRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/CarRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_CarRentalIncome_RentalIncome4_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Rental/CarRentalIncome/RentalIncome4/_RentalIncome4_IncomeGrid.cshtml");
        }
        #endregion

        #endregion

        #region Other

        #region Income1
        public ActionResult CustomersIncome_CoBorrower3_Other_Income1_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Other/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Other_Income1_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Other/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Other_Income1_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Other/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Other_Income1_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Other/Income1/_Income1_IncomeGrid.cshtml");
        }
        #endregion
        #region Income2
        public ActionResult CustomersIncome_CoBorrower3_Other_Income2_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Other/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Other_Income2_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Other/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Other_Income2_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Other/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Other_Income2_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Other/Income2/_Income2_IncomeGrid.cshtml");
        }
        #endregion
        #region Income3
        public ActionResult CustomersIncome_CoBorrower3_Other_Income3_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Other/Income3/_Income3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Other_Income3_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Other/Income3/_Income3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Other_Income3_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Other/Income3/_Income3_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Other_Income3_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Other/Income3/_Income3_IncomeGrid.cshtml");
        }
        #endregion
        #region Income4
        public ActionResult CustomersIncome_CoBorrower3_Other_Income4_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Other/Income4/_Income4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Other_Income4_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Other/Income4/_Income4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Other_Income4_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Other/Income4/_Income4_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_Other_Income4_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/Other/Income4/_Income4_IncomeGrid.cshtml");
        }
        #endregion

        #endregion

        #region SelfEmployed

        /// <summary>
        /// Income1
        /// </summary>
        /// <returns></returns>
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_IncomeGrid.cshtml");
        }


        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_TotalCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_TotalCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_TotalCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_TotalCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_TotalCreditInGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_TotalLoanGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_TotalLoanGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_EligibleCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_EligibleCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_EligibleCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income1_EligibleCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income1/_Income1_EligibleCreditInGrid.cshtml");
        }

        /// <summary>
        /// Income2
        /// </summary>
        /// <returns></returns>
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income2_IncomeGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income2_IncomeGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income2_IncomeGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income2_IncomeGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income2/_Income2_IncomeGrid.cshtml");
        }


        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income2_TotalCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income2/_Income2_TotalCreditInGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income2_TotalLoanGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income2/_Income2_TotalLoanGrid.cshtml");
        }

        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income2/_Income2_EligibleCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income2/_Income2_EligibleCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income2/_Income2_EligibleCreditInGrid.cshtml");
        }
        public ActionResult CustomersIncome_CoBorrower3_SelfEmployed_Income2_EligibleCreditInGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersIncome/CoBorrower3/SelfEmployed/Income2/_Income2_EligibleCreditInGrid.cshtml");
        }
        #endregion

        #endregion

        #endregion

        #region CustomersCreditBureau

        #region CoBorrower1
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower1_CreditBureauGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower1/_CoBorrower1_CreditBureauGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower1_CreditBureauGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower1/_CoBorrower1_CreditBureauGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower1_CreditBureauGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower1/_CoBorrower1_CreditBureauGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower1_CreditBureauGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower1/_CoBorrower1_CreditBureauGrid.cshtml");
        }

        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower1_CreditCardGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower1/_CoBorrower1_CreditCardGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower1_CreditCardGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower1/_CoBorrower1_CreditCardGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower1_CreditCardGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower1/_CoBorrower1_CreditCardGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower1_CreditCardGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower1/_CoBorrower1_CreditCardGrid.cshtml");
        }
        #endregion

        #region CoBorrower2
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower2_CreditBureauGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower2/_CoBorrower2_CreditBureauGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower2_CreditBureauGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower2/_CoBorrower2_CreditBureauGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower2_CreditBureauGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower2/_CoBorrower2_CreditBureauGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower2_CreditBureauGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower2/_CoBorrower2_CreditBureauGrid.cshtml");
        }

        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower2_CreditCardGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower2/_CoBorrower2_CreditCardGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower2_CreditCardGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower2/_CoBorrower2_CreditCardGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower2_CreditCardGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower2/_CoBorrower2_CreditCardGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower2_CreditCardGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower2/_CoBorrower2_CreditCardGrid.cshtml");
        }
        #endregion

        #region CoBorrower3
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower3_CreditBureauGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower3/_CoBorrower3_CreditBureauGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower3_CreditBureauGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower3/_CoBorrower3_CreditBureauGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower3_CreditBureauGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower3/_CoBorrower3_CreditBureauGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower3_CreditBureauGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower3/_CoBorrower3_CreditBureauGrid.cshtml");
        }

        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower3_CreditCardGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower3/_CoBorrower3_CreditCardGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower3_CreditCardGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower3/_CoBorrower3_CreditCardGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower3_CreditCardGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower3/_CoBorrower3_CreditCardGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_CoBorrower3_CreditCardGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/CoBorrower3/_CoBorrower3_CreditCardGrid.cshtml");
        }
        #endregion

        #region MainBorrower
        public ActionResult OperationSupport_CustomersCreditBureau_MainBorrower_CreditBureauGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/MainBorrower/_MainBorrower_CreditBureauGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_MainBorrower_CreditBureauGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/MainBorrower/_MainBorrower_CreditBureauGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_MainBorrower_CreditBureauGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/MainBorrower/_MainBorrower_CreditBureauGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_MainBorrower_CreditBureauGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/MainBorrower/_MainBorrower_CreditBureauGrid.cshtml");
        }

        public ActionResult OperationSupport_CustomersCreditBureau_MainBorrower_CreditCardGrid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/MainBorrower/_MainBorrower_CreditCardGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_MainBorrower_CreditCardGrid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/MainBorrower/_MainBorrower_CreditCardGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_MainBorrower_CreditCardGrid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/MainBorrower/_MainBorrower_CreditCardGrid.cshtml");
        }
        public ActionResult OperationSupport_CustomersCreditBureau_MainBorrower_CreditCardGrid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CustomersCreditBureau/MainBorrower/_MainBorrower_CreditCardGrid.cshtml");
        }
        #endregion

        #endregion

        #region CarSalesInformation
        public ActionResult OperationSupport_CarSalesInformation_Grid_Callback()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml");
        }

        public ActionResult OperationSupport_CarSalesInformation_Grid_AddNewRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml");
        }

        public ActionResult OperationSupport_CarSalesInformation_Grid_UpdateRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml");
        }

        public ActionResult OperationSupport_CarSalesInformation_Grid_DeleteRow()
        {
            return PartialView("~/Areas/AutoLoanPersonal/Views/OperationSupport/PartialViews/CarSalesInformation/_CarSalesInformation_Grid.cshtml");
        }
        #endregion

    }
}
