﻿using LITS.Model.PartialViews.Main.CreateNewLoan;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LITS.UI.Controllers;
using LITS.Infrastructure.Configuration;
using LITS.Infrastructure.Common;
using LITS.Interface.Service.Main.CreateNewLoan;
using Newtonsoft.Json;


namespace LITS.UI.Areas.Main.Controllers
{
    public class CreateNewLoanMakerController : BaseController
    {
        private readonly ICreateNewLoanService _CreateNewLoanService;

        public CreateNewLoanMakerController(IUnitOfWorkManager unitOfWorkManager,
            ICreateNewLoanService createNewLoanService)
            : base(unitOfWorkManager)
        {
            this._CreateNewLoanService = createNewLoanService;
        }


        #region Variables
        const string CreateNewLoan_TreeList = "CreateNewLoan_TreeList";
        const string Step3_Content = "Step3_Content";
        const string Step2_CoBorrower1_CompanyGrid = "Step2_CoBorrower1_CompanyGrid";
        const string Step2_CoBorrower1_IdentifiGrid = "Step2_CoBorrower1_IdentifiGrid";
        const string Step2_CoBorrower2_CompanyGrid = "Step2_CoBorrower2_CompanyGrid";
        const string Step2_CoBorrower2_IdentifiGrid = "Step2_CoBorrower2_IdentifiGrid";
        const string Step2_CoBorrower3_CompanyGrid = "Step2_CoBorrower3_CompanyGrid";
        const string Step2_CoBorrower3_IdentifiGrid = "Step2_CoBorrower3_IdentifiGrid";
        const string Step2_Corporate_IdentifiGrid = "Step2_Corporate_IdentifiGrid";
        const string Step2_MainBorrower_CompanyGrid = "Step2_MainBorrower_CompanyGrid";
        const string Step2_MainBorrower_IdentifiGrid = "Step2_MainBorrower_IdentifiGrid";
        const string Step3_CompanyGrid = "Step3_CompanyGrid";
        const string Step3_DeDuplicateGrid = "Step3_DeDuplicateGrid";
        const string Step3_IdentifiGrid = "Step3_IdentifiGrid";

        const string Step2_M_IdentificationTypeViewModel = "Step2_M_IdentificationTypeViewModel";
        const string Step2_M_CompanyTypeViewModel = "Step2_M_CompanyTypeViewModel";
        const string Step2_M_DistrictViewModel = "Step2_M_DistrictViewModel";
        const string Step2_M_CityViewModel = "Step2_M_CityViewModel";
        const string Step2_M_NationalityViewModel = "Step2_M_NationalityViewModel";
        const string Step2_M_InitialViewModel = "Step2_M_InitialViewModel";
        const string Step2_M_CustomerRelationshipViewModel = "Step2_M_CustomerRelationshipViewModel";

        const string Step3_M_IdentificationTypeViewModel = "Step3_M_IdentificationTypeViewModel";
        const string Step3_M_CompanyTypeViewModel = "Step3_M_CompanyTypeViewModel";
        const string Step3_M_ApplicationTypeViewModel = "Step3_M_ApplicationTypeViewModel";
        const string Step3_M_NationalityViewModel = "Step3_M_NationalityViewModel";


        #endregion

        #region Index
        // GET: CreateNewLoanMaker
        public ActionResult Index()
        {
            var area = ControllerContext.RouteData.DataTokens["area"].ToString();
            var controller = ControllerContext.RouteData.Values["controller"].ToString();

            LITS.Model.Views.Main.CreateNewLoanViewModel obj = new Model.Views.Main.CreateNewLoanViewModel();
            obj = _CreateNewLoanService.LoadIndexStep1(obj, area, controller, User.Identity.Name);

            Session[CreateNewLoan_TreeList] = obj._CreateNewLoanStep1ViewModel.lstCreateNewLoanStep1Tree;

            // Set Session data grid
            Session[Step3_Content] = null;
            Session[Step2_CoBorrower1_CompanyGrid] = null;
            Session[Step2_CoBorrower1_IdentifiGrid] = null;
            Session[Step2_CoBorrower2_CompanyGrid] = null;
            Session[Step2_CoBorrower2_IdentifiGrid] = null;
            Session[Step2_CoBorrower3_CompanyGrid] = null;
            Session[Step2_CoBorrower3_IdentifiGrid] = null;
            Session[Step2_Corporate_IdentifiGrid] = null;
            Session[Step2_MainBorrower_CompanyGrid] = null;
            Session[Step2_MainBorrower_IdentifiGrid] = null;
            Session[Step3_CompanyGrid] = null;
            Session[Step3_DeDuplicateGrid] = null;
            Session[Step3_IdentifiGrid] = null;

            // Set Session data combo grid
            Session[Step2_M_IdentificationTypeViewModel] = null;
            Session[Step2_M_CompanyTypeViewModel] = null;
            Session[Step2_M_DistrictViewModel] = null;
            Session[Step2_M_CityViewModel] = null;
            Session[Step2_M_NationalityViewModel] = null;
            Session[Step2_M_InitialViewModel] = null;
            Session[Step2_M_CustomerRelationshipViewModel] = null;
            Session[Step3_M_IdentificationTypeViewModel] = null;
            Session[Step3_M_CompanyTypeViewModel] = null;
            Session[Step3_M_ApplicationTypeViewModel] = null;
            Session[Step3_M_NationalityViewModel] = null;

            return View("~/Areas/Main/Views/CreateNewLoan/CreateNewLoan.cshtml", obj);
        }

        #endregion

        #region Grid
        #region CreateNewLoan_TreeList
        public ActionResult CreateNewLoan_TreeList_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step1_TreeList.cshtml", Session[CreateNewLoan_TreeList]);
        }
        #endregion

        #region Step2_CoBorrower1_CompanyGrid
        public ActionResult Step2_CoBorrower1_CompanyGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower1_CompanyGrid.cshtml", Session[Step2_CoBorrower1_CompanyGrid]);
        }

        //public ActionResult(ThongTinCongSuThamGia_ViewModel item)
        //{
        //    List<ThongTinCongSuThamGia_ViewModel> listCanBoThucHien = Session[CONGSUTHAMGIA] as List<ThongTinCongSuThamGia_ViewModel>;
        //    if (listCanBoThucHien != null)
        //    {
        //        if (ModelState.IsValid)
        //        {
        //            int count = listCanBoThucHien.Count(x => x.CanBoThucHienID == item.CanBoThucHienID);
        //            if (count > 0)
        //            {
        //                ViewData["EditError"] = MsgResources.DataExist;
        //            }
        //            else
        //            {
        //                item.CongSuThamGiaID = listCanBoThucHien.Count + 1;
        //                listCanBoThucHien.Add(item);
        //            }

        //            Session[CONGSUTHAMGIA] = listCanBoThucHien;
        //        }
        //        else
        //            ViewData["EditError"] = MsgResources.InvalidValue;
        //    }
        //    return PartialView("_gvCongSuThamGiaPartial");
        //}

        //public ActionResult(ThongTinCongSuThamGia_ViewModel item)
        //{
        //    List<ThongTinCongSuThamGia_ViewModel> listCanBoThucHien = Session[CONGSUTHAMGIA] as List<ThongTinCongSuThamGia_ViewModel>;
        //    if (listCanBoThucHien != null)
        //    {
        //        if (ModelState.IsValid)
        //        {
        //            ThongTinCongSuThamGia_ViewModel modelItem = listCanBoThucHien.SingleOrDefault(x => x.CongSuThamGiaID == item.CongSuThamGiaID);
        //            if (modelItem != null)
        //            {
        //                int count = listCanBoThucHien.Count(x => x.CanBoThucHienID == item.CanBoThucHienID && x.CongSuThamGiaID != item.CongSuThamGiaID);
        //                if (count > 0)
        //                {
        //                    ViewData["EditError"] = MsgResources.DataExist;
        //                }
        //                else
        //                {
        //                    modelItem.CanBoThucHienID = item.CanBoThucHienID;
        //                    modelItem.MaCanBoThucHien = item.MaCanBoThucHien;
        //                    //modelItem.HoTen = item.HoTen;
        //                    modelItem.TenChucDanhKhoaHoc = item.TenChucDanhKhoaHoc;
        //                    modelItem.TenChucVu = item.TenChucVu;
        //                    modelItem.TenHocHamHocVi = item.TenHocHamHocVi;
        //                }
        //            }
        //            Session[CONGSUTHAMGIA] = listCanBoThucHien;
        //        }
        //        else
        //            ViewData["EditError"] = MsgResources.InvalidValue;
        //    }
        //    return PartialView("_gvCongSuThamGiaPartial");
        //}

        //public ActionResult(int? CongSuThamGiaID)
        //{
        //    List<ThongTinCongSuThamGia_ViewModel> listCanBoThucHien = Session[CONGSUTHAMGIA] as List<ThongTinCongSuThamGia_ViewModel>;
        //    if (listCanBoThucHien != null)
        //    {
        //        if (CongSuThamGiaID.HasValue && CongSuThamGiaID > 0)
        //        {
        //            listCanBoThucHien.Remove(listCanBoThucHien.SingleOrDefault(x => x.CongSuThamGiaID == CongSuThamGiaID));
        //        }
        //        else
        //            ViewData["EditError"] = MsgResources.InvalidID;
        //        Session[CONGSUTHAMGIA] = listCanBoThucHien;
        //    }
        //    return PartialView("_gvCongSuThamGiaPartial");
        //}

        #endregion

        #region Step2_CoBorrower1_IdentifiGrid
        public ActionResult Step2_CoBorrower1_IdentifiGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower1_IdentifiGrid.cshtml", Session[Step2_CoBorrower1_IdentifiGrid]);
        }


        #endregion

        #region Step2_CoBorrower2_CompanyGrid
        public ActionResult Step2_CoBorrower2_CompanyGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower2_CompanyGrid.cshtml", Session[Step2_CoBorrower2_CompanyGrid]);
        }


        #endregion

        #region Step2_CoBorrower2_IdentifiGrid
        public ActionResult Step2_CoBorrower2_IdentifiGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower2_IdentifiGrid.cshtml", Session[Step2_CoBorrower2_IdentifiGrid]);
        }


        #endregion

        #region Step2_CoBorrower3_CompanyGrid
        public ActionResult Step2_CoBorrower3_CompanyGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower3_CompanyGrid.cshtml", Session[Step2_CoBorrower3_CompanyGrid]);
        }


        #endregion

        #region Step2_CoBorrower3_IdentifiGrid
        public ActionResult Step2_CoBorrower3_IdentifiGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_CoBorrower3_IdentifiGrid.cshtml", Session[Step2_CoBorrower3_IdentifiGrid]);
        }


        #endregion

        #region Step2_Corporate_IdentifiGrid
        public ActionResult Step2_Corporate_IdentifiGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_Corporate_IdentifiGrid.cshtml", Session[Step2_Corporate_IdentifiGrid]);
        }


        #endregion

        #region Step2_MainBorrower_CompanyGrid
        public ActionResult Step2_MainBorrower_CompanyGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_MainBorrower_CompanyGrid.cshtml", Session[Step2_MainBorrower_CompanyGrid]);
        }


        #endregion

        #region Step2_MainBorrower_IdentifiGrid
        public ActionResult Step2_MainBorrower_IdentifiGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2_MainBorrower_IdentifiGrid.cshtml", Session[Step2_MainBorrower_IdentifiGrid]);
        }


        #endregion

        #region Step3_CompanyGrid
        public ActionResult Step3_CompanyGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step3_CompanyGrid.cshtml", Session[Step3_CompanyGrid]);
        }


        #endregion

        #region Step3_DeDuplicateGrid
        public ActionResult Step3_DeDuplicateGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step3_DeDuplicateGrid.cshtml", Session[Step3_DeDuplicateGrid]);
        }


        #endregion

        #region Step3_IdentifiGrid
        public ActionResult Step3_IdentifiGrid_Callback()
        {
            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step3_IdentifiGrid.cshtml", Session[Step3_IdentifiGrid]);
        }


        #endregion

        #endregion

        #region CallbackPanel
        public ActionResult cpStep2_Callback(int? nodeKeySelected, int? typeSelected)
        {
            var area = ControllerContext.RouteData.DataTokens["area"].ToString();
            var controller = ControllerContext.RouteData.Values["controller"].ToString();
            LITS.Model.Views.Main.CreateNewLoanViewModel obj = new Model.Views.Main.CreateNewLoanViewModel();

            // Set CreateNewLoanStep1ViewModel
            obj._CreateNewLoanStep1ViewModel.ProductTypeID = nodeKeySelected;
            obj._CreateNewLoanStep1ViewModel.ApplicationTypeID = typeSelected;

            // Set CreateNewLoanStep2ViewModel
            obj._CreateNewLoanStep2ViewModel.ProductTypeID = nodeKeySelected;
            obj._CreateNewLoanStep2ViewModel.ApplicationTypeID = typeSelected;

            // Call Service
            obj = _CreateNewLoanService.LoadIndexStep2(obj, area, controller, User.Identity.Name);

            // Set Session data grid
            Session[Step3_Content] = null;
            Session[Step2_CoBorrower1_CompanyGrid] = obj._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2CompanyCo1;
            Session[Step2_CoBorrower1_IdentifiGrid] = obj._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo1;
            Session[Step2_CoBorrower2_CompanyGrid] = obj._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2CompanyCo2;
            Session[Step2_CoBorrower2_IdentifiGrid] = obj._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo2;
            Session[Step2_CoBorrower3_CompanyGrid] = obj._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2CompanyCo3;
            Session[Step2_CoBorrower3_IdentifiGrid] = obj._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationCo3;
            Session[Step2_Corporate_IdentifiGrid] = obj._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationLegalRepresentative;
            Session[Step2_MainBorrower_CompanyGrid] = obj._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2CompanyMain;
            Session[Step2_MainBorrower_IdentifiGrid] = obj._CreateNewLoanStep2ViewModel.lstCreateNewLoanStep2IdentificationMain;

            // Set Session data combo grid
            Session[Step2_M_IdentificationTypeViewModel] = obj._CreateNewLoanStep2ViewModel._M_IdentificationTypeViewModel;
            Session[Step2_M_CompanyTypeViewModel] = obj._CreateNewLoanStep2ViewModel._M_CompanyTypeViewModel;
            Session[Step2_M_DistrictViewModel] = obj._CreateNewLoanStep2ViewModel._M_DistrictViewModel;
            Session[Step2_M_CityViewModel] = obj._CreateNewLoanStep2ViewModel._M_CityViewModel;
            Session[Step2_M_NationalityViewModel] = obj._CreateNewLoanStep2ViewModel._M_NationalityViewModel;
            Session[Step2_M_InitialViewModel] = obj._CreateNewLoanStep2ViewModel._M_InitialViewModel;
            Session[Step2_M_CustomerRelationshipViewModel] = obj._CreateNewLoanStep2ViewModel._M_CustomerRelationshipViewModel;

            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step2.cshtml", obj._CreateNewLoanStep2ViewModel);
        }

        public ActionResult cpStep3_Callback(int? nodeKeySelected, int? typeSelected)
        {
            var obj = (Model.Views.Main.CreateNewLoanViewModel)Session[Step3_Content];

            // Set Session data grid
            Session[Step3_CompanyGrid] = obj._CreateNewLoanStep3ViewModel.lstCreateNewLoanStep3CompanyBlackList;
            Session[Step3_DeDuplicateGrid] = obj._CreateNewLoanStep3ViewModel.lstCreateNewLoanStep3DuplicateViewModel;
            Session[Step3_IdentifiGrid] = obj._CreateNewLoanStep3ViewModel.lstCreateNewLoanStep3CustomerBlackList;

            // Set Session data combo grid
            Session[Step3_M_IdentificationTypeViewModel] = obj._CreateNewLoanStep3ViewModel._M_IdentificationTypeViewModel;
            Session[Step3_M_CompanyTypeViewModel] = obj._CreateNewLoanStep3ViewModel._M_CompanyTypeViewModel;
            Session[Step3_M_ApplicationTypeViewModel] = obj._CreateNewLoanStep3ViewModel._M_ApplicationTypeViewModel;
            Session[Step3_M_NationalityViewModel] = obj._CreateNewLoanStep3ViewModel._M_NationalityViewModel;

            return PartialView("~/Areas/Main/Views/CreateNewLoan/PartialViews/_Step3.cshtml", obj._CreateNewLoanStep3ViewModel);
        }

        #endregion

        #region Submit



        #endregion




    }
}