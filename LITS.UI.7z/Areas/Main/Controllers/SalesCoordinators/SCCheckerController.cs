﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LITS.UI.Areas.Main.Controllers
{
    public class SCCheckerController : Controller
    {
        // GET: Checker
        public ActionResult Index()
        {
            return View();
        }

        // GET: Checker/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Checker/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Checker/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Checker/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Checker/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Checker/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Checker/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
