﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using LITS.UI.Custom;
using LITS.Infrastructure.Configuration;
using LITS.Infrastructure.Context;

namespace LITS.UI.Controllers
{
    public class BaseController : Controller
    {
        protected readonly IUnitOfWorkManager UnitOfWorkManager;
        // GET: Base
        public BaseController(IUnitOfWorkManager unitOfWorkManager)
        {
            UnitOfWorkManager = unitOfWorkManager;
        }

        protected override void OnException(ExceptionContext filterContext)
        {
            if (!filterContext.ExceptionHandled)
            {
                var areaName = filterContext.RouteData.DataTokens.Keys.Contains("area") ? filterContext.RouteData.DataTokens["area"].ToString() : "";
                var controllerName = filterContext.RouteData.Values.Keys.Contains("controller") ? filterContext.RouteData.Values["controller"].ToString() : "";
                var actionName = filterContext.RouteData.Values.Keys.Contains("action") ? filterContext.RouteData.Values["action"].ToString() : "";
                filterContext.Controller.ViewData["ErrorMessage"] = filterContext.Exception.Message;
                filterContext.Controller.ViewData["StackTrace"] = filterContext.Exception.StackTrace;
                filterContext.Controller.ViewData["areaName"] = areaName;
                filterContext.Controller.ViewData["controllerName"] = controllerName;
                filterContext.Controller.ViewData["actionName"] = actionName;

                ExceptionLogger logger = new ExceptionLogger()
                {
                    ExceptionMessage = filterContext.Exception.Message,
                    ExceptionStackTrace = filterContext.Exception.StackTrace,
                    ControllerName = filterContext.RouteData.Values["controller"].ToString(),
                    ActionName = filterContext.Controller.ViewData["actionName"].ToString(),
                    AreaName = areaName,
                    ProcessesId = 4,
                    LogBy = User.Identity.Name,
                    LogTime = DateTime.Now
                };

                ADCSEntities ctx = new ADCSEntities();
                ctx.ExceptionLoggers.Add(logger);
                ctx.SaveChanges();

                LogManager.LogError(string.Format(@"Area Name:[{0}],[Controller Name:[{1}],Action Name:[{2}] Abnormal Information", areaName, controllerName, actionName), filterContext.Exception);

                filterContext.Result = new ViewResult()
                {
                    ViewName = "Error",
                    ViewData = filterContext.Controller.ViewData
                };

                filterContext.ExceptionHandled = true;
            }
        }
    }
}
