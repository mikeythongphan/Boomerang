﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity.Owin;
using System.ComponentModel;
using System.Net;
using System.Threading.Tasks;
using LITS.UI.Custom;
using LITS.UI.Models;
using LITS.Infrastructure.Common;
using LITS.Infrastructure.Configuration;
using LITS.Infrastructure.Context;

namespace LITS.UI.Controllers
{
    [Description("Role")]
    public class RoleController : BaseController
    {
        private ApplicationRoleManager _roleManager;
        private static Lazy<IEnumerable<ControllerDescription>> _controllerList = new Lazy<IEnumerable<ControllerDescription>>();
        private ADCSEntities _ADCSEntities;

        public RoleController(IUnitOfWorkManager unitOfWorkManager)
            : base(unitOfWorkManager)
        {}

        public RoleController(ApplicationRoleManager roleManager,
            IUnitOfWorkManager unitOfWorkManager,
            ADCSEntities _adcsEntities)
            : base(unitOfWorkManager)
        {
            RoleManager = roleManager;
            this._ADCSEntities = _adcsEntities;
        }

        public ApplicationRoleManager RoleManager
        {
            get { return _roleManager ?? HttpContext.GetOwinContext().Get<ApplicationRoleManager>(); }
            private set { _roleManager = value; }
        }

        // GET: Role
        [Description("Role List")]
        public ActionResult Index()
        {
            var roles = RoleManager.Roles;
            return View(roles);
        }

        // GET: Role/Create
        [Description("Create Role")]
        public ActionResult Create()
        {
            var createRoleViewModel = new CreateRoleViewModel
            {
                Controllers = GetControllers()
            };
            return View(createRoleViewModel);
        }

        // POST: ROle/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(CreateRoleViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                viewModel.Controllers = GetControllers();
                return View(viewModel);
            }

            var role = new ApplicationRole
            {
                Name = viewModel.Name,
                RoleAccesses = new List<Models.RoleAccess>()
            };

            //
            foreach (var controller in viewModel.SelectedControllers)
            {
                foreach (var action in controller.Actions)
                {
                    role.RoleAccesses.Add(new Models.RoleAccess { Controller = controller.Name, Action = action.Name });
                }
            }

            await RoleManager.CreateAsync(role);
            return RedirectToAction("Index");
        }

        // GET: /Role/Edit
        [Description("Edit Role")]
        public async Task<ActionResult> Edit(string id)
        {
            var role = await RoleManager.FindByIdAsync(id);
            if (role == null)
                return HttpNotFound();

            var viewModel = new EditRoleViewModel
            {
                Id = role.Id,
                Name = role.Name,
                RoleAccesses = new List<Models.RoleAccess>(role.RoleAccesses),
                Controllers = GetControllers()
            };

            return View(viewModel);
        }

        // POST: /Role/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(EditRoleViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                viewModel.Controllers = GetControllers();
                return View(viewModel);
            }

            var role = await RoleManager.FindByIdAsync(viewModel.Id);
            role.Name = viewModel.Name;
            var dbContext = HttpContext.GetOwinContext().Get<ApplicationDbContext>();
            dbContext.RoleAccesses.RemoveRange(role.RoleAccesses);

            foreach (var controller in viewModel.SelectedControllers)
            {
                foreach (var action in controller.Actions)
                {
                    role.RoleAccesses.Add(new Models.RoleAccess
                    {
                        Action = action.Name,
                        Controller = controller.Name,
                        RoleId = role.Id,
                        Role = role,
                    });
                }
            }
            await RoleManager.UpdateAsync(role);
            await dbContext.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        // GET: /Role/Delete
        [Description("Delete Role")]
        public async Task<JsonResult> Delete(string id)
        {
            var role = await RoleManager.FindByIdAsync(id);
            if (role == null)
            {
                Response.StatusCode = (int)HttpStatusCode.NotFound;
                return Json(false, JsonRequestBehavior.AllowGet);
            }

            await RoleManager.DeleteAsync(role);
            return Json(true, JsonRequestBehavior.AllowGet);
        }

        private static IEnumerable<ControllerDescription> GetControllers()
        {
            if (_controllerList.IsValueCreated)
                return _controllerList.Value;

            _controllerList = new Lazy<IEnumerable<ControllerDescription>>(() => new ControllerHelper().GetControllersNameAnDescription());
            return _controllerList.Value;
        }
    }
}